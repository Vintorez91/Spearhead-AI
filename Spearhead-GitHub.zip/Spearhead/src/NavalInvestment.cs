using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Warheads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedStrategyBotModule {
  sealed class NavalBudgetCheck { public int Until; public bool Allowed; public string Reason; }
  readonly Dictionary<string,NavalBudgetCheck> navalBudget=new Dictionary<string,NavalBudgetCheck>();
  internal void ResetNavalBudgetProbe(){navalBudget.Clear();}
  internal bool AllowNavalInvestment(ActorInfo ship) {
   if(!AITestMetrics.NavalInvestmentEnabled || !new[]{"ca","msub","dd","pt","ss"}.Contains(ship.Name))return true;
   NavalBudgetCheck cached;if(navalBudget.TryGetValue(ship.Name,out cached)&&world.WorldTick<cached.Until)return cached.Allowed;
   Refresh();string reason;var allowed=CheckNavalInvestment(ship,out reason);
   navalBudget[ship.Name]=new NavalBudgetCheck{Until=world.WorldTick+250,Allowed=allowed,Reason=reason};
   Console.WriteLine("AI-NAVAL-BUDGET tick="+world.WorldTick+" ship="+ship.Name+" allowed="+allowed+" reason="+reason);return allowed;
  }
  bool CheckNavalInvestment(ActorInfo ship,out string reason) {
   reason="no_connected_known_target";
   var mobile=ship.TraitInfoOrDefault<MobileInfo>();if(mobile==null)return false;
   var loco=world.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==mobile.Locomotor);var finder=world.WorldActor.Trait<IPathFinder>();
   var yards=world.Actors.Where(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead&&(a.Info.Name=="syrd"||a.Info.Name=="spen")).ToArray();
   var starts=yards.SelectMany(y=>world.Map.FindTilesInCircle(y.Location,5).Where(c=>mobile.CanEnterCell(world,null,c)).OrderBy(c=>(c-y.Location).LengthSquared).Take(4)).Distinct().ToArray();
   if(starts.Length==0){reason="no_shipyard_water";return false;}
   foreach(var target in KnownEnemies.Where(o=>world.WorldTick-o.Seen<=(o.Building?7500:1500)).OrderByDescending(o=>o.Seen).Take(16)) {
    if((ship.Name=="ca"||ship.Name=="msub")&&!target.Building)continue;
    var arms=ship.TraitInfos<ArmamentInfo>().Select(a=>world.Map.Rules.Weapons[a.Weapon.ToLowerInvariant()]).Where(w=>w.IsValidTarget(target.TargetTypes)&&w.Warheads.OfType<DamageWarhead>().Any(d=>d.Damage>0&&(target.Armor==null||!d.Versus.ContainsKey(target.Armor)||d.Versus[target.Armor]>0))).ToArray();
    foreach(var arm in arms) {
     var range=Math.Max(0,arm.Range.Length-512);var min=arm.MinRange.Length+512;
     foreach(var cell in world.Map.FindTilesInCircle(target.Position,range/1024+1).Where(c=>player.Shroud.IsExplored(c)&&mobile.CanEnterCell(world,null,c)&&(long)(c-target.Position).LengthSquared*1024*1024<=(long)range*range&&(long)(c-target.Position).LengthSquared*1024*1024>=(long)min*min).OrderBy(c=>starts.Min(s=>(s-c).LengthSquared)).Take(32))
      if(starts.Any(s=>finder.PathExistsForLocomotor(loco,s,cell))){reason="reachable_known_target:"+target.Id;return true;}
    }
   }
   if(ship.Name=="ca"||ship.Name=="msub")return false;
   var scoutCount=world.Actors.Count(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead&&new[]{"pt","dd","ss"}.Contains(a.Info.Name));
   var scoutQueued=new[]{"Ship","Submarine"}.SelectMany(q=>LegacyAIUtils.FindQueues(player,q)).SelectMany(q=>q.AllQueued()).Any(q=>new[]{"pt","dd","ss"}.Contains(q.Item));
   if(scoutCount>0||scoutQueued){reason="scout_already_available";return false;}
   for(var x=world.Map.Bounds.Left+3;x<world.Map.Bounds.Right;x+=6)for(var y=world.Map.Bounds.Top+3;y<world.Map.Bounds.Bottom;y+=6){var c=new CPos(x,y);if(!mobile.CanEnterCell(world,null,c)||player.Shroud.IsExplored(c))continue;if(starts.Any(s=>finder.PathExistsForLocomotor(loco,s,c))){reason="one_exploration_ship";return true;}}
   reason="no_unexplored_connected_water";return false;
  }
 }
}

