using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedBaseBuilderBotModule {
  internal void ResetAirDefenceProbe(){nextDefenceReview=0;}
 }
 public partial class AITestMetrics {
  bool airPoliciesChecked;
  void CheckAirPolicies(World world){
   if(airPoliciesChecked||world.WorldTick!=150)return;airPoliciesChecked=true;
   var own=world.Players.First(p=>p.IsBot&&p.BotType=="improved");
   var enemy=world.Players.First(p=>p.Playable&&p.RelationshipWith(own)==PlayerRelationship.Enemy);
   world.AddFrameEndTask(w=>{
    var strategy=own.PlayerActor.Trait<ImprovedStrategyBotModule>();
    var builder=own.PlayerActor.Trait<ImprovedBaseBuilderBotModule>();
    Func<string,Player,CPos,Actor> make=(name,p,c)=>w.CreateActor(name,new TypeDictionary{new OwnerInit(p),new LocationInit(c)});
    make(own.Faction.InternalName=="russia"||own.Faction.InternalName=="ukraine"?"ftur":"pbox",own,own.HomeLocation+new CVec(-5,0));
    var heli=make("heli",own,own.HomeLocation+new CVec(4,4));
    var ammo=heli.Trait<AmmoPool>();ammo.TakeAmmo(heli,ammo.Info.Ammo);
    var rearm=heli.Trait<Rearmable>();
    var type=typeof(Squads.AirAttackState);
    var automatic=type.BaseType.BaseType.GetMethod("ReloadsAutomatically",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic);
    if((bool)automatic.Invoke(null,new object[]{heli.TraitsImplementing<AmmoPool>(),rearm}))throw new InvalidOperationException("Helicopter incorrectly classified as airborne automatic reload");
    var bot=new AirPolicyProbeBot(w,own);var squad=new Squads.Squad(bot,own.PlayerActor.Trait<ImprovedSquadManagerBotModule>(),Squads.SquadType.Air,make("2tnk",enemy,own.HomeLocation+new CVec(8,5)));
    squad.Units.Add(heli);
    w.IssueOrder(new Order("Attack",heli,Target.FromActor(squad.TargetActor),false));
    // A separate later tick verifies the active pursuit is interrupted by ReturnToBase.
    policyProbeSquad=squad;policyProbeBot=bot;
    var countries=own.Faction.InternalName=="russia"||own.Faction.InternalName=="ukraine";
    var aa=w.Map.Rules.Actors[countries?"sam":"agun"];
    var ground=w.Map.Rules.Actors[countries?"ftur":"pbox"];
    var observations=Enumerable.Range(0,3).Select(i=>new ImprovedStrategyBotModule.Observation{Id=(uint)(900000+i),Owner=enemy,Info=w.Map.Rules.Actors["heli"],Position=own.HomeLocation+new CVec(16+i,0),Seen=w.WorldTick,Armed=true,Value=2000,Armor="Light",TargetTypes=new BitSet<TargetableType>("Air", "AirborneActor")}).ToArray();
    strategy.ProbeKnowledge(observations);builder.ResetAirDefenceProbe();
    var selected=builder.ChooseTargetedDefence(new[]{ground,aa});
    if(selected!=aa)throw new InvalidOperationException("Air wave did not prioritize AA over existing ground defence");
    Console.WriteLine("AI-AIRPOLICY TEST passed ground defence does not block AA; selected="+aa.Name);
    strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation[0]);builder.ResetAirDefenceProbe();
    selected=builder.ChooseTargetedDefence(new[]{ground,aa});
    if(selected==aa)throw new InvalidOperationException("No observed aircraft should not trigger AA");
    Console.WriteLine("AI-AIRPOLICY TEST passed no unseen-aircraft AA trigger");
   });
  }
  Squads.Squad policyProbeSquad;AirPolicyProbeBot policyProbeBot;
  void CheckAirPursuit(World w){
   if(policyProbeSquad==null||(w.WorldTick!=160&&w.WorldTick!=170))return;
   if(w.WorldTick==170){var h=policyProbeSquad.Units[0];h.Trait<AmmoPool>().GiveAmmo(h,1);var before=policyProbeBot.Attacks;new Squads.AirAttackState().Tick(policyProbeSquad);if(policyProbeBot.Attacks!=before)throw new InvalidOperationException("Partially reloaded helicopter resumed pursuit");Console.WriteLine("AI-AIRPOLICY TEST passed partial reload stays reserved");return;}
   new Squads.AirAttackState().Tick(policyProbeSquad);
   if(policyProbeBot.Returns==0)throw new InvalidOperationException("Empty helicopter pursuit did not order ReturnToBase");
   Console.WriteLine("AI-AIRPOLICY TEST passed empty helicopter pursuit orders ReturnToBase");
  }
 }
 sealed class AirPolicyProbeBot:IBot{
  readonly World world; public int Returns,Attacks;public Player Player{get;private set;}public IBotInfo Info=>null;
  public AirPolicyProbeBot(World w,Player p){world=w;Player=p;}public void Activate(Player p){Player=p;}
  public void QueueOrder(Order o){if(o.OrderString=="ReturnToBase")Returns++;if(o.OrderString=="Attack")Attacks++;world.IssueOrder(o);}
 }
}