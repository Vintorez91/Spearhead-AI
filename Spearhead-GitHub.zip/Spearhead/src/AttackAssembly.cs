using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedSquadManagerBotModule
 {
  sealed class MassAssembly { public CPos Cell; public int Started, NextOrder, NextLog; public bool Released; }
  readonly Dictionary<Squad,MassAssembly> massAssemblies=new Dictionary<Squad,MassAssembly>();
  int massAssemblyCooldown;
  readonly Dictionary<Squad,int> nextWaitReasonLog=new Dictionary<Squad,int>();
  internal void LogAttackWait(Squad squad,string reason,int duration){
   TraceAttack(squad,reason,"wait_ticks="+duration);
   int next;if(nextWaitReasonLog.TryGetValue(squad,out next)&&World.WorldTick<next)return;
   nextWaitReasonLog[squad]=World.WorldTick+125;
   LogOperation(squad,"wait_reason="+reason+" duration="+duration+" units="+squad.Units.Count);
   foreach(var stale in nextWaitReasonLog.Keys.Where(s=>!Squads.Contains(s)||!s.IsValid).ToArray())nextWaitReasonLog.Remove(stale);
  }
  const bool AdaptiveAssembly=true;
  const bool AdvanceVanguard=true;
  const bool LocalAttackAssessment=true;
  public static int AssemblyRadius(int count) { return Math.Min(14,Math.Max(7,(int)Math.Ceiling(Math.Sqrt(Math.Max(1,count))*1.2))); }
  internal bool HoldForMassAssembly(Squad squad) {
   if(Strategy==null||Strategy.Plan!=StrategicPlan.AllIn||squad.Type!=SquadType.Assault||!squad.IsValid||!squad.IsTargetValid)return false;
   MassAssembly assembly;
   if(!massAssemblies.TryGetValue(squad,out assembly)) {
    var units=squad.Units.OrderBy(a=>(a.Location-squad.TargetActor.Location).LengthSquared).ToArray();
    var representative=units[units.Length/2];var mobile=representative.TraitOrDefault<Mobile>();
    var domain=new DomainIndex(World);
    var cell=World.Map.FindTilesInCircle(representative.Location,5).Where(c=>Player.Shroud.IsExplored(c)&&mobile!=null&&domain.IsPassable(representative.Location,c,mobile.Locomotor))
     .Where(c=>!World.FindActorsInCircle(World.Map.CenterOfCell(c),WDist.FromCells(10)).Any(a=>IsPreferredEnemyUnit(a)&&a.Info.HasTraitInfo<AttackBaseInfo>()))
     .OrderBy(c=>(c-representative.Location).LengthSquared).Select(c=>(CPos?)c).FirstOrDefault();
    if(!cell.HasValue){LogOperation(squad,"assembly unavailable; hold mass attack");massAssemblyCooldown=World.WorldTick+500;ReleaseUnits(squad);return true;}
    massAssemblies[squad]=assembly=new MassAssembly{Cell=cell.Value,Started=World.WorldTick};
   }
   if(assembly.Released)return false;
   var radius=AdaptiveAssembly?AssemblyRadius(squad.Units.Count):7;
   var total=squad.Units.Sum(a=>a.GetSellValue());
   var nearby=squad.Units.Where(a=>(a.Location-assembly.Cell).LengthSquared<=radius*radius).ToArray();
   var nearValue=nearby.Sum(a=>a.GetSellValue());
   var fraction=total>0?nearValue/(double)total:nearby.Length/(double)squad.Units.Count;
   var danger=World.FindActorsInCircle(squad.CenterPosition,WDist.FromCells(6)).Any(a=>IsPreferredEnemyUnit(a)&&a.Info.HasTraitInfo<AttackBaseInfo>());
   var ready=nearby.Length>=8&&fraction>=0.75;
   if(ready||danger) {
    assembly.Released=true;LogOperation(squad,"assembly released reason="+(ready?"ready":"contact")+" near="+nearby.Length+" total="+squad.Units.Count+" radius="+radius+" fraction="+fraction.ToString("F2",System.Globalization.CultureInfo.InvariantCulture)+" wait="+(World.WorldTick-assembly.Started));return false;
   }
   if(World.WorldTick-assembly.Started>=750 && AdvanceVanguard && nearby.Length>=8 && CanCommitLocalAttack(squad,squad.TargetActor,nearby,"vanguard")) {
    assembly.Released=true;LogOperation(squad,"assembly released reason=vanguard near="+nearby.Length+" total="+squad.Units.Count+" radius="+radius+" wait="+(World.WorldTick-assembly.Started));return false;
   }
   if(World.WorldTick-assembly.Started>=750) {
    LogOperation(squad,"assembly aborted timeout near="+nearby.Length+" total="+squad.Units.Count);massAssemblyCooldown=World.WorldTick+500;ReleaseUnits(squad);return true;
   }
   if(World.WorldTick>=assembly.NextLog) {assembly.NextLog=World.WorldTick+125;LogOperation(squad,"assembly waiting cell="+assembly.Cell+" near="+nearby.Length+" total="+squad.Units.Count+" radius="+radius+" fraction="+fraction.ToString("F2",System.Globalization.CultureInfo.InvariantCulture));}
   if(World.WorldTick>=assembly.NextOrder) {assembly.NextOrder=World.WorldTick+75;    var spots=World.Map.FindTilesInAnnulus(assembly.Cell,2,AdaptiveAssembly?Math.Max(3,radius-2):3).Where(c=>Player.Shroud.IsExplored(c)).ToArray();
    foreach(var a in squad.Units.Where(a=>(a.Location-assembly.Cell).LengthSquared>(AdaptiveAssembly?Math.Max(3,radius-2)*Math.Max(3,radius-2):9))) {
     var mobile=a.TraitOrDefault<Mobile>();var domain=new DomainIndex(World);
     var destination=AdaptiveAssembly&&spots.Length>0?spots[(int)(a.ActorID%(uint)spots.Length)]:assembly.Cell;
     if(mobile==null||!domain.IsPassable(a.Location,destination,mobile.Locomotor))destination=assembly.Cell;
     squad.Bot.QueueOrder(new Order("AttackMove",a,Target.FromCell(World,destination),false));
    }}
   foreach(var stale in massAssemblies.Keys.Where(s=>!Squads.Contains(s)||!s.IsValid).ToArray())massAssemblies.Remove(stale);
   return true;
  }
 }
 public partial class AITestMetrics
 {
  StreamWriter attackDecisionLog;
  void InitializeAttackDecisionTelemetry(string prefix) {attackDecisionLog=new StreamWriter(prefix+"-attack-decisions.csv");attackDecisionLog.WriteLine("tick,player,chosen,land_value,estimated_resistance,uncertainty,recent_enemy_bases,opponents,visible_enemies,remembered_enemies,urgent,recent_loss");}
  public void TelemetryAttackDecision(int tick,Player player,StrategicPlan chosen,int land,int resistance,int uncertainty,int bases,int opponents,int visible,int remembered,bool urgent,bool loss) {
   if(attackDecisionLog!=null)attackDecisionLog.WriteLine(Csv(tick,player.InternalName,chosen,land,resistance,uncertainty,bases,opponents,visible,remembered,urgent,loss));
  }
 }
}





