using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  internal const bool CorrectedBreakthroughEnabled = true;
  readonly Dictionary<Squad,Actor> breakthroughOriginal = new Dictionary<Squad,Actor>();
  readonly Dictionary<Squad,int> breakthroughAssessmentTick = new Dictionary<Squad,int>();
  readonly Dictionary<Squad,int> breakthroughOrderTick = new Dictionary<Squad,int>();
  internal string BreakthroughReason {get;private set;} = "none";
  internal Actor BreakthroughDefense {get;private set;}
  CPos? breakthroughReconGoal;
  internal bool TryQueueBreakthrough(Squad squad) {
   BreakthroughReason="none";BreakthroughDefense=null;
   if(!CorrectedBreakthroughEnabled||!squad.IsValid||squad.Type!=SquadType.Assault)return false;
   RememberAttackGoal(squad);
   Actor macro;
   if(!breakthroughOriginal.TryGetValue(squad,out macro))macro=squad.TargetActor;
   if(macro==null||macro.IsDead||!macro.IsInWorld)return false;
   if(!macro.CanBeViewedByPlayer(Player))return false;
   var eligible=squad.Units.Where(a=>!a.IsDead&&a.IsInWorld&&!IsRecoveringVeteran(a)).ToArray();
   var nearby=eligible.Count(a=>(a.Location-macro.Location).LengthSquared<=576);

   int assessed;
   if(breakthroughOriginal.ContainsKey(squad)&&squad.IsTargetValid&&breakthroughAssessmentTick.TryGetValue(squad,out assessed)&&World.WorldTick-assessed<25){BreakthroughReason="commit";BreakthroughDefense=squad.TargetActor;return true;}
   breakthroughAssessmentTick[squad]=World.WorldTick;
   if(World.WorldTick%125<25)foreach(var dead in breakthroughAssessmentTick.Keys.Where(q=>!q.IsValid).ToArray()){breakthroughAssessmentTick.Remove(dead);breakthroughOriginal.Remove(dead);breakthroughOrderTick.Remove(dead);}
   var memory=Strategy.KnownEnemies.Where(o=>o.Building&&o.Armed&&(o.Position-macro.Location).LengthSquared<=144).ToArray();
   var live=World.FindActorsInCircle(macro.CenterPosition,WDist.FromCells(12))
    .Where(a=>!a.IsDead&&a.IsInWorld&&a.Owner.RelationshipWith(Player)==PlayerRelationship.Enemy
     &&a.CanBeViewedByPlayer(Player)&&a.Info.HasTraitInfo<BuildingInfo>()&&a.TraitsImplementing<Armament>().Any()).ToArray();
   var unseen=memory.Where(o=>!live.Any(a=>a.ActorID==o.Id)&&!Player.Shroud.IsVisible(o.Position)).ToArray();
   if(unseen.Length>0) {
    BreakthroughReason="recon";breakthroughReconGoal=unseen[0].Position;
    if(World.WorldTick%125<25)Console.WriteLine("AI-BREAK recon risk="+unseen.Sum(o=>o.Value*1.5)+" contacts="+unseen.Length);
    foreach(var u in squad.Units.Where(a=>!a.IsIdle))squad.Bot.QueueOrder(new Order("Stop",u,false));
    return true;
   }
   if(nearby<Math.Max(1,(int)Math.Ceiling(eligible.Length*0.85))){BreakthroughReason="approach";AdvanceAttackLocation(squad,macro.Location,16);return true;}
   if(live.Length==0) {
    if(breakthroughOriginal.ContainsKey(squad)){squad.TargetActor=macro;breakthroughOriginal.Remove(squad);}
    breakthroughReconGoal=null;return false;
   }
   var force=squad.Units.Where(a=>!a.IsDead&&a.IsInWorld&&!IsRecoveringVeteran(a)&&(a.Location-macro.Location).LengthSquared<=576).ToArray();
   var ownValue=force.Sum(a=>a.GetSellValue()*(a.TraitOrDefault<Health>()?.HP??1)/(double)(a.TraitOrDefault<Health>()?.MaxHP??1));
   var risk=live.Sum(a=>a.GetSellValue()*(a.TraitOrDefault<Health>()?.HP??1)/(double)(a.TraitOrDefault<Health>()?.MaxHP??1));
   var foes=World.FindActorsInCircle(macro.CenterPosition,WDist.FromCells(12)).Where(IsPreferredEnemyUnit).Where(a=>a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
   if(ownValue<risk*1.75||!ForecastBreakthrough(force,foes)) {
    BreakthroughReason="weak"; if(World.WorldTick%250<25)Console.WriteLine("AI-BREAK weak own="+ownValue+" risk="+risk+" force="+force.Length+" enemies="+foes.Length);
    foreach(var u in squad.Units.Where(a=>!a.IsIdle))squad.Bot.QueueOrder(new Order("Stop",u,false));
    return true;
   }
   var defense=live.Where(a=>force.Any(u=>AttackOrFleeFuzzy.SuitableAttacker(u,a)))
    .OrderByDescending(a=>breakthroughOriginal.ContainsKey(squad)&&a==squad.TargetActor ? double.MaxValue : AttackOrFleeFuzzy.EffectiveDamage(a,force))
    .ThenBy(a=>(a.CenterPosition-squad.CenterPosition).LengthSquared).FirstOrDefault();
   if(defense==null){BreakthroughReason="weak"; if(World.WorldTick%250<25)Console.WriteLine("AI-BREAK weak own="+ownValue+" risk="+risk+" force="+force.Length+" enemies="+foes.Length);return true;}
   var targetChanged=squad.TargetActor!=defense;
   breakthroughOriginal[squad]=macro;BreakthroughDefense=defense;BreakthroughReason="commit";squad.TargetActor=defense;
   int last;
   if(targetChanged||!breakthroughOrderTick.TryGetValue(squad,out last)||World.WorldTick-last>=50) {
    foreach(var u in force.Where(a=>(targetChanged||a.IsIdle)&&AttackOrFleeFuzzy.SuitableAttacker(a,defense)))
     squad.Bot.QueueOrder(new Order("Attack",u,Target.FromActor(defense),false));
    breakthroughOrderTick[squad]=World.WorldTick;
    Console.WriteLine("AI-BREAK commit tick="+World.WorldTick+" defense="+defense.ActorID+" own="+ownValue+" risk="+risk);
   }
   return true;
  }
  internal bool ForecastBreakthrough(Actor[] force,Actor[] foes) {
   if(force.Length==0)return false;
   var hp=force.Sum(a=>(double)(a.TraitOrDefault<IHealth>()?.HP??0));
   if(hp<=0)return false;
   var loss=foes.Sum(e=>AttackOrFleeFuzzy.EffectiveDamage(e,force)*force.Select(a=>Math.Max(0,AttackOrFleeFuzzy.WeaponRange(e,a)-AttackOrFleeFuzzy.WeaponRange(a,e))/(double)Math.Max(1,a.Info.HasTraitInfo<MobileInfo>()?a.Info.TraitInfo<MobileInfo>().Speed:1)).DefaultIfEmpty(0).Max());
   var remaining=foes.OrderByDescending(e=>AttackOrFleeFuzzy.EffectiveDamage(e,force)).ToList();
   while(remaining.Count>0){
    var victim=remaining[0];
    var dps=force.Sum(a=>AttackOrFleeFuzzy.EffectiveDamage(a,new[]{victim}))*Math.Max(0,1-loss/hp);
    if(dps<=0)return false;
    var duration=(victim.TraitOrDefault<IHealth>()?.HP??1)/dps;
    loss+=remaining.Sum(e=>AttackOrFleeFuzzy.EffectiveDamage(e,force))*duration;
    if(loss>hp*0.65)return false;
    remaining.RemoveAt(0);
   }
   return true;
  }
  internal CPos? BreakthroughScoutGoal(Actor scout) {
   if(!breakthroughReconGoal.HasValue)return null;
   var m=scout.TraitOrDefault<Mobile>();if(m==null)return null;
   return World.Map.FindTilesInAnnulus(breakthroughReconGoal.Value,5,7).Where(c=>m.Info.CanEnterCell(World,scout,c))
    .Where(c=>World.WorldActor.Trait<IPathFinder>().PathExistsForLocomotor(m.Locomotor,scout.Location,c))
    .OrderBy(c=>(c-scout.Location).LengthSquared).Select(c=>(CPos?)c).FirstOrDefault();
  }
 }
}




