using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
    public partial class ImprovedSquadManagerBotModule
    {
        internal ImprovedStrategyBotModule Strategy { get { return Player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>(); } }
        readonly Dictionary<Squad, bool> harassment = new Dictionary<Squad, bool>();
        readonly List<Actor> escortUnits = new List<Actor>();
        Actor escortedMcv;
        int nextOperationsTick;
        internal string TelemetryRole(Actor a)
        {
            if(EngineerRaidOwns(a))return "EngineerRaid";
            if (IsRecoveringVeteran(a)) return "VeteranRecovery";
            if (supportSquad != null && supportSquad.Units.Contains(a)) return "AllySupport";
            if (escortUnits.Contains(a)) return "MCVEscort";
            if (reconGroups.Any(g => g.Units.Contains(a))) return "Scout";
            var squad = Squads.FirstOrDefault(s => s.Units.Contains(a));
            if (squad != null) return harassment.ContainsKey(squad) && harassment[squad] ? "Diversion" : squad.Type.ToString();
            return "Reserve";
        }
        internal Actor TelemetryTarget(Actor a)
        {
            var squad = Squads.FirstOrDefault(s => s.Units.Contains(a));
            return squad == null || !squad.IsTargetValid ? null : squad.TargetActor;
        }
        bool IsEscort(Actor a) { return escortUnits.Contains(a); }
        void UpdateStrategicOperations(IBot bot)
        {
            var strategy = Strategy;
            if (strategy == null) return;
            strategy.Refresh();
            if (World.WorldTick < nextOperationsTick) return;
            nextOperationsTick = World.WorldTick + 75;
            foreach (var s in jointOperations.Keys.Where(s => !Squads.Contains(s) || !s.IsValid).ToArray()) { jointOperations.Remove(s); raidContact.Remove(s); }
            foreach (var s in harassment.Keys.Where(s => !Squads.Contains(s) || !s.IsValid).ToArray()) harassment.Remove(s);
            foreach (var s in flankRoutes.Keys.Where(s => !Squads.Contains(s) || !s.IsValid).ToArray()) flankRoutes.Remove(s);
            UpdateAllySupport(bot, strategy);
            UpdateEconomicDefense(strategy);QueueEconomicReserve(bot);
            if (strategy.HoldingOffense || EconomicDefenseHolding)
            {
                foreach (var s in Squads.Where(s => s.Type == SquadType.Assault || s.Type == SquadType.Rush).ToArray())
                { foreach (var a in s.Units) bot.QueueOrder(new Order("Move", a, Target.FromCell(World, GetRandomBaseCenter()), false)); ReleaseUnits(s); }
                if (strategy.Plan == StrategicPlan.Defend || EconomicDefenseHolding)
                {
                    var enemy = strategy.HomeEnemies.Where(a => a.CanBeViewedByPlayer(Player) && !a.IsDead).OrderBy(a=>EconomicDefenseHolding?(a.Location-economicGuardSite.Location).LengthSquared:0).FirstOrDefault();
                    if (enemy != null)
                    {
                        var defence = GetSquadOfType(SquadType.Protection) ?? RegisterNewSquad(bot, SquadType.Protection, enemy);
                        defence.TargetActor = enemy;
                        foreach (var a in unitsHangingAroundTheBase.OrderBy(a => (a.CenterPosition - enemy.CenterPosition).LengthSquared).Take(8).ToArray()) TransferUnit(a, defence);
                    }
                }
            }
            escortUnits.RemoveAll(unitCannotBeOrdered);
            if (escortedMcv == null || escortedMcv.IsDead || !escortedMcv.IsInWorld)
            {
                if (escortedMcv != null) { foreach (var a in escortUnits) activeUnits.Remove(a); escortUnits.Clear(); escortedMcv = null; }
                var mcv = World.Actors.FirstOrDefault(a => a.Owner == Player && a.Info.Name == "mcv" && !a.IsDead);
                if (mcv != null)
                {
                    escortedMcv = mcv;
                    var escort = unitsHangingAroundTheBase.Where(a => a.Info.HasTraitInfo<MobileInfo>() && a.Info.HasTraitInfo<AttackBaseInfo>())
                        .OrderBy(a => a.Info.TraitInfo<MobileInfo>().Locomotor == "foot" ? 1 : 0).Take(4).ToArray();
                    foreach (var a in escort) { unitsHangingAroundTheBase.Remove(a); escortUnits.Add(a); }
                    Console.WriteLine("AI-OPERATION escort units=" + escort.Length);
                }
            }
            if (escortedMcv != null && !escortedMcv.IsDead && escortedMcv.IsInWorld)
            {
                if (escortUnits.Count < 4)
                {
                    var reinforcement = unitsHangingAroundTheBase.Where(a => a.Info.HasTraitInfo<MobileInfo>() && a.Info.HasTraitInfo<AttackBaseInfo>())
                        .OrderBy(a => (a.CenterPosition - escortedMcv.CenterPosition).LengthSquared).Take(4 - escortUnits.Count).ToArray();
                    foreach (var a in reinforcement) { unitsHangingAroundTheBase.Remove(a); escortUnits.Add(a); }
                }
                var threats = strategy.VisibleEnemies.Where(a => a.CanBeViewedByPlayer(Player) && a.Info.HasTraitInfo<AttackBaseInfo>() && (a.CenterPosition - escortedMcv.CenterPosition).LengthSquared < 100L * 1024 * 1024).ToArray();
                if (threats.Length > 0 && !AttackOrFleeFuzzy.Default.CanAttack(escortUnits, threats))
                    bot.QueueOrder(new Order("Move", escortedMcv, Target.FromCell(World, Player.HomeLocation), false));
                foreach (var a in escortUnits)
                    if (a.IsIdle || (a.CenterPosition - escortedMcv.CenterPosition).LengthSquared > 36L * 1024 * 1024)
                        bot.QueueOrder(new Order("AttackMove", a, Target.FromCell(World, escortedMcv.Location), false));
            }
        }
        void CreateStrategicAttackForce(IBot bot)
        {
            var strategy = Strategy;
            strategy.Refresh();
            UpdateAllySupport(bot, strategy);
            if (strategy.HoldingOffense || EconomicDefenseHolding || strategy.AllyEnemies.Length > 0 || OffenseRegrouping) return;
            if(TryTeamOffense(bot))return;
            var reserve = strategy.MayExpand ? 4 : strategy.CombatCount >= 12 ? 2 : 0;
            var available = unitsHangingAroundTheBase.Where(a => !unitCannotBeOrdered(a) && a.Info.HasTraitInfo<AttackBaseInfo>()).ToList();
                        if(strategy.Plan==StrategicPlan.AllIn||strategy.Plan==StrategicPlan.Finish) {
                if(World.WorldTick<massAssemblyCooldown)return;
                var groups=Squads.Where(s=>s.Type==SquadType.Assault&&s.IsValid).ToArray();
                var combined=groups.Sum(s=>s.Units.Count)+Math.Max(0,available.Count-reserve);
                if(combined<strategy.AttackSize)return;
                var mass=groups.OrderByDescending(s=>s.Units.Count).FirstOrDefault()??RegisterNewSquad(bot,SquadType.Assault);
                foreach(var group in groups.Where(s=>s!=mass)) {
                    foreach(var a in group.Units.ToArray())TransferUnit(a,mass);
                    jointOperations.Remove(group);raidContact.Remove(group);harassment.Remove(group);flankRoutes.Remove(group);
                }
                foreach(var a in available.Take(Math.Max(0,available.Count-reserve)).ToArray())TransferUnit(a,mass);
                harassment[mass]=false;jointOperations.Remove(mass);raidContact.Remove(mass);
                if(mass.Units.Count!=combined||available.Count>reserve)LogOperation(mass,"committed "+strategy.Plan+" units="+mass.Units.Count+" reserve="+reserve);
                return;
            }
            if (available.Count < strategy.AttackSize + reserve) return;
            var waveSize = Math.Min(32, available.Count - reserve - (available.Count >= strategy.AttackSize + reserve + 4 ? 4 : 0));
            var main = RegisterNewSquad(bot, SquadType.Assault);
            foreach (var a in available.OrderBy(a => a.Info.HasTraitInfo<MobileInfo>() && a.Info.TraitInfo<MobileInfo>().Locomotor == "foot" ? 1 : 0).Take(waveSize).ToArray()) TransferUnit(a, main);
            harassment[main] = false;
            Console.WriteLine("AI-OPERATION mainAttack units=" + main.Units.Count + " plan=" + strategy.Plan);
            var remaining = unitsHangingAroundTheBase.Where(a => !unitCannotBeOrdered(a) && a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
            if (remaining.Length >= reserve + 4)
            {
                var raid = RegisterNewSquad(bot, SquadType.Assault);
                foreach (var a in remaining.OrderByDescending(a => a.Info.HasTraitInfo<MobileInfo>() ? a.Info.TraitInfo<MobileInfo>().Speed : 0).Take(4)) TransferUnit(a, raid);
                harassment[raid] = true;
                var operation = new JointOperation { Main = main, Raid = raid }; jointOperations[main] = operation; jointOperations[raid] = operation;
                Console.WriteLine("AI-OPERATION diversion units=" + raid.Units.Count);
            }
        }
        internal void ValidateStrategicAssignments()
        {
            var assigned = Squads.SelectMany(s => s.Units).Concat(reconGroups.SelectMany(g => g.Units)).Concat(escortUnits).Concat(veteranRecovery.Keys).Concat(raidEngineers).Concat(raidTransport==null?new Actor[0]:new[]{raidTransport}).Where(a => !unitCannotBeOrdered(a)).ToArray();
            if (assigned.GroupBy(a => a.ActorID).Any(g => g.Count() > 1)) throw new InvalidOperationException("Unit assigned to multiple operations.");
            if (Squads.SelectMany(s => s.Units).Any(a => a.Info.Name == "e6" || a.Info.Name == "mcv" || a.Info.Name == "harv")) throw new InvalidOperationException("Support unit assigned to combat squad.");
        }
        internal Actor ChooseOperationTarget(Squad squad)
        {
            var strategy = Strategy;
            if (strategy == null) return FindClosestEnemy(squad.Units.First().CenterPosition);
            strategy.Refresh();
            var leader = squad.Units.First();
            if(squad==teamSquad&&TeamObjectiveValid()){List<CPos> sharedPath;if(OffensiveRouteReady(squad,teamObjective,out sharedPath))return teamObjective;}
            var raid = harassment.ContainsKey(squad) && harassment[squad];
            return World.Actors.Where(IsPreferredEnemyUnit).Where(IsNotHiddenUnit)
                .Where(a => !unreachableTargets.ContainsKey(a.ActorID) || unreachableTargets[a.ActorID] <= World.WorldTick)
                .Where(a => squad.Units.Any(u => AttackOrFleeFuzzy.SuitableAttacker(u, a)))
                .Where(a => AttackOrFleeFuzzy.Default.CanAttack(squad.Units, World.FindActorsInCircle(a.CenterPosition, WDist.FromCells(10)).Where(IsPreferredEnemyUnit)))
                .OrderByDescending(a => TargetScore(a, leader.CenterPosition) * strategy.ObjectiveWeight(a) *
                    (strategy.Plan==StrategicPlan.Finish ? a.Info.HasTraitInfo<BuildingInfo>() ? 4 : 0.5 : raid ? a.Info.HasTraitInfo<HarvesterInfo>() ? 8 : a.Info.Name == "proc" ? 5 : 0.15 : 1) /
                    (1 + Squads.Count(s => s != squad && s.IsTargetValid && s.TargetActor == a) * (strategy.Plan == StrategicPlan.AllIn || strategy.Plan == StrategicPlan.Finish ? 0 : 4))).Take(4).FirstOrDefault(a => { List<CPos> path; return OffensiveRouteReady(squad,a,out path); });
        }
    }
}














