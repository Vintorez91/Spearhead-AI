using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  sealed class NavalMission { public Actor Target; public CPos? Destination; public CPos Last; public int Progress, Ordered, HoldUntil; public string Mode; public CPos? Contact; public int ContactSeen; public readonly Dictionary<uint,int> Blocked=new Dictionary<uint,int>(); }
  readonly Dictionary<Actor,NavalMission> navalMissions=new Dictionary<Actor,NavalMission>();
  readonly Dictionary<CPos,int> navalVisited=new Dictionary<CPos,int>();
  readonly Dictionary<Squad,int> navalNext=new Dictionary<Squad,int>();
  bool NavalVisibleEnemy(Actor a){return a!=null&&a.IsInWorld&&!a.IsDead&&a.OccupiesSpace!=null&&a.CanBeViewedByPlayer(Player)&&Player.RelationshipWith(a.Owner)==PlayerRelationship.Enemy;}
  internal Actor NavalMissionTarget(Actor unit){NavalMission m;return navalMissions.TryGetValue(unit,out m)?m.Target:null;}
  internal CPos? NavalFirePosition(Actor unit,Actor target){
   if(!NavalVisibleEnemy(target)||!AttackOrFleeFuzzy.SuitableAttacker(unit,target))return null;
   var mobile=unit.TraitOrDefault<Mobile>();if(mobile==null)return null;
   var arms=unit.TraitsImplementing<Armament>().Where(a=>!a.IsTraitDisabled&&!a.IsTraitPaused&&a.Weapon.IsValidTarget(target.GetEnabledTargetTypes())).ToArray();
   var range=arms.Select(a=>a.Weapon.Range.Length).DefaultIfEmpty(0).Max();if(range<=0)return null;
   var min=arms.Select(a=>a.Weapon.MinRange.Length).DefaultIfEmpty(0).Min();
   Func<CPos,bool> inRange=c=>{var d=(World.Map.CenterOfCell(c)-target.CenterPosition).LengthSquared;return d<=(long)Math.Max(0,range-256)*Math.Max(0,range-256)&&d>=(long)(min+256)*(min+256);};
   var finder=World.WorldActor.Trait<IPathFinder>();
   return World.Map.FindTilesInCircle(target.Location,range/1024+1).Where(c=>Player.Shroud.IsExplored(c)&&mobile.Info.CanEnterCell(World,unit,c)&&inRange(c))
    .OrderBy(c=>(c-unit.Location).LengthSquared).Where(c=>finder.PathExistsForLocomotor(mobile.Locomotor,unit.Location,c)).Select(c=>(CPos?)c).FirstOrDefault();
  }
  bool NavalTargetSuitable(Actor unit,Actor target){
   if(!NavalVisibleEnemy(target)||!AttackOrFleeFuzzy.SuitableAttacker(unit,target))return false;
   var ship=target.TraitOrDefault<Mobile>();var own=unit.Trait<Mobile>();
   var sea=ship!=null&&own.Locomotor.MovementCostForCell(target.Location)<short.MaxValue;
   if(unit.Info.Name=="ss")return sea||Info.NavalProductionTypes.Contains(target.Info.Name);
   if(unit.Info.Name=="ca"||unit.Info.Name=="msub")return target.Info.HasTraitInfo<BuildingInfo>()||sea;
   return sea||target.Info.HasTraitInfo<BuildingInfo>();
  }
  internal void TickNavalMissions(Squad squad){
   if(!squad.IsValid)return;int next;if(navalNext.TryGetValue(squad,out next)&&World.WorldTick<next)return;navalNext[squad]=World.WorldTick+100;
   foreach(var dead in navalMissions.Keys.Where(a=>a.IsDead||!a.IsInWorld).ToArray())navalMissions.Remove(dead);
   var ships=squad.Units.Where(a=>!a.IsDead&&a.IsInWorld&&a.TraitOrDefault<Mobile>()!=null&&!IsRecoveringVeteran(a)).ToArray();
   var visible=World.Actors.Where(NavalVisibleEnemy).ToArray();
   AssignNavalEscorts(ships,visible);
   var scouts=ships.Where(a=>a.Info.Name=="pt"&&!navalEscorts.ContainsKey(a)).OrderBy(a=>a.ActorID).Take(2).ToArray();
   if(scouts.Length==0)scouts=ships.Where(a=>a.Info.Name=="dd"&&!navalEscorts.ContainsKey(a)).OrderBy(a=>a.ActorID).Take(1).ToArray();
   if(scouts.Length==0)scouts=ships.Where(a=>a.Info.Name=="ss"&&!navalEscorts.ContainsKey(a)).OrderBy(a=>a.ActorID).Take(1).ToArray();
   foreach(var unit in ships.OrderBy(a=>a.Info.Name=="ca"||a.Info.Name=="msub"?0:1)){
    NavalMission mission;if(!navalMissions.TryGetValue(unit,out mission)){mission=new NavalMission{Last=unit.Location,Progress=World.WorldTick};navalMissions[unit]=mission;}
    if(unit.Location!=mission.Last){mission.Last=unit.Location;mission.Progress=World.WorldTick;}
    if(World.WorldTick<mission.HoldUntil)continue;
    var health=unit.TraitOrDefault<IHealth>();
    var threats=visible.Where(e=>e.Info.HasTraitInfo<AttackBaseInfo>()&&AttackOrFleeFuzzy.EffectiveDamage(e,new[]{unit})>0&&(e.Location-unit.Location).LengthSquared<=144).ToArray();
    var support=ships.Where(a=>(a.Location-unit.Location).LengthSquared<=100).ToArray();
    if(threats.Length>0&&(health!=null&&health.HP<health.MaxHP*.3||!AttackOrFleeFuzzy.Default.CanAttack(support,threats))){
     var mobile=unit.Trait<Mobile>();var finder=World.WorldActor.Trait<IPathFinder>();
     var safe=World.Map.FindTilesInAnnulus(unit.Location,4,9).Where(c=>Player.Shroud.IsExplored(c)&&mobile.Info.CanEnterCell(World,unit,c)).OrderByDescending(c=>threats.Min(e=>(e.Location-c).LengthSquared)).Where(c=>finder.PathExistsForLocomotor(mobile.Locomotor,unit.Location,c)).Select(c=>(CPos?)c).FirstOrDefault();
     if(safe.HasValue){squad.Bot.QueueOrder(new Order("Move",unit,Target.FromCell(World,safe.Value),false));mission.HoldUntil=World.WorldTick+300;mission.Target=null;mission.Destination=safe;mission.Mode="withdraw";Console.WriteLine("AI-NAVAL tick="+World.WorldTick+" unit="+unit.ActorID+" mode=withdraw water="+safe);}
     continue;
    }
    RememberNavalContact(mission);
    if(NavalRecoveryScout(unit))continue;
    if(QueueNavalEscort(squad,unit,mission,visible))continue;
    if(mission.Target!=null&&!NavalVisibleEnemy(mission.Target)){if(!unit.IsIdle)squad.Bot.QueueOrder(new Order("Stop",unit,false));mission.Target=null;mission.Destination=null;}
    if(mission.Target!=null&&World.WorldTick-mission.Progress>375&&unit.IsIdle){Console.WriteLine("AI-NAVAL tick="+World.WorldTick+" unit="+unit.ActorID+" mode=blocked target="+mission.Target.ActorID);mission.Blocked[mission.Target.ActorID]=World.WorldTick+750;mission.Target=null;mission.Destination=null;mission.HoldUntil=World.WorldTick+100;continue;}
    if(mission.Target==null){
     foreach(var target in visible.Where(a=>NavalTargetSuitable(unit,a)&&(!mission.Blocked.ContainsKey(a.ActorID)||World.WorldTick>=mission.Blocked[a.ActorID])).OrderByDescending(a=>(a.Info.HasTraitInfo<BuildingInfo>()&&(unit.Info.Name=="ca"||unit.Info.Name=="msub")?4000:0)+a.GetSellValue()-(a.Location-unit.Location).LengthSquared*2).Take(8)){
      var position=NavalFirePosition(unit,target);if(!position.HasValue)continue;
      mission.Target=target;mission.Destination=position;mission.Progress=World.WorldTick;mission.Mode="approach";mission.Ordered=-10000;
      Console.WriteLine("AI-NAVAL tick="+World.WorldTick+" unit="+unit.ActorID+" type="+unit.Info.Name+" target="+target.Info.Name+":"+target.ActorID+" water="+position);break;
     }
    }
    RememberNavalContact(mission);
    if(mission.Target!=null){
     var range=AttackOrFleeFuzzy.WeaponRange(unit,mission.Target);var dist=(unit.CenterPosition-mission.Target.CenterPosition).LengthSquared;
     var min=unit.TraitsImplementing<Armament>().Where(a=>!a.IsTraitDisabled&&!a.IsTraitPaused&&a.Weapon.IsValidTarget(mission.Target.GetEnabledTargetTypes())).Select(a=>a.Weapon.MinRange.Length).DefaultIfEmpty(0).Min();
     if(dist<=(long)range*range&&dist>=(long)min*min){
      if(mission.Mode!="fire"||unit.IsIdle){squad.Bot.QueueOrder(new Order("Attack",unit,Target.FromActor(mission.Target),false));mission.Mode="fire";mission.Ordered=World.WorldTick;Console.WriteLine("AI-NAVAL tick="+World.WorldTick+" unit="+unit.ActorID+" mode=fire target="+mission.Target.ActorID);}
      mission.Progress=World.WorldTick;
     }else if(mission.Destination.HasValue&&(mission.Ordered<0||unit.IsIdle)){
      if(unit.IsIdle&&mission.Ordered>=0){var refreshed=NavalFirePosition(unit,mission.Target);if(refreshed.HasValue)mission.Destination=refreshed;}
      squad.Bot.QueueOrder(new Order("Move",unit,Target.FromCell(World,mission.Destination.Value),false));mission.Mode="approach";mission.Ordered=World.WorldTick;
     }
     continue;
    }
    if((unit.Info.Name=="ca"||unit.Info.Name=="msub")&&RecoverNavalContact(squad,unit,mission,ships))continue;
    if(!scouts.Contains(unit))continue;
    if(!mission.Destination.HasValue||(unit.Location-mission.Destination.Value).LengthSquared<9||World.WorldTick-mission.Progress>300){
     if(mission.Destination.HasValue)navalVisited[mission.Destination.Value]=World.WorldTick;
     var mobile=unit.Trait<Mobile>();var finder=World.WorldActor.Trait<IPathFinder>();
     var candidates=new List<CPos>();for(var x=World.Map.Bounds.Left+3;x<World.Map.Bounds.Right;x+=6)for(var y=World.Map.Bounds.Top+3;y<World.Map.Bounds.Bottom;y+=6)candidates.Add(new CPos(x,y));
     var dangers=Strategy.KnownEnemies.Where(o=>o.Armed&&World.WorldTick-o.Seen<1500).ToArray();
     mission.Destination=candidates.Where(c=>mobile.Info.CanEnterCell(World,unit,c)&&(!navalVisited.ContainsKey(c)||World.WorldTick-navalVisited[c]>1500)&&dangers.All(o=>(o.Position-c).LengthSquared>100))
      .Where(c=>!navalMissions.Any(k=>k.Key!=unit&&k.Value.Mode=="scout"&&k.Value.Destination.HasValue&&(k.Value.Destination.Value-c).LengthSquared<36))
      .OrderByDescending(c=>World.Map.FindTilesInCircle(c,4).Count(t=>!Player.Shroud.IsExplored(t)&&mobile.Locomotor.MovementCostForCell(t)<short.MaxValue))
      .ThenBy(c=>(unit.Location-c).LengthSquared).Where(c=>finder.PathExistsForLocomotor(mobile.Locomotor,unit.Location,c)).Select(c=>(CPos?)c).FirstOrDefault();
     mission.Progress=World.WorldTick;mission.Ordered=-10000;
    }
    if(mission.Destination.HasValue&&(mission.Ordered<0||unit.IsIdle)){
     squad.Bot.QueueOrder(new Order("Move",unit,Target.FromCell(World,mission.Destination.Value),false));mission.Mode="scout";mission.Ordered=World.WorldTick;Console.WriteLine("AI-NAVAL tick="+World.WorldTick+" unit="+unit.ActorID+" mode=scout water="+mission.Destination);
    }
   }
  }
 }
}






