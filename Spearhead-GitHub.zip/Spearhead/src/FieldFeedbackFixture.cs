using System;
using System.Linq;
using System.Collections;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule { internal void ProbeRememberedLocation(Squads.Squad squad,CPos cell){attackGoals[squad]=new AttackGoalMemory{Cell=cell,Seen=World.WorldTick-25,Expires=World.WorldTick+375};} }
 public partial class AITestMetrics {
  bool fieldChecked;
  void CheckFieldFeedback(World world){
   if(world.WorldTick==149)world.Players.First(p=>p.IsBot&&p.BotType=="improved").Shroud.ExploreAll(); if(fieldChecked||world.WorldTick!=150)return;fieldChecked=true;
   world.AddFrameEndTask(w=>{
    var own=w.Players.First(p=>p.IsBot&&p.BotType=="improved");var enemy=w.Players.First(p=>p.Playable&&p.RelationshipWith(own)==PlayerRelationship.Enemy);
    var strategy=own.PlayerActor.Trait<ImprovedStrategyBotModule>();strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation[0]);
    var builder=own.PlayerActor.Trait<ImprovedBaseBuilderBotModule>();
    Func<string,CPos,Actor> make=(name,c)=>w.CreateActor(name,new TypeDictionary{new OwnerInit(own),new LocationInit(c)});
    var main=w.Actors.First(a=>a.Owner==own&&a.Info.Name=="fact");var forward=make("fact",own.HomeLocation+new CVec(-25,25));
    if(builder.PreferredTechBases().First()!=main)throw new InvalidOperationException("Safe main not preferred for tech");
    var queue=new ImprovedBaseBuilderQueueManager(builder,"Building",own,own.PlayerActor.Trait<PowerManager>(),own.PlayerActor.Trait<PlayerResources>(),new BitArray(256));
    var method=queue.GetType().GetMethod("ChooseBuildLocation",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);
    var selected=(CPos?)method.Invoke(queue,new object[]{"atek",true,BuildingType.Building});
    if(!selected.HasValue||(selected.Value-main.Location).LengthSquared>(selected.Value-forward.Location).LengthSquared)throw new InvalidOperationException("Tech placement did not stay at main");
    Console.WriteLine("AI-FIELD TEST passed tech placed at main location="+selected);
    strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation{Id=999123,Info=w.Map.Rules.Actors["3tnk"],Owner=enemy,Position=main.Location+new CVec(3,0),Seen=w.WorldTick,Value=1150,Armed=true});
    if(builder.PreferredTechBases().First()!=forward)throw new InvalidOperationException("Threatened main not replaced by safer base");
    Console.WriteLine("AI-FIELD TEST passed threatened main falls back to safe expansion");
    var tech=make("atek",own.HomeLocation+new CVec(-5,7));var box=make("pbox",own.HomeLocation+new CVec(-7,7));
    tech.InflictDamage(enemy.PlayerActor,new Damage(tech.Trait<Health>().HP*8/10));box.InflictDamage(enemy.PlayerActor,new Damage(box.Trait<Health>().HP*5/10));
    var repair=own.PlayerActor.Trait<ImprovedPriorityRepairBotModule>();
    if(repair.Priorities().First()!=tech)throw new InvalidOperationException("Critical damaged tech not first in repair priorities");
    var money=own.PlayerActor.Trait<PlayerResources>();money.TakeCash(Math.Max(0,money.Cash-500));money.TakeResources(money.Resources);
    var recorder=new ProbeBot(own);repair.ResetRepairProbe();((IBotTick)repair).BotTick(recorder);
    var orders=recorder.Orders.Where(o=>o.OrderString=="RepairBuilding").ToArray();
    if(!orders.Any(o=>o.Target.Actor==tech)||orders.Any(o=>o.Target.Actor==box))throw new InvalidOperationException("Scarce repair orders did not favor critical tech");
    Console.WriteLine("AI-FIELD TEST passed low funds repair critical tech ahead of pillbox");
    strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation[0]);
    own.Shroud.ExploreAll();
    var manager=own.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
    var mobile=w.Map.Rules.Actors["2tnk"].TraitInfo<MobileInfo>(); var start=w.Map.FindTilesInAnnulus(own.HomeLocation,14,24).First(c=>mobile.CanEnterCell(w,null,c)&&!w.Actors.Any(a=>a.OccupiesSpace!=null&&a.Location==c)); var unit=make("2tnk",start);
    var squad=new Squads.Squad(recorder,manager,Squads.SquadType.Assault);squad.Units.Add(unit);
    var loco=w.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==mobile.Locomotor); var route=FairNavigation.Route(w,own,loco,start,enemy.HomeLocation,12,new CPos[0],false); if(route.Count<15)throw new InvalidOperationException("Fixture has no traversable contact route"); var contact=route.Last(); manager.ProbeRememberedLocation(squad,contact);recorder.Orders.Clear();
    if(!manager.ContinueRememberedAttack(squad)||!recorder.Orders.Any(o=>o.OrderString=="AttackMove"))throw new InvalidOperationException("Lost contact caused retreat instead of location advance");
    if(recorder.Orders.Any(o=>o.OrderString=="Attack"))throw new InvalidOperationException("Lost contact used hidden actor attack");
    Console.WriteLine("AI-FIELD TEST passed lost contact uses location advance instead of actor attack or retreat");
   });
  }
 }
}


