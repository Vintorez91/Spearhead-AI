using System;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  Actor economicGuardSite; int economicGuardUntil;
  internal bool EconomicDefenseHolding => AITestMetrics.EconomicDefenseEnabled && economicGuardSite != null && economicGuardSite.IsInWorld && !economicGuardSite.IsDead && World.WorldTick < economicGuardUntil;
  internal CPos? EconomicDefenseLocation => EconomicDefenseHolding ? (CPos?)economicGuardSite.Location : null;
  void UpdateEconomicDefense(ImprovedStrategyBotModule strategy) {
   if(!AITestMetrics.EconomicDefenseEnabled || strategy.Plan!=StrategicPlan.Defend)return;
   var sites=World.Actors.Where(a=>a.Owner==Player&&a.IsInWorld&&!a.IsDead&&(a.Info.Name=="fact"||a.Info.Name=="proc")).ToArray();
   var harvesters=World.Actors.Where(a=>a.Owner==Player&&a.IsInWorld&&!a.IsDead&&a.Info.Name=="harv").ToArray();
   var threatened=sites.Where(s=>strategy.HomeEnemies.Any(e=>(e.Location-s.Location).LengthSquared<144)||harvesters.Any(h=>(h.Location-s.Location).LengthSquared<400&&strategy.HomeEnemies.Any(e=>(e.Location-h.Location).LengthSquared<144))).ToArray();
   if(threatened.Length>0) {
    var preferred=threatened.OrderByDescending(s=>sites.Count(b=>b.Info.Name=="proc"&&(b.Location-s.Location).LengthSquared<225)*2+harvesters.Count(h=>(h.Location-s.Location).LengthSquared<400))
     .ThenBy(s=>strategy.HomeEnemies.Min(e=>(e.Location-s.Location).LengthSquared)).First();
    if(!EconomicDefenseHolding || !threatened.Contains(economicGuardSite)) {economicGuardSite=preferred;Console.WriteLine("AI-ECONOMIC-GUARD tick="+World.WorldTick+" site="+preferred.ActorID+" cell="+preferred.Location);}
    economicGuardUntil=World.WorldTick+750;
   }
  }
  void QueueEconomicReserve(IBot bot) {
   if(!EconomicDefenseHolding)return;
   foreach(var a in unitsHangingAroundTheBase.Where(a=>!unitCannotBeOrdered(a)&&a.IsIdle&&a.Info.HasTraitInfo<MobileInfo>()&&!a.Info.HasTraitInfo<AircraftInfo>()&&!new[]{"naval","lcraft","float","sub"}.Contains(a.Info.TraitInfo<MobileInfo>().Locomotor)&&(a.Location-economicGuardSite.Location).LengthSquared>36).ToArray())
    bot.QueueOrder(new Order("AttackMove",a,Target.FromCell(World,economicGuardSite.Location),false));
  }
  internal void ProbeEconomicOperations(IBot bot){nextOperationsTick=0;UpdateStrategicOperations(bot);}
 }
}

