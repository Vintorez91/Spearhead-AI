using System;
using System.IO;
using System.Linq;
using OpenRA;
using OpenRA.Traits;
using OpenRA.Mods.Common.LoadScreens;
using OpenRA.Mods.Common.Traits;
using OpenRA.Widgets;
using OpenRA.Primitives;

namespace OpenRA.Mods.Common.Traits.AITest
{
    public class AITestLoadScreen : BlankLoadScreen
    {
        public override void StartGame(Arguments args)
        {
            if (args.GetValue("AITest.Enabled", "false") != "true") { base.StartGame(args); return; }
            Launch = new OpenRA.LaunchArguments(args);
            AITestMetrics.RushTrialExpectedMap=args.GetValue("AITest.Map", "AI Duel - Polar Disorder"); AITestMetrics.RushTrialSwap=args.GetValue("AITest.Swap","false")=="true"; AITestMetrics.RushTrialVariant=args.GetValue("AITest.RushTrialVariant","new"); AITestMetrics.EarlyReconEnabled=args.GetValue("AITest.EarlyRecon","true")=="true"; AITestMetrics.EconomicDefenseEnabled=args.GetValue("AITest.EconomicDefense","true")=="true"; AITestMetrics.NavalInvestmentEnabled=args.GetValue("AITest.NavalInvestment","true")=="true";
            if (!string.IsNullOrEmpty(args.GetValue("Launch.Replay", null))) { base.StartGame(args); return; }
            AITestMetrics.ControlEnabled = args.GetValue("AITest.Control", "false") == "true";
            AITestMetrics.TestScenario = args.GetValue("AITest.Scenario", AITestMetrics.TestScenario);
            AITestMetrics.SmokeTest = args.GetValue("AITest.SmokeTest", "false") == "true";
            int.TryParse(args.GetValue("AITest.TestTicks", "1500"), out AITestMetrics.SmokeExitTicks);
            Console.WriteLine("AI-TEST scenario=" + AITestMetrics.TestScenario);
            Ui.ResetAll();
            Game.Settings.Save();
            var map = Game.ModData.MapCache.First(m => m.Title == args.GetValue("AITest.Map", "AI Duel - Polar Disorder"));
            var swap = args.GetValue("AITest.Swap", "false") == "true";
            var baseline = args.GetValue("AITest.Baseline", "false") == "true";
            var teams = args.GetValue("AITest.Teams", "false") == "true";
            AITestMetrics.ExpectedTeams = teams;
            var opponent = args.GetValue("AITest.Opponent", "normal");
            var faction = args.GetValue("AITest.Faction", "russia");
                        var human = args.GetValue("AITest.Human", "false") == "true";
            var orders = new System.Collections.Generic.List<Order>();
            if(!human)orders.Add(Order.Command("spectate"));else orders.Add(Order.Command("join Multi0"));
            var count = teams ? 4 : 2;
            for (var i = 0; i < count; i++)
            {
                var improved = teams ? (i < 2) == swap : (i == 0) == swap;
                var type = human ? opponent : improved && !baseline ? "improved" : opponent;
                if(!human || i!=0)orders.Add(Order.Command("slot_bot Multi" + i + " 0 " + type));
                orders.Add(Order.Command("faction " + (human ? i : i + 1) + " " + (improved ? faction : args.GetValue("AITest.OpponentFaction",faction))));
                orders.Add(Order.Command("team " + (human ? i : i + 1) + " " + (teams ? i < 2 ? 1 : 2 : 0)));
                orders.Add(Order.Command("color " + (human ? i : i + 1) + " " + ((human && i==0 || type == "improved") ? i % 2 == 0 ? "3388FF" : "33DDFF" : i % 2 == 0 ? "FF3030" : "FF8800")));
            }
            orders.Add(Order.Command("option gamespeed " + args.GetValue("AITest.Speed", "default")));
            orders.Add(Order.Command("option startingcash 10000"));
            orders.Add(Order.Command("option crates False"));
            orders.Add(Order.Command("option startingunits none"));
            orders.Add(Order.Command("state Ready"));
            Game.CreateAndStartLocalServer(map.Uid, orders.ToArray());
        }
    }

    public class AITestMetricsInfo : TraitInfo<AITestMetrics> { }
    public partial class AITestMetrics : ITick, IWorldLoaded
    {
        public static bool EarlyReconEnabled=true; public static bool EconomicDefenseEnabled=true; public static bool NavalInvestmentEnabled=true; public static bool ExpectedTeams; public static bool SmokeTest; public static string TestScenario = "standard";
        public static int SmokeExitTicks = 1500;
        Actor[] veteranFixtures; bool[] veteranObserved, veteranReturned;
        string resultPath;
        bool finished; bool recoveryLossInjected, recoveryObserved, recoveryRestored; int recoveryLossTick;
        void IWorldLoaded.WorldLoaded(World world, OpenRA.Graphics.WorldRenderer wr)
        {
            if (world.Type != WorldType.Regular) return;
            if(SmokeTest && TestScenario=="targeting")SetupTargetingFixture(world);
            if(SmokeTest && TestScenario=="hypotheses")SetupHypothesisFixture(world);
            world.AddFrameEndTask(w => {
                foreach (var player in w.Players.Where(p => p.Playable && !p.Spectating))
                {
                    var mcv = w.Actors.FirstOrDefault(a => a.Owner == player && a.Info.Name == "mcv" && !a.IsDead);
                    if (mcv != null)
                    {
                        var transforms = mcv.Info.TraitInfo<TransformsInfo>();
                        var home = mcv.Location + transforms.Offset;
                        mcv.Dispose();
                        w.CreateActor(transforms.IntoActor, new TypeDictionary { new OwnerInit(player), new LocationInit(home), new SkipMakeAnimsInit() });
                        Console.WriteLine("AI-TEST STARTYARD: " + player.InternalName + " | " + home);
                    }
                    foreach (var name in new[] { "powr", player.Faction.InternalName == "russia" || player.Faction.InternalName == "ukraine" ? "barr" : "tent", "proc" })
                    {
                        var info = w.Map.Rules.Actors[name];
                        var building = info.TraitInfo<BuildingInfo>();
                        var location = w.Map.FindTilesInAnnulus(player.HomeLocation, 4, 12)
                            .Where(cell => w.CanPlaceBuilding(cell, info, building, null))
                            .Select(cell => (CPos?)cell).FirstOrDefault();
                        if (!location.HasValue) throw new InvalidOperationException("No valid location for fast-start building " + name);
                        w.CreateActor(name, new TypeDictionary { new OwnerInit(player), new LocationInit(location.Value), new SkipMakeAnimsInit() });
                        Console.WriteLine("AI-TEST STARTBASE: " + player.InternalName + " | " + name + " | " + location.Value);
                    }
                }
            });
            if (SmokeTest && TestScenario == "defence") world.AddFrameEndTask(w => {
                var player = w.Players.First(p => p.IsBot && p.BotType == "improved");
                var enemy = w.Players.First(p => p.IsBot && p != player);
                var mobile = w.Map.Rules.Actors["3tnk"].TraitInfo<MobileInfo>();
                var locomotor = w.WorldActor.TraitsImplementing<Locomotor>().First(l => l.Info.Name == mobile.Locomotor);
                var cells = w.Map.FindTilesInAnnulus(player.HomeLocation, 4, 6).Where(c => new DomainIndex(w).IsPassable(player.HomeLocation, c, locomotor)).Take(3).ToArray();
                foreach (var cell in cells) w.CreateActor("3tnk", new TypeDictionary { new OwnerInit(enemy), new LocationInit(cell) });
                Console.WriteLine("AI-SCENARIO defence enemies=" + cells.Length);
            });
            if (SmokeTest && (TestScenario == "recovery" || TestScenario == "forward-defence")) world.AddFrameEndTask(w => {
                var player = w.Players.First(p => p.IsBot && p.BotType == "improved");
                var yardInfo = w.Map.Rules.Actors["fact"]; var yardBuilding = yardInfo.TraitInfo<BuildingInfo>();
                var resources = new System.Collections.Generic.HashSet<byte>(w.Map.Rules.Actors["world"].TraitInfo<ResourceLayerInfo>().ResourceTypes.Values.Select(t => w.Map.Rules.TerrainInfo.GetTerrainIndex(t.TerrainType)));
                var ore = w.Map.AllCells.Where(c => resources.Contains(w.Map.GetTerrainIndex(c))).ToArray();
                var site = w.Map.FindTilesInAnnulus(player.HomeLocation, 22, 35).Where(c => w.CanPlaceBuilding(c, yardInfo, yardBuilding, null)).OrderBy(c => ore.Min(r => (r - c).LengthSquared)).First();
                w.CreateActor("fact", new TypeDictionary { new OwnerInit(player), new LocationInit(site), new SkipMakeAnimsInit() });
                var refineryInfo = w.Map.Rules.Actors["proc"]; var refineryBuilding = refineryInfo.TraitInfo<BuildingInfo>();
                var refineryCell = w.Map.FindTilesInAnnulus(site, 4, 8).First(c => w.CanPlaceBuilding(c, refineryInfo, refineryBuilding, null));
                w.CreateActor("proc", new TypeDictionary { new OwnerInit(player), new LocationInit(refineryCell), new SkipMakeAnimsInit() });
                Console.WriteLine("AI-SCENARIO recovery surviving refinery=" + refineryCell);
                foreach (var name in new[] { "weap", "fix" })
                {
                    var info = w.Map.Rules.Actors[name]; var building = info.TraitInfo<BuildingInfo>();
                    var cell = w.Map.FindTilesInAnnulus(player.HomeLocation, 4, 14).First(c => w.CanPlaceBuilding(c, info, building, null));
                    w.CreateActor(name, new TypeDictionary { new OwnerInit(player), new LocationInit(cell), new SkipMakeAnimsInit() });
                }
                Console.WriteLine("AI-SCENARIO recovery fixture yard=" + site);
                if (TestScenario == "forward-defence")
                {
                    var enemy = w.Players.First(p => p.IsBot && p != player);
                    var info = w.Map.Rules.Actors["e1"].TraitInfo<MobileInfo>();
                    var locomotor = w.WorldActor.TraitsImplementing<Locomotor>().First(l => l.Info.Name == info.Locomotor);
                    foreach (var cell in w.Map.FindTilesInAnnulus(site, 7, 9).Where(c => new DomainIndex(w).IsPassable(site, c, locomotor)).Take(3))
                        w.CreateActor("e1", new TypeDictionary { new OwnerInit(enemy), new LocationInit(cell) });
                }
            });
            if (SmokeTest && TestScenario == "veterans") world.AddFrameEndTask(w => {
                var p = w.Players.First(a => a.IsBot && a.BotType == "improved");
                var fixInfo = w.Map.Rules.Actors["fix"]; var building = fixInfo.TraitInfo<BuildingInfo>();
                var fixCell = w.Map.FindTilesInAnnulus(p.HomeLocation,4,10).First(c => w.CanPlaceBuilding(c,fixInfo,building,null));
                w.CreateActor("fix",new TypeDictionary { new OwnerInit(p),new LocationInit(fixCell),new SkipMakeAnimsInit() });
                veteranFixtures = new Actor[3]; veteranObserved = new bool[3]; veteranReturned = new bool[3];
                var names = new[] { "3tnk", "e1", "e1" }; var ranks = new[] { 2, 4, 1 };
                for (var i=0;i<3;i++) {
                    var info=w.Map.Rules.Actors[names[i]].TraitInfo<MobileInfo>();
                    var locomotor=w.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==info.Locomotor);
                    var cell=w.Map.FindTilesInAnnulus(p.HomeLocation,6,10).Where(c=>new DomainIndex(w).IsPassable(p.HomeLocation,c,locomotor)&&!w.Actors.Any(a=>a.OccupiesSpace!=null&&a.Location==c)).Skip(i*3).First();
                    veteranFixtures[i]=w.CreateActor(names[i],new TypeDictionary {new OwnerInit(p),new LocationInit(cell)});
                    veteranFixtures[i].Trait<GainsExperience>().GiveLevels(ranks[i],true);
                }
                Console.WriteLine("AI-VETERAN TEST fixtures="+string.Join(";",veteranFixtures.Select(a=>a.ActorID+":"+a.Info.Name)));
            });
            if(SmokeTest && TestScenario=="opportunity")SetupOpportunityFixture(world);
            var bots = world.Players.Where(p => p.IsBot && p.Playable).ToArray();
            if (ExpectedTeams && (bots.Length != 4 || bots.Any(p => bots.Count(a => a != p && p.RelationshipWith(a) == PlayerRelationship.Ally) != 1 || bots.Count(a => p.RelationshipWith(a) == PlayerRelationship.Enemy) != 2))) throw new InvalidOperationException("Expected two teams with one allied copy per player.");
            Console.WriteLine("AI-TEST FORMAT " + (ExpectedTeams ? "2v2" : "1v1") + " alliances=passed");
            var directory = Path.Combine(Platform.SupportDir, "Results");
            Directory.CreateDirectory(directory);
            resultPath = Path.Combine(directory, "duel-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".csv");
            File.WriteAllText(resultPath, "tick,player,ai,faction,state,units,buildings,harvesters,cash,resources\r\n");
            InitializeTelemetry(world, resultPath); InitializeControl(world);
            world.GameOver += () => { Record(world); TelemetrySnapshot(world); FlushTelemetry(); WriteDecisionSummary(world); };
            Console.WriteLine("AI-TEST OBSERVER: " + (world.LocalPlayer == null || world.LocalPlayer.Spectating));
            foreach (var p in world.Players.Where(p => p.IsBot && p.Playable)) Console.WriteLine("AI-TEST PLAYER: " + p.InternalName + " | " + p.PlayerName + " | " + p.BotType + " | " + p.Color);
            TextNotificationsManager.AddSystemLine("AI Testlab", "AI Testlab: jij kijkt toe. Bots, facties en teams staan in het spelersoverzicht. Resultaten en replay worden lokaal bewaard.");
        }
        void ITick.Tick(Actor self)
        {
            if (resultPath != null && !finished) { TelemetryTick(self.World); ControlTick(self.World); }
            if(SmokeTest && TestScenario=="opportunity")CheckOpportunityFixture(self.World);
            if(SmokeTest && TestScenario=="targeting")CheckTargetingFixture(self.World);
            if(SmokeTest && TestScenario=="fieldfeedback")CheckFieldFeedback(self.World);
            if(SmokeTest && TestScenario=="economy-policy")CheckEconomyPolicy(self.World); if(SmokeTest && TestScenario=="early-recon")CheckEarlyRecon(self.World); if(SmokeTest && TestScenario=="scout-rush")CheckScoutRush(self.World); if(SmokeTest && TestScenario=="placement-trace")CheckPlacementTrace(self.World);
            if(SmokeTest && TestScenario.StartsWith("naval"))CheckNavalFixture(self.World);
            if(SmokeTest && TestScenario=="airpolicy"){CheckAirPolicies(self.World);CheckAirPursuit(self.World);}
            if(SmokeTest && TestScenario.StartsWith("breakcombat-"))CheckBreakCombat(self.World);
            if(SmokeTest && TestScenario=="hypotheses")CheckHypothesisFixture(self.World);
            if (resultPath == null) return; if (finished) { if (SmokeTest) Game.Exit(); return; }
            if (SmokeTest && TestScenario == "veterans" && veteranFixtures!=null) {
                if (self.World.WorldTick==250) foreach(var a in veteranFixtures) a.InflictDamage(a,new Damage((int)(a.Trait<Health>().HP*(a.Trait<GainsExperience>().Level==4?1.10:0.90))));
                if (self.World.WorldTick>250) {
                    var manager=veteranFixtures[0].Owner.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
                    for(var i=0;i<3;i++) {
                        var a=veteranFixtures[i];
                        if(a.Disposed||a.IsDead)throw new InvalidOperationException("Veteran fixture was lost: "+i);
                        if(!a.IsInWorld)continue;
                        if(manager.VeteranRecovering(a))veteranObserved[i]=true;
                        var hp=a.Trait<Health>();
                        if(veteranObserved[i]&&!manager.VeteranRecovering(a)&&(i==2||hp.HP>=hp.MaxHP*0.85))veteranReturned[i]=true;
                    }
                    if(veteranReturned.All(a=>a)) {TelemetrySnapshot(self.World);FlushTelemetry();WriteDecisionSummary(self.World);Console.WriteLine("AI-VETERAN TEST repaired tank, healed elite and returned nonhealing infantry passed");Game.Exit();}
                    if(self.World.WorldTick>=SmokeExitTicks&&!veteranReturned.All(a=>a))throw new InvalidOperationException("Veteran test incomplete: "+string.Join(";",veteranObserved)+" / "+string.Join(";",veteranReturned));
                }
            }
            if (SmokeTest && TestScenario == "recovery")
            {
                var player = self.World.Players.First(p => p.IsBot && p.BotType == "improved");
                var expansion = player.PlayerActor.Trait<ImprovedMcvManagerBotModule>();
                var yards = self.World.Actors.Where(a => a.Owner == player && a.Info.Name == "fact" && !a.IsDead && a.IsInWorld).ToArray();
                if (!recoveryLossInjected && yards.Length >= 2 && self.World.WorldTick >= 250)
                {
                    recoveryLossInjected = true; recoveryLossTick = self.World.WorldTick;
                    var yard = yards.OrderByDescending(a => (a.Location - player.HomeLocation).LengthSquared).First();
                    Console.WriteLine("AI-SCENARIO recovery removing expansion=" + yard.Location);
                    self.World.AddFrameEndTask(w => yard.Dispose());
                }
                if (recoveryLossInjected && expansion.RecoveringExpansion) recoveryObserved = true;
                if (recoveryObserved && yards.Length >= 2 && !expansion.RecoveringExpansion && !recoveryRestored)
                { recoveryRestored = true; TelemetrySnapshot(self.World); FlushTelemetry(); WriteDecisionSummary(self.World); Game.Exit(); Console.WriteLine("AI-RECOVERY TEST restored after ticks=" + (self.World.WorldTick - recoveryLossTick)); }
                if (self.World.WorldTick >= SmokeExitTicks && (!recoveryObserved || !recoveryRestored))
                    throw new InvalidOperationException("Recovery scenario did not lose and restore an expansion.");
            }
            if (self.World.WorldTick % 250 == 0)
            {
                Record(self.World);
                if (SmokeTest)
                    foreach (var player in self.World.Players.Where(p => p.IsBot && p.BotType == "improved"))
                    {
                        var manager = player.PlayerActor.Trait<ImprovedSquadManagerBotModule>(); manager.ValidateStrategicAssignments();
                        var strategy = player.PlayerActor.Trait<ImprovedStrategyBotModule>(); strategy.Refresh();
                        if (TestScenario == "defence" && self.World.WorldTick == 250 && (strategy.Plan != StrategicPlan.Defend || strategy.MayExpand || strategy.MayCapture)) throw new InvalidOperationException("Defence scenario did not redirect strategic priorities.");
                        Console.WriteLine("AI-STRATEGY CHECK tick=" + self.World.WorldTick + " plan=" + strategy.Plan + " expand=" + strategy.MayExpand + " capture=" + strategy.MayCapture + " assignments=passed");
                        var selected = manager.FindClosestEnemy(self.World.Map.CenterOfCell(player.HomeLocation));
                        if (selected != null && !selected.CanBeViewedByPlayer(player))
                            throw new InvalidOperationException("Fair AI selected a hidden enemy.");
                        Console.WriteLine("AI-FAIR CHECK tick=" + self.World.WorldTick + " selected=" + (selected == null ? "none" : selected.Info.Name) + " passed");
                        var own = self.World.Actors.Where(a => a.Owner == player && !a.IsDead).ToArray();
                        Console.WriteLine("AI-EXPANSION CHECK tick=" + self.World.WorldTick + " yards=" + own.Count(a => a.Info.Name == "fact") + " yardLocations=" + string.Join(";", own.Where(a => a.Info.Name == "fact").Select(a => a.Location.ToString())) + " mcvs=" + own.Count(a => a.Info.Name == "mcv") + " refineries=" + string.Join(";", own.Where(a => a.Info.Name == "proc").Select(a => a.Location.ToString())));
                    }
            }
            if (SmokeTest && TestScenario == "visual" && !ControlEnabled && self.World.WorldTick == 500) Game.TakeScreenshot();
            if (SmokeTest && TestScenario == "forward-defence" && self.World.WorldTick >= SmokeExitTicks)
            {
                var player = self.World.Players.First(p => p.IsBot && p.BotType == "improved");
                var forward = self.World.Actors.Where(a => a.Owner == player && !a.IsDead && a.Info.HasTraitInfo<BuildingInfo>() && a.Info.HasTraitInfo<AttackBaseInfo>() && (a.Location - player.HomeLocation).LengthSquared > 324).ToArray();
                if (forward.Length == 0) throw new InvalidOperationException("No forward defence built in targeted scenario.");
                Console.WriteLine("AI-DEFENCE TEST forward buildings=" + forward.Length + " passed");
            }
            if (SmokeTest && self.World.WorldTick >= SmokeExitTicks) { TelemetrySnapshot(self.World); FlushTelemetry(); WriteDecisionSummary(self.World); Game.Exit(); }
            if (self.World.IsGameOver) finished = true;
        }
        void Record(World world)
        {
            foreach (var p in world.Players.Where(p => p.IsBot && p.Playable))
            {
                var actors = world.Actors.Where(a => a.Owner == p && !a.IsDead).ToArray();
                var r = p.PlayerActor.Trait<PlayerResources>();
                File.AppendAllText(resultPath, string.Join(",", world.WorldTick, p.InternalName, p.BotType, p.Faction.InternalName,
                    p.WinState, actors.Count(a => a.Info.HasTraitInfo<MobileInfo>()), actors.Count(a => a.Info.HasTraitInfo<BuildingInfo>()),
                    actors.Count(a => a.Info.HasTraitInfo<HarvesterInfo>()), r.Cash, r.Resources) + "\r\n");
            }
        }
    }
}



























