using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;

namespace OpenRA.Mods.Common.Traits.AITest
{
    public partial class ImprovedSquadManagerBotModule
    {
        sealed class Sighting { public uint Id; public CPos Position; public int Seen; public bool Building; }
        sealed class ReconGroup { public readonly List<Actor> Units = new List<Actor>(); public CPos? Destination; public int Ordered; public int RetreatUntil; public int Sector; public bool Local; public WPos LastPosition; public int LastProgress; }
        readonly Dictionary<uint, Sighting> sightings = new Dictionary<uint, Sighting>();
        readonly List<ReconGroup> reconGroups = new List<ReconGroup>();
        readonly Dictionary<CPos, int> visitedWaypoints = new Dictionary<CPos, int>();
        int nextReconTick;
        bool EarlyRecon => AITestMetrics.EarlyReconEnabled && World.WorldTick < 7500;
        bool LocalReconAllowed => EarlyRecon && (Strategy == null || Strategy.CombatCount < Strategy.AttackSize) && (Strategy == null || !Strategy.HoldingOffense);
        bool ReconEmergency(Actor[] visible) => visible.Any(a => a.Info.HasTraitInfo<AttackBaseInfo>() && (a.Location - Player.HomeLocation).LengthSquared < 576) || (Strategy != null && Strategy.Plan == StrategicPlan.Defend);
        int ReconBand(CPos cell) => (int)Math.Sqrt((cell - Player.HomeLocation).LengthSquared) / 12;
        int ReconSector(CPos cell) { var v=cell-Player.HomeLocation; return Math.Abs(v.X)>=Math.Abs(v.Y) ? (v.X>=0?0:2) : (v.Y>=0?1:3); }

        int nextRecruitTick;
        int reconOrders;
        int pokeOrders; int nextFairLogTick;

        bool VisibleEnemy(Actor a)
        {
            return a != null && a.TraitOrDefault<IPositionable>() != null && a.CanBeViewedByPlayer(Player) && !a.IsDead && a.IsInWorld && Player.RelationshipWith(a.Owner) == PlayerRelationship.Enemy;
        }

        void UpdateRecon(IBot bot)
        {
            if (World.WorldTick < nextReconTick) return;
            nextReconTick = World.WorldTick + 50;
            var visible = World.Actors.Where(VisibleEnemy).ToArray();
            if (Strategy != null)
            {
                Strategy.Refresh();
                sightings.Clear();
                foreach (var o in Strategy.KnownEnemies)
                    sightings[o.Id] = new Sighting { Id = o.Id, Position = o.Position, Seen = o.Seen, Building = o.Building };
            }
            foreach (var group in reconGroups.ToArray())
            {
                group.Units.RemoveAll(unitCannotBeOrdered);
                if (group.Units.Count == 0) { reconGroups.Remove(group); continue; }
                if (group.RetreatUntil > 0)
                {
                    if (World.WorldTick >= group.RetreatUntil)
                    {
                        foreach (var a in group.Units) activeUnits.Remove(a);
                        reconGroups.Remove(group);
                    }
                    continue;
                }
                if (group.Local && !LocalReconAllowed) {
                    foreach(var a in group.Units) { bot.QueueOrder(new Order("Move",a,Target.FromCell(World,EconomicDefenseLocation ?? Player.HomeLocation),false)); activeUnits.Remove(a); }
                    reconGroups.Remove(group); continue;
                }
                var leader = group.Units.First();
                var dangers = visible.Where(a => a.Info.HasTraitInfo<AttackBaseInfo>() &&
                    (a.CenterPosition - leader.CenterPosition).LengthSquared < 100L * 1024 * 1024).ToArray();
                var hurt = group.Units.Any(a => { var h = a.TraitOrDefault<IHealth>(); return h != null && h.HP < h.MaxHP * 0.6; });
                if ((AITestMetrics.EarlyReconEnabled && ReconEmergency(visible)) || hurt || (dangers.Length > 0 && !AttackOrFleeFuzzy.Default.CanAttack(group.Units, dangers)))
                {
                    bot.QueueOrder(new Order("Move", null, Target.FromCell(World, AITestMetrics.EarlyReconEnabled ? (EconomicDefenseLocation ?? Player.HomeLocation) : GetRandomBaseCenter()), false, groupedActors: group.Units.ToArray()));
                    group.RetreatUntil = World.WorldTick + 400;
                    nextRecruitTick = Math.Max(nextRecruitTick, World.WorldTick + (AITestMetrics.EarlyReconEnabled ? 750 : 500));
                    continue;
                }
                var target = visible.Where(a => !a.Info.HasTraitInfo<AircraftInfo>() && group.Units.Any(u => CanPoke(u, a)))
                    .Where(a => (a.CenterPosition - leader.CenterPosition).LengthSquared < 225L * 1024 * 1024)
                    .OrderByDescending(a => TargetScore(a, leader.CenterPosition)).FirstOrDefault();
                if (target != null && !group.Local)
                {
                    var guards = visible.Where(a => a.Info.HasTraitInfo<AttackBaseInfo>() &&
                        (a.CenterPosition - target.CenterPosition).LengthSquared < 64L * 1024 * 1024).ToArray();
                    if ((guards.Length == 0 || AttackOrFleeFuzzy.Default.CanAttack(group.Units, guards)) && (Strategy==null || Strategy.KnownEnemies.Where(e=>e.Armed&&e.Building).All(e=>(e.Position-target.Location).LengthSquared>144)))
                    {
                        if (World.WorldTick - group.Ordered >= 100)
                        {
                            foreach (var a in group.Units.Where(a => CanPoke(a, target))) bot.QueueOrder(new Order("Attack", a, Target.FromActor(target), false));
                            group.Ordered = World.WorldTick;
                            pokeOrders++;
                            Console.WriteLine("AI-RECON POKE visible target " + target.Info.Name + " at " + target.Location);
                        }
                        continue;
                    }
                }
                if ((leader.CenterPosition - group.LastPosition).LengthSquared > 1024L * 1024)
                { group.LastPosition = leader.CenterPosition; group.LastProgress = World.WorldTick; }
                if (!group.Destination.HasValue || (leader.Location - group.Destination.Value).LengthSquared < 16 || World.WorldTick - group.LastProgress > 250)
                {
                    if (group.Destination.HasValue) visitedWaypoints[group.Destination.Value] = World.WorldTick;
                    group.Destination = ChooseReconDestination(leader);
                    group.LastProgress = World.WorldTick;
                }
                if (group.Destination.HasValue && (leader.IsIdle || World.WorldTick - group.Ordered > 200))
                {
                    if(!QueueSafeReconMove(bot,group.Units.ToArray(),group.Destination.Value)){visitedWaypoints[group.Destination.Value]=World.WorldTick+1500;group.Destination=null;continue;}
                    group.Ordered = World.WorldTick;
                    reconOrders++;
                    Console.WriteLine("AI-RECON SCOUT " + group.Units.Count + " units to " + group.Destination.Value + " tick=" + World.WorldTick + " local=" + group.Local + " early=" + EarlyRecon + " sector=" + group.Sector + " band=" + ReconBand(group.Destination.Value));
                }
            }
            if (World.WorldTick >= nextRecruitTick && ! (AITestMetrics.EarlyReconEnabled && ReconEmergency(visible)) && (reconGroups.Count(g=>!g.Local) < 2 || LocalReconAllowed))
            {
                var local = reconGroups.Count(g=>!g.Local)>=2;
                var candidates = unitsHangingAroundTheBase.Where(a => !unitCannotBeOrdered(a) &&
                    (local ? new[] { "e1", "e2", "e3", "e4", "jeep", "ftrk", "1tnk", "2tnk", "3tnk" } : new[] { "e1", "jeep", "ftrk", "1tnk" }).Contains(a.Info.Name) && VeteranRank(a) < 2)
                    .OrderBy(VeteranRank).ThenBy(a => a.Info.Name == "e1" ? 1 : 0).Take(1).ToArray();
                if (candidates.Length > 0)
                {
                    var group = new ReconGroup { LastProgress = World.WorldTick, Local=local, Sector = Enumerable.Range(0,4).OrderBy(i=>reconGroups.Count(g=>g.Sector==i)).First() };
                    foreach (var a in candidates) { unitsHangingAroundTheBase.Remove(a); group.Units.Add(a); }
                    reconGroups.Add(group);
                    nextRecruitTick = World.WorldTick + (EarlyRecon ? 75 : 350);
                }
            }
            if (World.WorldTick >= nextFairLogTick)
                { nextFairLogTick = World.WorldTick + 250; Console.WriteLine("AI-FAIR tick=" + World.WorldTick + " visible=" + visible.Length + " memory=" + sightings.Count + " scouts=" + reconGroups.Sum(g => g.Units.Count) + " scoutOrders=" + reconOrders + " pokeOrders=" + pokeOrders); }
        }

        bool CanPoke(Actor own, Actor enemy)
        {
            return VisibleEnemy(enemy) && AttackOrFleeFuzzy.SuitableAttacker(own, enemy) && !enemy.Info.HasTraitInfo<HuskInfo>() && own.TraitsImplementing<Armament>()
                .Any(a => !a.IsTraitDisabled && !a.IsTraitPaused && a.Weapon.IsValidTarget(enemy.GetEnabledTargetTypes()));
        }

        CPos? ChooseReconDestination(Actor unit)
        {
            var mobile = unit.TraitOrDefault<Mobile>();
            var recon = reconGroups.FirstOrDefault(g=>g.Units.Contains(unit));
            if (mobile == null) return null;
            var domain = new DomainIndex(World);
            var recovery = Player.PlayerActor.TraitOrDefault<ImprovedMcvManagerBotModule>();
            var revisit = recovery == null ? null : recovery.RecoveryScoutTarget;
            if ((recon == null || !recon.Local) && revisit.HasValue && domain.IsPassable(unit.Location, revisit.Value, mobile.Locomotor) &&
                (!visitedWaypoints.ContainsKey(revisit.Value) || World.WorldTick - visitedWaypoints[revisit.Value] > 750) &&
                !reconGroups.Any(g => g.Destination == revisit)) return revisit;
            var cells = new List<CPos>();
            for (var x = World.Map.Bounds.Left + 4; x < World.Map.Bounds.Right; x += 4)
                for (var y = World.Map.Bounds.Top + 4; y < World.Map.Bounds.Bottom; y += 4)
                    cells.Add(new CPos(x, y));
            cells.AddRange(sightings.Values.Select(s => s.Position));
            if (Strategy != null && Strategy.Focus.HasValue) cells.Add(Strategy.Focus.Value);
            foreach (var old in armySearches.Keys.Where(s => !Squads.Contains(s) || !s.IsValid || s.Units.All(a => a.IsIdle)).ToArray()) armySearches.Remove(old);
            return cells.Where(c => recon == null || !recon.Local || (c-Player.HomeLocation).LengthSquared <= 1296)
                .Where(c => recon == null || !recon.Local || World.Map.FindTilesInCircle(c,4).Any(t=>!Player.Shroud.IsExplored(t) && mobile.Locomotor.MovementCostForCell(t)<short.MaxValue))
                .Where(c => World.Map.Contains(c) && domain.IsPassable(unit.Location, c, mobile.Locomotor))
                .Where(c => Strategy==null || Strategy.KnownEnemies.Where(e=>e.Armed&&e.Building).All(e=>(e.Position-c).LengthSquared>121))
                .Where(c => !armySearches.Values.Any(d => (d - c).LengthSquared < 64))
                .Where(c => !visitedWaypoints.ContainsKey(c) || World.WorldTick - visitedWaypoints[c] > 1500)
                .Where(c => !reconGroups.Any(g => g.Destination.HasValue && (g.Destination.Value - c).LengthSquared < 36))
                .OrderBy(c => EarlyRecon && recon != null ? (World.Map.FindTilesInCircle(c,4).Any(t=>!Player.Shroud.IsExplored(t) && mobile.Locomotor.MovementCostForCell(t)<short.MaxValue) ? 0 : 1) : 0)
                .ThenBy(c => EarlyRecon && recon != null ? ReconBand(c) : 0)
                .ThenBy(c => EarlyRecon && recon != null && ReconSector(c)!=recon.Sector ? 1 : 0)
                .ThenByDescending(c => World.Map.FindTilesInCircle(c, 4).Count(t => !Player.Shroud.IsExplored(t) && mobile.Locomotor.MovementCostForCell(t)<short.MaxValue))
                .ThenBy(c => Player.Shroud.IsExplored(c) ? (sightings.Values.Any(s => s.Position == c) ? 1 : 2) : 0)
                .ThenBy(c => (Strategy != null && Strategy.Focus.HasValue ? (c - Strategy.Focus.Value).LengthSquared : 0) + (unit.Location - c).LengthSquared).Select(c => (CPos?)c).FirstOrDefault();
        }

        bool QueueSafeReconMove(IBot bot,Actor[] units,CPos destination)
        {
            if(units.Length==0)return false;
            var mobile=units[0].TraitOrDefault<Mobile>();if(mobile==null)return false;
            var dangers=Strategy==null?new CPos[0]:Strategy.KnownEnemies.Where(e=>e.Building&&e.Armed).Select(e=>e.Position).ToArray();
            var path=FairNavigation.Route(World,Player,mobile.Locomotor,units[0].Location,destination,0,dangers,false);
            if(path.Count==0)return false;
            var queued=false;
            foreach(var cell in path.Take(6)) {bot.QueueOrder(new Order("Move",null,Target.FromCell(World,cell),queued,groupedActors:units));queued=true;}
            return true;
        }
        readonly Dictionary<Squad, CPos> armySearches = new Dictionary<Squad, CPos>();
        internal void ExploreSquad(Squad squad)
        {
            if (ApproachKnownLocation(squad)) return;
            var leader = squad.Units.FirstOrDefault();
            if (leader == null || !leader.IsIdle || OffenseRegrouping) return;
                        var destination = ChooseReconDestination(leader);
            if (Strategy != null && Strategy.Focus.HasValue)
            {
                var mobile = leader.TraitOrDefault<Mobile>();
                var focus = Strategy.Focus.Value;
                if (mobile != null && World.Map.Contains(focus) && !Player.Shroud.IsVisible(focus) &&
                    (!visitedWaypoints.ContainsKey(focus) || World.WorldTick - visitedWaypoints[focus] > 750) &&
                    !armySearches.Any(s => s.Key != squad && (s.Value - focus).LengthSquared < 64) &&
                    new DomainIndex(World).IsPassable(leader.Location, focus, mobile.Locomotor)) destination = focus;
            }
            if (!destination.HasValue) return;
            armySearches[squad] = destination.Value;
            visitedWaypoints[destination.Value] = World.WorldTick;
            QueueSafeReconMove(bot,squad.Units.ToArray(),destination.Value);
        }
    }
}









