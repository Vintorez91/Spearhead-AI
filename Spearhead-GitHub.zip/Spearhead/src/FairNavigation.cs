using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public static class FairNavigation
 {
  static readonly CVec[] Steps={new CVec(1,0),new CVec(-1,0),new CVec(0,1),new CVec(0,-1)};
  // Terrain is public map data; actor blockers must have been observed by this player.
  public static List<CPos> Route(World world,Player player,Locomotor locomotor,CPos start,CPos goal,int goalRadius,IEnumerable<CPos> dangers,bool exploredOnly=true,HashSet<CPos> goals=null)
  {
   var threats=dangers.ToArray();
   var blocked=new HashSet<CPos>(world.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&a.OccupiesSpace!=null&&!a.Info.HasTraitInfo<MobileInfo>()&&!a.Info.HasTraitInfo<AircraftInfo>()&&(a.Owner==player||a.CanBeViewedByPlayer(player))).SelectMany(a=>a.OccupiesSpace.OccupiedCells().Select(c=>c.Item1)));
   var parent=new Dictionary<CPos,CPos>();var queue=new Queue<CPos>();parent[start]=start;queue.Enqueue(start); CPos? found=null;
   while(queue.Count>0&&parent.Count<20000) {
    var c=queue.Dequeue();if((goals==null?(c-goal).LengthSquared<=goalRadius*goalRadius:goals.Contains(c))&&!blocked.Contains(c)){found=c;break;}
    foreach(var step in Steps){var n=c+step;
     if(parent.ContainsKey(n)||!world.Map.Contains(n)||(exploredOnly&&!player.Shroud.IsExplored(n))||blocked.Contains(n)||locomotor.MovementCostForCell(n)==short.MaxValue)continue;
     // Permit escape from an existing danger zone, never move deeper into it.
     if(threats.Any(d=>(n-d).LengthSquared<=100&&(n-d).LengthSquared<(c-d).LengthSquared))continue;
     parent[n]=c;queue.Enqueue(n);
    }
   }
   var path=new List<CPos>();if(!found.HasValue)return path;
   var end=found.Value;while(end!=start){path.Add(end);end=parent[end];}path.Reverse();return path;
  }
  public static bool CaptureAccess(World world,Player player,Locomotor locomotor,CPos start,CPos goal,IEnumerable<CPos> dangers){var target=world.Actors.FirstOrDefault(a=>a.IsInWorld&&!a.IsDead&&a.OccupiesSpace!=null&&a.Info.HasTraitInfo<BuildingInfo>()&&a.CanBeViewedByPlayer(player)&&a.Location==goal);
   if(target==null)return Route(world,player,locomotor,start,goal,1,dangers).Count>0;
   var cells=new HashSet<CPos>(target.OccupiesSpace.OccupiedCells().Select(c=>c.Item1));
   var goals=new HashSet<CPos>(cells.SelectMany(c=>Steps.Select(step=>c+step)).Where(c=>!cells.Contains(c)));
   return goals.Contains(start)||Route(world,player,locomotor,start,goal,0,dangers,true,goals).Count>0;}
 }
}



