using System;
using System.IO;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  internal void ProbeRecon(IBot testBot){nextReconTick=0;UpdateRecon(testBot);}
  internal int ReconProbeCount => reconGroups.Count;
  internal int ReconProbeLocal => reconGroups.Count(g=>g.Local);
  internal int ReconProbeReturning => reconGroups.Count(g=>g.RetreatUntil>World.WorldTick);
  internal CPos[] ReconProbeDestinations => reconGroups.Where(g=>g.Destination.HasValue).Select(g=>g.Destination.Value).ToArray();
  internal bool ReconProbeLocalBounded => reconGroups.Where(g=>g.Local&&g.Destination.HasValue).All(g=>(g.Destination.Value-Player.HomeLocation).LengthSquared<=1296);
 }
 public partial class AITestMetrics {
  Player reconOwn,reconEnemy; ProbeBot reconBot; int reconPeak,reconLocal,reconReturns; CPos[] reconDestinations;
  void CheckEarlyRecon(World world){
   if(world.WorldTick==2){foreach(var p in world.Players.Where(p=>p.IsBot))foreach(var b in p.PlayerActor.TraitsImplementing<ModularBot>())b.IsEnabled=false;
    world.AddFrameEndTask(w=>{
     reconOwn=w.Players.First(p=>p.IsBot&&p.BotType=="improved");reconEnemy=w.Players.First(p=>p.Playable&&p.RelationshipWith(reconOwn)==PlayerRelationship.Enemy);reconBot=new ProbeBot(reconOwn);
     var mobile=w.Map.Rules.Actors["e1"].TraitInfo<MobileInfo>();var cells=w.Map.FindTilesInAnnulus(reconOwn.HomeLocation,6,12).Where(c=>mobile.CanEnterCell(w,null,c)).Take(8).ToArray();
     if(cells.Length<8)throw new InvalidOperationException("Insufficient fixture cells");
     foreach(var c in cells)w.CreateActor("e1",new TypeDictionary{new OwnerInit(reconOwn),new LocationInit(c)});
    });
   }
   if(world.WorldTick>=100&&world.WorldTick<=850&&world.WorldTick%100==0){var m=reconOwn.PlayerActor.Trait<ImprovedSquadManagerBotModule>();m.ProbeAssignIdle(reconBot);m.ProbeRecon(reconBot);}
   if(world.WorldTick==900){var m=reconOwn.PlayerActor.Trait<ImprovedSquadManagerBotModule>();reconPeak=m.ReconProbeCount;reconLocal=m.ReconProbeLocal;reconDestinations=m.ReconProbeDestinations;
    if(EarlyReconEnabled&&(reconPeak<=4||reconLocal==0||!m.ReconProbeLocalBounded))throw new InvalidOperationException("Idle local scouting or near-base bounds failed");
    if(!EarlyReconEnabled&&reconPeak!=2)throw new InvalidOperationException("Baseline scout count changed");
    if(reconDestinations.Length<2||reconDestinations.Distinct().Count()!=reconDestinations.Length)throw new InvalidOperationException("Scout destinations missing or duplicated");
    world.AddFrameEndTask(w=>{var mobile=w.Map.Rules.Actors["3tnk"].TraitInfo<MobileInfo>();var c=w.Map.FindTilesInAnnulus(reconOwn.HomeLocation,8,10).First(t=>mobile.CanEnterCell(w,null,t));w.CreateActor("3tnk",new TypeDictionary{new OwnerInit(reconEnemy),new LocationInit(c)});w.CreateActor("camera",new TypeDictionary{new OwnerInit(reconOwn),new LocationInit(c)});});
   }
   if(world.WorldTick==1050){var m=reconOwn.PlayerActor.Trait<ImprovedSquadManagerBotModule>();reconOwn.PlayerActor.Trait<ImprovedStrategyBotModule>().ForceSituationProbe();m.ProbeRecon(reconBot);reconReturns=m.ReconProbeReturning;
    if(EarlyReconEnabled&&reconReturns!=reconPeak)throw new InvalidOperationException("Home threat did not recall every scouting group");
   }
   if(world.WorldTick==1100){var text="PASS enabled="+EarlyReconEnabled+" scouts="+reconPeak+" local="+reconLocal+" unique_destinations="+reconDestinations.Length+" recalled="+reconReturns+" destinations="+string.Join(";",reconDestinations.Select(c=>c.ToString()));File.WriteAllText(Path.Combine(Platform.SupportDir,"recon-result.txt"),text);Console.WriteLine(text);Game.Exit();}
  }
 }
}
