#region Copyright & License Information
/*
 * Copyright 2007-2020 The OpenRA Developers (see AUTHORS)
 * This file is part of OpenRA, which is free software. It is made
 * available to you under the terms of the GNU General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version. For more
 * information, see COPYING.
 */
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Mods.Common.Warheads;

namespace OpenRA.Mods.Common.Traits.AITest
{
	[Desc("Controls AI unit production.")]
	public class ImprovedUnitBuilderBotModuleInfo : ConditionalTraitInfo
	{
		// TODO: Investigate whether this might the (or at least one) reason why bots occasionally get into a state of doing nothing.
		// Reason: If this is less than SquadSize, the bot might get stuck between not producing more units due to this,
		// but also not creating squads since there aren't enough idle units.
		[Desc("Only produce units as long as there are less than this amount of units idling inside the base.")]
		public readonly int IdleBaseUnitsMaximum = 12;

		[Desc("Production queues AI uses for producing units.")]
		public readonly HashSet<string> UnitQueues = new HashSet<string> { "Vehicle", "Infantry", "Plane", "Ship", "Aircraft" };

		[Desc("What units to the AI should build.", "What relative share of the total army must be this type of unit.")]
		public readonly Dictionary<string, int> UnitsToBuild = null;

		[Desc("What units should the AI have a maximum limit to train.")]
		public readonly Dictionary<string, int> UnitLimits = null;

		[Desc("When should the AI start train specific units.")]
		public readonly Dictionary<string, int> UnitDelays = null;

		public override object Create(ActorInitializer init) { return new ImprovedUnitBuilderBotModule(init.Self, this); }
	}

	public class ImprovedUnitBuilderBotModule : ConditionalTrait<ImprovedUnitBuilderBotModuleInfo>, IBotTick, IBotNotifyIdleBaseUnits, IBotRequestUnitProduction, IGameSaveTraitData
	{
		public const int FeedbackTime = 30; // ticks; = a bit over 1s. must be >= netlag.

		readonly World world;
		readonly Player player;

		readonly List<string> queuedBuildRequests = new List<string>();

		IBotRequestPauseUnitProduction[] requestPause;
		int idleUnitCount;
        int nextProductionReasonLog;
        void LogProductionReason(string reason){
            if(world.WorldTick<nextProductionReasonLog)return;nextProductionReasonLog=world.WorldTick+250;
            var funds=player.PlayerActor.Trait<PlayerResources>();
            Console.WriteLine("AI-PRODUCTION tick="+world.WorldTick+" reason="+reason+" funds="+(funds.Cash+funds.Resources)+" idle="+idleUnitCount+" requested="+queuedBuildRequests.Count);
        }

		int ticks;

		public ImprovedUnitBuilderBotModule(Actor self, ImprovedUnitBuilderBotModuleInfo info)
			: base(info)
		{
			world = self.World;
			player = self.Owner;
		}

		protected override void Created(Actor self)
		{
			requestPause = self.Owner.PlayerActor.TraitsImplementing<IBotRequestPauseUnitProduction>().ToArray();
		}

		void IBotNotifyIdleBaseUnits.UpdatedIdleBaseUnits(List<Actor> idleUnits)
		{
			idleUnitCount = idleUnits.Count;
		}

		void IBotTick.BotTick(IBot bot)
		{
			if (requestPause.Any(rp => rp.PauseUnitProduction)){LogProductionReason("pause_requested");return;}

			ticks++;

			if (ticks % FeedbackTime == 0)
			{
				if(idleUnitCount>=Info.IdleBaseUnitsMaximum)LogProductionReason("idle_reserve_limit");
                var buildRequest = queuedBuildRequests.FirstOrDefault();
				if (buildRequest != null)
				{
					if (BuildUnit(bot, buildRequest))
						queuedBuildRequests.Remove(buildRequest);
				}

				foreach (var q in Info.UnitQueues)
					BuildUnit(bot, q, idleUnitCount < Info.IdleBaseUnitsMaximum);
			}
		}

		void IBotRequestUnitProduction.RequestUnitProduction(IBot bot, string requestedActor)
		{
			queuedBuildRequests.Add(requestedActor);
		}

		int IBotRequestUnitProduction.RequestedProductionCount(IBot bot, string requestedActor)
		{
			return queuedBuildRequests.Count(r => r == requestedActor);
		}

		void BuildUnit(IBot bot, string category, bool buildRandom)
		{
            var expansion = player.PlayerActor.TraitOrDefault<ImprovedMcvManagerBotModule>();
            if (expansion != null && expansion.SavingForExpansion() && !queuedBuildRequests.Contains("mcv")){LogProductionReason("expansion_reserve");return;}			// Pick a free queue
			var queue = LegacyAIUtils.FindQueues(player, category).FirstOrDefault(q => !q.AllQueued().Any());
			if (queue == null){LogProductionReason("no_free_queue:"+category);return;}

			var unit = buildRandom ?
				ChooseRandomUnitToBuild(queue) :
				ChooseUnitToBuild(queue);

			if (unit == null){LogProductionReason("no_eligible_unit:"+category);return;}

			var name = unit.Name;

			if (Info.UnitsToBuild != null && !Info.UnitsToBuild.ContainsKey(name))
				return;

			if (Info.UnitDelays != null &&
				Info.UnitDelays.ContainsKey(name) &&
				Info.UnitDelays[name] > world.WorldTick)
				return;

			if (Info.UnitLimits != null &&
				Info.UnitLimits.ContainsKey(name) &&
				world.Actors.Count(a => a.Owner == player && a.Info.Name == name) >= Info.UnitLimits[name])
				return;

			bot.QueueOrder(Order.StartProduction(queue.Actor, name, 1));
		}

		// In cases where we want to build a specific unit but don't know the queue name (because there's more than one possibility)
		bool BuildUnit(IBot bot, string name)
		{
			var actorInfo = world.Map.Rules.Actors[name];
            var navalPolicy=player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>();if(navalPolicy!=null&&!navalPolicy.AllowNavalInvestment(actorInfo))return false;
			if (actorInfo == null)
				return false;

			var buildableInfo = actorInfo.TraitInfoOrDefault<BuildableInfo>();
			if (buildableInfo == null)
				return false;

			ProductionQueue queue = null;
			foreach (var pq in buildableInfo.Queue)
			{
				queue = LegacyAIUtils.FindQueues(player, pq).FirstOrDefault(q => !q.AllQueued().Any() && q.BuildableItems().Any(a => a.Name == name));
				if (queue != null)
					break;
			}

			if (queue != null)
			{
				bot.QueueOrder(Order.StartProduction(queue.Actor, name, 1));
				LegacyAIUtils.BotDebug("{0} decided to build {1} (external request)", queue.Actor.Owner, name);
                return true;
			}
            return false;
		}

		ActorInfo ChooseRandomUnitToBuild(ProductionQueue queue) { return ChooseUnitToBuild(queue); }

        ActorInfo ChooseUnitToBuild(ProductionQueue queue)
        {
            var candidates = queue.BuildableItems().Where(a => Info.UnitsToBuild.ContainsKey(a.Name))
                .Where(a => Info.UnitLimits == null || !Info.UnitLimits.ContainsKey(a.Name) ||
                    world.Actors.Count(u => u.Owner == player && u.Info.Name == a.Name) < Info.UnitLimits[a.Name])
                .Where(a => Info.UnitDelays == null || !Info.UnitDelays.ContainsKey(a.Name) || Info.UnitDelays[a.Name] <= world.WorldTick)
                .Where(HasAdequateAirUnitReloadBuildings).Where(a=>{var policy=player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>();return policy==null||policy.AllowNavalInvestment(a);}).ToArray();
            if (candidates.Length == 0) return null;
            var own = world.Actors.Where(a => a.Owner == player && a.Info.HasTraitInfo<IPositionableInfo>()).ToArray();
            var enemies = world.Actors.Where(a => player.RelationshipWith(a.Owner) == PlayerRelationship.Enemy && a.CanBeViewedByPlayer(player)).ToArray();
            var dangerous = enemies.Where(a => a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
            var strategy = player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>(); if (strategy != null) strategy.Refresh();
            var matchup = candidates.ToDictionary(c => c.Name, c => strategy == null ? dangerous.Sum(e => CounterScore(c, e)) : strategy.KnownEnemies.Where(e => e.Armed).Sum(e => RememberedCounterScore(c, e)));
            var maxMatchup = matchup.Values.DefaultIfEmpty(0).Max();            var enemyAir = enemies.Count(a => a.Info.HasTraitInfo<AircraftInfo>());
            var enemyInfantry = enemies.Count(a => a.Info.HasTraitInfo<MobileInfo>() && a.Info.TraitInfo<MobileInfo>().Locomotor == "foot");
            var enemyVehicles = enemies.Count(a => a.Info.HasTraitInfo<MobileInfo>() && a.Info.TraitInfo<MobileInfo>().Locomotor != "foot" && !a.Info.HasTraitInfo<AircraftInfo>());
            return candidates.OrderByDescending(a =>
            {
                var count = own.Count(u => u.Info.Name == a.Name);
                double desired = Info.UnitsToBuild[a.Name];
                if (maxMatchup > 0) desired *= 1 + (strategy != null && (strategy.Plan == StrategicPlan.BuildCounters || strategy.Plan == StrategicPlan.Defend) ? 6 : 3) * matchup[a.Name] / maxMatchup;
                if (a.Name == "e3" || a.Name == "ftrk") desired *= 1.0 + Math.Min(2.0, enemyAir / 3.0);
                if (a.Name == "e1" || a.Name == "apc" || a.Name == "arty" || a.Name == "v2rl") desired *= 1.0 + Math.Min(1.5, enemyInfantry / 12.0);
                if (a.Name == "e3" || a.Name == "2tnk" || a.Name == "3tnk") desired *= 1.0 + Math.Min(1.5, enemyVehicles / 8.0);
                                if (a.Name == "harv") {
                    var cap = strategy != null && !strategy.OpeningSecured ? 3 : Math.Min(8, world.Actors.Count(u => u.Owner == player && u.Info.Name == "proc") * 2);
                    desired = own.Count(u => u.Info.Name == "harv") < cap ? 500 : 0;
                }
                if (strategy != null && !strategy.OpeningSecured && a.Name != "harv") {
                    if (a.HasTraitInfo<AttackBaseInfo>()) desired *= a.Name == "e3" || a.Name == "1tnk" || a.Name == "2tnk" ? 2.5 : 1.5;
                    else desired *= 0.25;
                }
                return desired / (1 + count) * (0.95 + world.LocalRandom.Next(10) / 100.0);
            }).First();
        }
        double RememberedCounterScore(ActorInfo candidate, ImprovedStrategyBotModule.Observation enemy)
        {
            double damage = 0;
            var range = enemy.Info.TraitInfos<ArmamentInfo>().Select(a => world.Map.Rules.Weapons[a.Weapon.ToLowerInvariant()].Range.Length).DefaultIfEmpty(0).Max();
            foreach (var arm in candidate.TraitInfos<ArmamentInfo>())
            {
                var weapon = world.Map.Rules.Weapons[arm.Weapon.ToLowerInvariant()];
                if (!weapon.IsValidTarget(enemy.TargetTypes)) continue;
                foreach (var warhead in weapon.Warheads.OfType<DamageWarhead>())
                    damage += Math.Max(0, warhead.Damage) * (enemy.Armor != null && warhead.Versus.ContainsKey(enemy.Armor) ? warhead.Versus[enemy.Armor] / 100.0 : 1) * weapon.Burst /
                        Math.Max(1, weapon.ReloadDelay + weapon.BurstDelays.FirstOrDefault() * (weapon.Burst - 1)) * (weapon.Range.Length > range ? 1.5 : 1);
            }
            return damage * enemy.Value / (candidate.TraitInfoOrDefault<ValuedInfo>() == null ? 1000 : Math.Max(200, candidate.TraitInfo<ValuedInfo>().Cost));
        }
        double CounterScore(ActorInfo candidate, Actor enemy)
        {
            double damage = 0;
            var armor = enemy.TraitsImplementing<Armor>().Where(a => !a.IsTraitDisabled).Select(a => a.Info.Type).FirstOrDefault();
            foreach (var arm in candidate.TraitInfos<ArmamentInfo>())
            {
                var weapon = world.Map.Rules.Weapons[arm.Weapon.ToLowerInvariant()];
                if (!weapon.IsValidTarget(enemy.GetEnabledTargetTypes())) continue;
                var range = enemy.TraitsImplementing<Armament>().Select(a => a.Weapon.Range.Length).DefaultIfEmpty(0).Max();
                foreach (var warhead in weapon.Warheads.OfType<DamageWarhead>())
                    damage += Math.Max(0, warhead.Damage) * (armor != null && warhead.Versus.ContainsKey(armor) ? warhead.Versus[armor] / 100.0 : 1) * weapon.Burst /
                        Math.Max(1, weapon.ReloadDelay + weapon.BurstDelays.FirstOrDefault() * (weapon.Burst - 1)) * (weapon.Range.Length > range ? 1.5 : 1);
            }
            return damage * Math.Max(1, enemy.GetSellValue()) / (candidate.TraitInfoOrDefault<ValuedInfo>() == null ? 1000 : Math.Max(200, candidate.TraitInfo<ValuedInfo>().Cost));
        }
// For mods like RA (number of RearmActors must match the number of aircraft)
		bool HasAdequateAirUnitReloadBuildings(ActorInfo actorInfo)
		{
			var aircraftInfo = actorInfo.TraitInfoOrDefault<AircraftInfo>();
			if (aircraftInfo == null)
				return true;

			// If actor isn't Rearmable, it doesn't need a RearmActor to reload
			var rearmableInfo = actorInfo.TraitInfoOrDefault<RearmableInfo>();
			if (rearmableInfo == null)
				return true;

			var countOwnAir = LegacyAIUtils.CountActorsWithTrait<IPositionable>(actorInfo.Name, player);
			var countBuildings = rearmableInfo.RearmActors.Sum(b => LegacyAIUtils.CountActorsWithTrait<Building>(b, player));
			if (countOwnAir >= countBuildings)
				return false;

			return true;
		}

		List<MiniYamlNode> IGameSaveTraitData.IssueTraitData(Actor self)
		{
			if (IsTraitDisabled)
				return null;

			return new List<MiniYamlNode>()
			{
				new MiniYamlNode("QueuedBuildRequests", FieldSaver.FormatValue(queuedBuildRequests.ToArray())),
				new MiniYamlNode("IdleUnitCount", FieldSaver.FormatValue(idleUnitCount))
			};
		}

		void IGameSaveTraitData.ResolveTraitData(Actor self, MiniYaml yaml)
        { var data = yaml.Nodes;
		
			if (self.World.IsReplay)
				return;

			var queuedBuildRequestsNode = data.FirstOrDefault(n => n.Key == "QueuedBuildRequests");
			if (queuedBuildRequestsNode != null)
			{
				queuedBuildRequests.Clear();
				queuedBuildRequests.AddRange(FieldLoader.GetValue<string[]>("QueuedBuildRequests", queuedBuildRequestsNode.Value.Value));
			}

			var idleUnitCountNode = data.FirstOrDefault(n => n.Key == "IdleUnitCount");
			if (idleUnitCountNode != null)
				idleUnitCount = FieldLoader.GetValue<int>("IdleUnitCount", idleUnitCountNode.Value.Value);
		}
	}
}





