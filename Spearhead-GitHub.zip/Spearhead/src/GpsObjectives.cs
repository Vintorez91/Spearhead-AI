using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedStrategyBotModule {
  public CPos[] GpsContacts { get; private set; } = new CPos[0];
  int nextGpsLog;
  void RefreshGpsContacts() {
   // Cnc GPS traits are internal. Read their public state, without adding a dependency
   // on a different Cnc build or exposing actor identity, health or weapon information.
   var watcher=player.PlayerActor.TraitsImplementing<object>().FirstOrDefault(t=>t.GetType().Name=="GpsWatcher");
   Func<string,bool> granted=n=>watcher!=null && (bool)(watcher.GetType().GetProperty(n).GetValue(watcher,null));
   GpsContacts = !granted("Granted")&&!granted("GrantedAllies") ? new CPos[0] : world.Actors
    .Where(a=>a.IsInWorld&&!a.IsDead&&a.OccupiesSpace!=null&&player.RelationshipWith(a.EffectiveOwner!=null&&a.EffectiveOwner.Owner!=null?a.EffectiveOwner.Owner:a.Owner)==PlayerRelationship.Enemy)
    .Where(a=>a.TraitsImplementing<object>().Any(t=>t.GetType().Name=="GpsDot") && player.Shroud.IsExplored(a.Location)
      && a.TraitsImplementing<IVisibilityModifier>().All(v=>v.IsVisible(a,player)))
    .Select(a=>a.Location).Distinct().ToArray();
   if(world.WorldTick>=nextGpsLog){nextGpsLog=world.WorldTick+750;Console.WriteLine("AI-GPS player="+player.InternalName+" active="+(granted("Granted")||granted("GrantedAllies"))+" contacts="+GpsContacts.Length);}
  }
 }
 public partial class ImprovedSquadManagerBotModule {
  readonly Dictionary<Squad,int> locationOrderAt=new Dictionary<Squad,int>();
  internal bool ApproachKnownLocation(Squad squad) {
   var strategy=Strategy; if(strategy==null||strategy.HoldingOffense||OffenseRegrouping||!squad.IsValid||squad.Type!=SquadType.Assault)return false;
   strategy.Refresh(); var leader=squad.Units.FirstOrDefault(a=>a.TraitOrDefault<Mobile>()!=null);if(leader==null)return false;
   var goals=strategy.KnownEnemies.Where(o=>o.Building&&!Player.Shroud.IsVisible(o.Position))
    .OrderByDescending(o=>new[]{"fact","weap","proc"}.Contains(o.Info.Name)).Select(o=>o.Position)
    .Concat(strategy.GpsContacts.Where(c=>!Player.Shroud.IsVisible(c))).Distinct().ToArray();
   if(goals.Length==0){LogAttackWait(squad,"no_known_location",0);return false;}
   int ordered; if(locationOrderAt.TryGetValue(squad,out ordered)&&World.WorldTick-ordered<150)return true;
   var dangers=strategy.KnownEnemies.Where(o=>o.Armed&&o.Building&&World.WorldTick-o.Seen<=7500).Select(o=>o.Position).ToArray();
   foreach(var goal in goals.Take(24)) {
    leader=squad.Units.Where(a=>a.TraitOrDefault<Mobile>()!=null).OrderBy(a=>(a.Location-goal).LengthSquared).First();
    if((goal-leader.Location).LengthSquared<=9)continue;
    var path=FairNavigation.Route(World,Player,leader.Trait<Mobile>().Locomotor,leader.Location,goal,3,dangers);
    if(path.Count==0)continue;
    var waypoint=path[Math.Min(7,path.Count-1)];
    // Location order only: actual target selection and combat safety remain unchanged.
    bot.QueueOrder(new Order("AttackMove",null,Target.FromCell(World,waypoint),false,groupedActors:squad.Units.ToArray()));
    locationOrderAt[squad]=World.WorldTick;
    TraceAttack(squad,"location_advance","waypoint="+waypoint,goal,strategy.KnownEnemies.Any(o=>o.Building&&o.Position==goal)?"remembered_building":"gps_contact");
    Console.WriteLine("AI-LOCATION player="+Player.InternalName+" goal="+goal+" waypoint="+waypoint+" units="+squad.Units.Count);
    return true;
   }
   LogAttackWait(squad,"known_location_route_blocked",0);return false;
  }
 }
}

