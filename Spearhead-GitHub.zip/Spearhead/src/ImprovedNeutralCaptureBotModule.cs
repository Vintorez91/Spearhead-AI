using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest
{
    public class ImprovedNeutralCaptureBotModuleInfo : ConditionalTraitInfo
    {
        public override object Create(ActorInitializer init) { return new ImprovedNeutralCaptureBotModule(init.Self, this); }
    }
    public class ImprovedNeutralCaptureBotModule : ConditionalTrait<ImprovedNeutralCaptureBotModuleInfo>, IBotTick
    {
        readonly World world;
        readonly Player player;
        sealed class Site { public uint Id; public CPos Position; public bool Income; }
        readonly Dictionary<uint, Site> known = new Dictionary<uint, Site>();
        readonly Dictionary<Actor, uint> assignments = new Dictionary<Actor, uint>();
        readonly Dictionary<uint, int> unsafeUntil = new Dictionary<uint, int>();
        int nextTick; int nextEngineerRequest;
        public ImprovedNeutralCaptureBotModule(Actor self, ImprovedNeutralCaptureBotModuleInfo info) : base(info) { world = self.World; player = self.Owner; }
        public bool EngineerAssigned(Actor a){return assignments.ContainsKey(a);}
        internal CPos CaptureOrigin(Locomotor locomotor,bool ignoreEngineers=false){
            var engineer=world.Actors.FirstOrDefault(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead&&a.Info.Name=="e6"&&!player.PlayerActor.Trait<ImprovedSquadManagerBotModule>().EngineerRaidOwns(a));
            if(!ignoreEngineers&&engineer!=null)return engineer.Location;
            var blocked=new HashSet<CPos>(world.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&a.OccupiesSpace!=null&&!a.Info.HasTraitInfo<MobileInfo>()&&!a.Info.HasTraitInfo<AircraftInfo>()&&(a.Owner==player||a.CanBeViewedByPlayer(player))).SelectMany(a=>a.OccupiesSpace.OccupiedCells().Select(c=>c.Item1)));
            return world.Map.FindTilesInCircle(player.HomeLocation,8).Where(c=>player.Shroud.IsExplored(c)&&!blocked.Contains(c)&&locomotor.MovementCostForCell(c)<short.MaxValue).OrderBy(c=>(c-player.HomeLocation).LengthSquared).Select(c=>(CPos?)c).FirstOrDefault()??player.HomeLocation;
        }
        void IBotTick.BotTick(IBot bot)
        {
            if (world.WorldTick < nextTick) return;
            nextTick = world.WorldTick + 75;
            var visible = world.Actors.Where(a => a.CanBeViewedByPlayer(player) && !a.IsDead && a.IsInWorld && a.Info.HasTraitInfo<CapturableInfo>()).ToArray();
            foreach (var a in visible)
                if (player.RelationshipWith(a.Owner) == PlayerRelationship.Neutral)
                {
                    if (!known.ContainsKey(a.ActorID)) Console.WriteLine("AI-CAPTURE discovered " + a.Info.Name + " at " + a.Location);
                    known[a.ActorID] = new Site { Id = a.ActorID, Position = a.Location, Income = a.Info.HasTraitInfo<CashTricklerInfo>() };
                }
                else { if (a.Owner == player && known.ContainsKey(a.ActorID)) Console.WriteLine("AI-CAPTURE captured " + a.Info.Name + " at " + a.Location); known.Remove(a.ActorID); }
            foreach (var site in known.Values.ToArray())
                if (player.Shroud.IsVisible(site.Position) && !visible.Any(a => a.ActorID == site.Id)) known.Remove(site.Id);
                        foreach (var a in assignments.Keys.Where(a => a.IsDead || !a.IsInWorld || a.Owner != player || !known.ContainsKey(assignments[a])).ToArray()) {
                var id = assignments[a];
                if ((a.IsDead || a.Owner != player) && known.ContainsKey(id)) {
                    unsafeUntil[id] = world.WorldTick + 2250;
                    Console.WriteLine("AI-CAPTURE blocked target=" + id + " until=" + unsafeUntil[id] + " reason=engineer_lost");
                }
                assignments.Remove(a);
            }
            var engineers = world.Actors.Where(a => a.Owner == player && !a.IsDead && a.IsInWorld && a.Info.Name == "e6" && !player.PlayerActor.Trait<ImprovedSquadManagerBotModule>().EngineerRaidOwns(a)).ToArray();
            var dangers = world.Actors.Where(a => a.CanBeViewedByPlayer(player) && !a.IsDead && a.IsInWorld && a.OccupiesSpace != null && a.Info.HasTraitInfo<AttackBaseInfo>() && player.RelationshipWith(a.Owner) == PlayerRelationship.Enemy).ToArray();
                        var engineerInfo = world.Map.Rules.Actors["e6"].TraitInfo<MobileInfo>();
            var locomotor = world.WorldActor.TraitsImplementing<Locomotor>().First(l => l.Info.Name == engineerInfo.Locomotor);
            var domainIndex = new DomainIndex(world);
            var origin = CaptureOrigin(locomotor);
            var safe = known.Values.Where(s => !unsafeUntil.ContainsKey(s.Id) || world.WorldTick >= unsafeUntil[s.Id])
                .Where(s => domainIndex.IsPassable(origin, s.Position, locomotor) && dangers.All(a => (a.Location - s.Position).LengthSquared > 144 && SafeRoute(origin, s.Position, a.Location)))
                .OrderByDescending(s => s.Income).Where(s => FairNavigation.CaptureAccess(world,player,locomotor,origin,s.Position,dangers.Select(a=>a.Location))).ToArray();
            foreach (var engineer in engineers)
            {
                if (dangers.Any(a => (a.CenterPosition - engineer.CenterPosition).LengthSquared < 64L * 1024 * 1024))
                                { uint abandoned; if(assignments.TryGetValue(engineer,out abandoned)) { unsafeUntil[abandoned]=world.WorldTick+2250; Console.WriteLine("AI-CAPTURE blocked target="+abandoned+" until="+unsafeUntil[abandoned]+" reason=route_threat"); }
                  bot.QueueOrder(new Order("Move", engineer, Target.FromCell(world, player.HomeLocation), false)); assignments.Remove(engineer); continue; }
                var mobile = engineer.Trait<Mobile>();
                var domain = new DomainIndex(world);
                var site = safe.Where(s => !assignments.Any(kv => kv.Key != engineer && kv.Value == s.Id) && domain.IsPassable(engineer.Location, s.Position, mobile.Locomotor) && dangers.All(a => SafeRoute(engineer.Location, s.Position, a.Location)))
                    .OrderByDescending(s => s.Income).ThenBy(s => (s.Position - engineer.Location).LengthSquared).FirstOrDefault();
                                if (site == null) {
                    uint abandoned;
                    if(assignments.TryGetValue(engineer,out abandoned)) {
                        unsafeUntil[abandoned]=world.WorldTick+2250;
                        Console.WriteLine("AI-CAPTURE blocked target="+abandoned+" until="+unsafeUntil[abandoned]+" reason=no_safe_route");
                        bot.QueueOrder(new Order("Move",engineer,Target.FromCell(world,player.HomeLocation),false));assignments.Remove(engineer);
                    }
                    continue;
                }
                if (!engineer.IsIdle && assignments.ContainsKey(engineer) && assignments[engineer] == site.Id) continue;
                var target = visible.FirstOrDefault(a => a.ActorID == site.Id);
                if (target != null && engineer.Trait<CaptureManager>().CanTarget(target.Trait<CaptureManager>()))
                { bot.QueueOrder(new Order("CaptureActor", engineer, Target.FromActor(target), false)); Console.WriteLine("AI-CAPTURE engineer ordered to " + target.Info.Name + " at " + site.Position); }
                else bot.QueueOrder(new Order("Move", engineer, Target.FromCell(world, site.Position), false));
                assignments[engineer] = site.Id;
            }
            var strategy = player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>(); if (strategy != null) strategy.Refresh();
            var money = player.PlayerActor.Trait<PlayerResources>();
            var builder = player.PlayerActor.TraitsImplementing<IBotRequestUnitProduction>().FirstOrDefault(Exts.IsTraitEnabled);
            // Up to two early income investments, each backed by a distinct safe oil target.

            var earlyIncome = engineers.Length < 2 && strategy != null && strategy.CombatCount >= 3
                && strategy.Plan != StrategicPlan.Defend && strategy.AllyEnemies.Length == 0
                && money.Cash + money.Resources >= 1500
                && safe.Count(s => s.Income && visible.Any(a => a.ActorID == s.Id)
                    && (s.Position - origin).LengthSquared <= 900
                    && domainIndex.IsPassable(origin, s.Position, locomotor)
                    && dangers.All(a => SafeRoute(origin, s.Position, a.Location))) > engineers.Length;
            if (world.WorldTick >= nextEngineerRequest && (strategy == null || strategy.MayCapture || earlyIncome) && builder != null && safe.Length > engineers.Length && engineers.Length < 2 && money.Cash + money.Resources >= 800 && builder.RequestedProductionCount(bot, "e6") == 0 && LegacyAIUtils.FindQueues(player, "Infantry").Any(q => q.BuildableItems().Any(a => a.Name == "e6")))
            { nextEngineerRequest = world.WorldTick + (earlyIncome ? 250 : 750); builder.RequestUnitProduction(bot, "e6"); Console.WriteLine("AI-CAPTURE player="+player.InternalName+" requesting engineer origin="+origin+" safe_targets="+safe.Length); }
        }
        static bool SafeRoute(CPos start, CPos end, CPos danger)
        {
            var dx = end.X - start.X; var dy = end.Y - start.Y;
            var length = dx * dx + dy * dy;
            var t = length == 0 ? 0 : Math.Max(0, Math.Min(1, ((danger.X - start.X) * dx + (danger.Y - start.Y) * dy) / (double)length));
            var x = danger.X - start.X - t * dx; var y = danger.Y - start.Y - t * dy;
            return x * x + y * y > 64;
        }
    }
}








