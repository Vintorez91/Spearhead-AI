using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class AITestMetrics {
  public static bool ControlEnabled;
  string controlDir,controlSession; StreamWriter controlLog;
  readonly Dictionary<Player,int> manualTokens=new Dictionary<Player,int>();
  readonly Dictionary<Player,ModularBot> easyBots=new Dictionary<Player,ModularBot>();
  readonly Dictionary<Player,int> manualExpiry=new Dictionary<Player,int>();
  int nextControlSnapshot;
  void InitializeControl(World w) {
   if(!ControlEnabled||w.IsReplay)return;
   controlDir=Path.Combine(Platform.SupportDir,"Control");Directory.CreateDirectory(Path.Combine(controlDir,"Inbox"));
   controlSession=Guid.NewGuid().ToString("N");File.WriteAllText(Path.Combine(controlDir,"session.txt"),controlSession);
   controlLog=new StreamWriter(Path.Combine(controlDir,"commands-"+controlSession+".csv")){AutoFlush=true};controlLog.WriteLine("tick,id,player,action,status,detail");
   Console.WriteLine("AI-CONTROL enabled session="+controlSession);ControlSnapshot(w);
  }
  void ControlTick(World w) {
      if(controlDir==null)return;
   foreach(var p in w.Players.Where(p=>p.Playable&&p.IsBot&&p.BotType=="easy")) {
    ModularBot easy;if(!easyBots.TryGetValue(p,out easy)){easy=p.PlayerActor.TraitsImplementing<ModularBot>().FirstOrDefault(b=>b.IsEnabled);if(easy!=null)easyBots[p]=easy;}
    if(easy!=null)easy.IsEnabled=w.WorldTick%300<100;
   }
   foreach(var p in manualExpiry.Keys.Where(p=>w.WorldTick>=manualExpiry[p]).ToArray())ReleaseControl(p,w,"lease_expired");
   if(w.WorldTick%5==0)foreach(var file in Directory.GetFiles(Path.Combine(controlDir,"Inbox"),"*.cmd").OrderBy(f=>f).Take(16)) {
    var id=Path.GetFileNameWithoutExtension(file);string player="",action="";
    try {
     var parts=File.ReadAllText(file).Trim().Split('|');if(parts.Length!=9)throw new InvalidOperationException("Expected nine fields");
     if(parts[0]!=controlSession)throw new InvalidOperationException("Wrong game session");
     player=parts[1];action=parts[2];var p=w.Players.FirstOrDefault(a=>a.InternalName==player&&a.Playable&&a==w.LocalPlayer&&!a.IsBot);
     if(p==null)throw new InvalidOperationException("Unknown local player");
     if(action=="takeover") {
      if(!manualTokens.ContainsKey(p)){manualTokens[p]=p.PlayerActor.GrantCondition("aitest-external-control");TextNotificationsManager.AddSystemLine("AI Testlab",p.InternalName+": externe besturing actief; geen zuivere AI-test.");}
      manualExpiry[p]=w.WorldTick+7500;
      // This is a human player: preserve current orders, especially automatic harvesting.
     } else if(action=="release")ReleaseControl(p,w,"released");
     else {
      if(!manualTokens.ContainsKey(p))throw new InvalidOperationException("Take over this player first");
            if(action=="produce"||action=="place"||action=="placeauto") {
       var type=parts[7].ToLowerInvariant();ActorInfo info;if(!w.Map.Rules.Actors.TryGetValue(type,out info))throw new InvalidOperationException("Unknown production type");
       var queues=w.Actors.Where(o=>o.Owner==p&&o.IsInWorld&&!o.IsDead).SelectMany(o=>o.TraitsImplementing<ProductionQueue>()).Where(q=>q.Enabled).ToArray();
       if(action=="produce") {
        var queue=queues.FirstOrDefault(q=>q.BuildableItems().Any(i=>i.Name==type));if(queue==null)throw new InvalidOperationException("Item is not buildable");
        if(queues.Any(q=>q.AllQueued().Any(i=>i.Item==type)))throw new InvalidOperationException("This item is already queued");
        w.IssueOrder(Order.StartProduction(queue.Actor,type,1));
       } else {
        var queue=queues.FirstOrDefault(q=>q.AllQueued().Any(i=>i.Item==type&&i.Done));if(queue==null)throw new InvalidOperationException("Building is not ready");
        int x,y;if(!int.TryParse(parts[4],out x)||!int.TryParse(parts[5],out y))throw new InvalidOperationException("Invalid coordinates");        var cell=new CPos(x,y);var building=info.TraitInfoOrDefault<BuildingInfo>();
        if(action=="placeauto")cell=w.Map.FindTilesInAnnulus(p.HomeLocation,4,20).Where(c=>p.Shroud.IsExplored(c)&&building!=null&&w.CanPlaceBuilding(c,info,building,null)&&building.IsCloseEnoughToBase(w,p,info,c)).Select(c=>(CPos?)c).FirstOrDefault()??cell;
        if(building==null||!w.Map.Contains(cell)||!p.Shroud.IsExplored(cell)||!w.CanPlaceBuilding(cell,info,building,null)||!building.IsCloseEnoughToBase(w,p,info,cell))throw new InvalidOperationException("Invalid building placement");
        w.IssueOrder(new Order("PlaceBuilding",p.PlayerActor,Target.FromCell(w,cell),false){TargetString=type,ExtraData=queue.Actor.ActorID});
       }
       manualExpiry[p]=w.WorldTick+7500;controlLog.WriteLine(Csv(w.WorldTick,id,player,action,"accepted","queued through OpenRA orders"));File.Delete(file);continue;
      }
      uint actorId;if(!uint.TryParse(parts[3],out actorId))throw new InvalidOperationException("Invalid actor ID");
      var a=w.Actors.FirstOrDefault(o=>o.ActorID==actorId&&o.Owner==p&&o.IsInWorld&&!o.IsDead&&o.OccupiesSpace!=null);
      if(a==null)throw new InvalidOperationException("Actor unavailable or belongs to another player");
      Order order;
      if(action=="move"||action=="attackmove") {
       int x,y;if(!int.TryParse(parts[4],out x)||!int.TryParse(parts[5],out y))throw new InvalidOperationException("Invalid coordinates");
       var cell=new CPos(x,y);if(!w.Map.Contains(cell))throw new InvalidOperationException("Destination outside map");
       if(!a.Info.HasTraitInfo<MobileInfo>()&&!a.Info.HasTraitInfo<AircraftInfo>())throw new InvalidOperationException("Actor cannot move");
       order=new Order(action=="move"?"Move":"AttackMove",a,Target.FromCell(w,cell),false);
      } else if(action=="attack"||action=="capture"||action=="repair") {
       uint targetId;if(!uint.TryParse(parts[6],out targetId))throw new InvalidOperationException("Invalid target ID");
       var target=w.Actors.FirstOrDefault(o=>o.ActorID==targetId&&o.IsInWorld&&!o.IsDead&&o.OccupiesSpace!=null&&o.CanBeViewedByPlayer(p));
       if(target==null)throw new InvalidOperationException("Target is not visible or unavailable");
       if(action=="attack"&&(p.RelationshipWith(target.Owner)!=PlayerRelationship.Enemy||!a.Info.HasTraitInfo<AttackBaseInfo>()||!Squads.AttackOrFleeFuzzy.SuitableAttacker(a,target)))throw new InvalidOperationException("Unsuitable attack target");
       if(action=="capture"&&(a.TraitOrDefault<CaptureManager>()==null||target.TraitOrDefault<CaptureManager>()==null||!a.Trait<CaptureManager>().CanTarget(target.Trait<CaptureManager>())))throw new InvalidOperationException("Cannot capture target");
       if(action=="repair"&&(target.Owner!=p||a.TraitOrDefault<Repairable>()==null||!a.Trait<Repairable>().Info.RepairActors.Contains(target.Info.Name)))throw new InvalidOperationException("Cannot repair here");
       order=new Order(action=="attack"?"Attack":action=="capture"?"CaptureActor":"Repair",a,Target.FromActor(target),false);
      } else if(action=="stop")order=new Order("Stop",a,false);
      else if(action=="deploy") {if(!a.Info.HasTraitInfo<TransformsInfo>())throw new InvalidOperationException("Actor cannot deploy");order=new Order("DeployTransform",a,false);}
      else throw new InvalidOperationException("Unsupported action");
      w.IssueOrder(order);manualExpiry[p]=w.WorldTick+7500;
     }
     controlLog.WriteLine(Csv(w.WorldTick,id,player,action,"accepted","queued through OpenRA orders"));
    } catch(Exception e){controlLog.WriteLine(Csv(w.WorldTick,id,player,action,"rejected",e.Message));}
    File.Delete(file);
   }
   if(w.WorldTick>=nextControlSnapshot){nextControlSnapshot=w.WorldTick+25;try{ControlSnapshot(w);}catch(IOException){ /* Reader holds a file: retry on the next snapshot. */ }}
  }
  void ReleaseControl(Player p,World w,string reason) {
   int token;if(manualTokens.TryGetValue(p,out token)){p.PlayerActor.RevokeCondition(token);manualTokens.Remove(p);manualExpiry.Remove(p);controlLog.WriteLine(Csv(w.WorldTick,"",p.InternalName,"release","accepted",reason));}
  }
  void ControlSnapshot(World w) {
   var temp=Path.Combine(controlDir,"state.tmp");
   using(var log=new StreamWriter(temp)) {
    log.WriteLine("session,tick,viewer,manual,id,type,owner,x,y,hp,max_hp,idle,activity");
    foreach(var p in w.Players.Where(a=>a.Playable&&a==w.LocalPlayer))foreach(var a in w.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&a.OccupiesSpace!=null&&(a.Owner==p||a.CanBeViewedByPlayer(p)))) {
     var hp=a.TraitOrDefault<Health>();log.WriteLine(Csv(controlSession,w.WorldTick,p.InternalName,manualTokens.ContainsKey(p),a.ActorID,a.Info.Name,a.Owner.InternalName,a.Location.X,a.Location.Y,hp==null?0:hp.HP,hp==null?0:hp.MaxHP,a.IsIdle,a.CurrentActivity==null?"":a.CurrentActivity.GetType().Name));
    }
   }
      using(var log=new StreamWriter(Path.Combine(controlDir,"economy.csv"))) {
    log.WriteLine("session,tick,player,cash,resources,queued_type,done");
    foreach(var p in w.Players.Where(p=>p.Playable&&p==w.LocalPlayer)) {
     var money=p.PlayerActor.TraitOrDefault<PlayerResources>();
     log.WriteLine(Csv(controlSession,w.WorldTick,p.InternalName,money==null?0:money.Cash,money==null?0:money.Resources,"",""));
     foreach(var q in w.Actors.Where(a=>a.Owner==p&&a.IsInWorld&&!a.IsDead).SelectMany(a=>a.TraitsImplementing<ProductionQueue>()).Where(q=>q.Enabled))foreach(var item in q.AllQueued())log.WriteLine(Csv(controlSession,w.WorldTick,p.InternalName,"","",item.Item,item.Done));
    }
   }
   var target=Path.Combine(controlDir,"state.csv");if(File.Exists(target))File.Replace(temp,target,null);else File.Move(temp,target);
  }
 }
}






