using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  int offenseHoldUntil, offenseRejectedValue; readonly Dictionary<Squad,int> nextRouteTrace=new Dictionary<Squad,int>();
  readonly Dictionary<Squad,int> committedAttack=new Dictionary<Squad,int>();
  internal bool OffenseRegrouping {get{return World.WorldTick<offenseHoldUntil || (World.WorldTick<offenseHoldUntil+1500 && Strategy!=null && Strategy.EstimatedLandArmy<offenseRejectedValue*1.15);}}
  internal void HoldRejectedAttack(Squad squad) {
   if(squad.Units.Count<8 || (harassment.ContainsKey(squad)&&harassment[squad]))return;
   var strength=Strategy==null?0:Strategy.EstimatedLandArmy;
   offenseHoldUntil=World.WorldTick+750;offenseRejectedValue=strength;
   Console.WriteLine("AI-STABILITY regroup until="+offenseHoldUntil+" army="+strength);
  }
  bool OffensiveRouteReady(Squad squad,Actor target,out List<CPos> path) {
   path=new List<CPos>();var unit=squad.Units.Where(a=>!a.IsDead&&a.IsInWorld&&a.TraitOrDefault<Mobile>()!=null).OrderBy(a=>(a.Location-target.Location).LengthSquared).FirstOrDefault();if(unit==null)return false;
   var mobile=unit.TraitOrDefault<Mobile>();if(mobile==null)return true;
   var guards=Strategy==null?new ImprovedStrategyBotModule.Observation[0]:Strategy.KnownEnemies.Where(e=>e.Building&&e.Armed).ToArray();
   var foot=squad.Units.Count(a=>a.Info.HasTraitInfo<MobileInfo>()&&a.Info.TraitInfo<MobileInfo>().Locomotor=="foot");
   var avoid=guards.Where(e=>!Player.Shroud.IsVisible(e.Position)||foot*2>=squad.Units.Count||squad.Units.Sum(a=>a.GetSellValue())<e.Value*2).Select(e=>e.Position);
   path=FairNavigation.Route(World,Player,mobile.Locomotor,unit.Location,target.Location,5,avoid);
      var ready=path.Count>0||(unit.Location-target.Location).LengthSquared<=25;
   int next;if(!ready&&(!nextRouteTrace.TryGetValue(squad,out next)||World.WorldTick>=next)) {
    nextRouteTrace[squad]=World.WorldTick+125;
    var plain=FairNavigation.Route(World,Player,mobile.Locomotor,unit.Location,target.Location,5,new CPos[0]);
    TraceAttack(squad,plain.Count>0?"route_danger_avoidance":"route_no_path","locomotor="+mobile.Info.Locomotor+";avoided_cells="+string.Join("|",avoid)+";plain_path_cells="+plain.Count,target.Location,"direct_target");
    foreach(var stale in nextRouteTrace.Keys.Where(s=>!Squads.Contains(s)||!s.IsValid).ToArray())nextRouteTrace.Remove(stale);
   }
   return ready;
  }
 }
}




