using System;using System.Linq;using System.Collections.Generic;using OpenRA.Traits;using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  Actor teamObjective; int teamObjectiveUntil,teamWaitSince=-1,nextTeamLog; Squad teamSquad;
  ImprovedSquadManagerBotModule TeamPartner(){return World.Players.Where(p=>p!=Player&&p.IsBot&&Player.RelationshipWith(p)==PlayerRelationship.Ally).Select(p=>p.PlayerActor.TraitOrDefault<ImprovedSquadManagerBotModule>()).FirstOrDefault(m=>m!=null);}
  Actor[] TeamAvailable(){return unitsHangingAroundTheBase.Concat(Squads.Where(s=>s.Type==SquadType.Assault||s.Type==SquadType.Rush).SelectMany(s=>s.Units)).Where(a=>!unitCannotBeOrdered(a)&&!EngineerRaidOwns(a)&&!IsRecoveringVeteran(a)&&a.Info.HasTraitInfo<MobileInfo>()&&a.Info.HasTraitInfo<AttackBaseInfo>()&&!new[]{"naval","lcraft","float","sub"}.Contains(a.Info.TraitInfo<MobileInfo>().Locomotor)).Distinct().ToArray();}
  bool TeamObjectiveValid(){return teamObjective!=null&&World.WorldTick<teamObjectiveUntil&&teamObjective.CanBeViewedByPlayer(Player)&&IsPreferredEnemyUnit(teamObjective);}
  bool TryTeamOffense(IBot bot){
   var peer=TeamPartner();if(peer==null||peer.Strategy==null||peer.Strategy.HoldingOffense||Strategy.HoldingOffense)return false;
   var own=TeamAvailable();var ally=peer.TeamAvailable();if(own.Length<12||ally.Length<12)return false;
   var target=TeamObjectiveValid()?teamObjective:peer.TeamObjectiveValid()&&peer.teamObjective.CanBeViewedByPlayer(Player)?peer.teamObjective:null;
   if(target==null){target=Strategy.VisibleEnemies.Where(a=>IsPreferredEnemyUnit(a)&&a.CanBeViewedByPlayer(peer.Player)&&a.Info.HasTraitInfo<BuildingInfo>())
    .OrderByDescending(a=>new[]{"fact","weap","proc"}.Contains(a.Info.Name)?3:1).ThenBy(a=>(a.Location-Player.HomeLocation).LengthSquared)
    .Take(8).FirstOrDefault(a=>AttackOrFleeFuzzy.Default.CanAttack(own.Concat(ally),World.FindActorsInCircle(a.CenterPosition,WDist.FromCells(10)).Where(IsPreferredEnemyUnit))&&
      FairNavigation.Route(World,Player,own[0].Trait<Mobile>().Locomotor,own[0].Location,a.Location,5,new CPos[0]).Count>0&&
      FairNavigation.Route(World,peer.Player,ally[0].Trait<Mobile>().Locomotor,ally[0].Location,a.Location,5,new CPos[0]).Count>0);
   }
   if(target==null)return false;
   if(teamObjective!=target){teamWaitSince=-1;Console.WriteLine("AI-TEAM player="+Player.InternalName+" partner="+peer.Player.InternalName+" target="+target.ActorID+" own="+own.Length+" ally="+ally.Length);}
   teamObjective=target;peer.teamObjective=target;teamObjectiveUntil=World.WorldTick+1000;peer.teamObjectiveUntil=teamObjectiveUntil;
   if(teamSquad==null||!Squads.Contains(teamSquad)||!teamSquad.IsValid)teamSquad=RegisterNewSquad(bot,SquadType.Assault,target);
   foreach(var a in own.OrderBy(a=>(a.Location-target.Location).LengthSquared).Take(Math.Max(0,own.Length-4)).Take(40).ToArray())TransferUnit(a,teamSquad);
   teamSquad.TargetActor=target;harassment[teamSquad]=false;jointOperations.Remove(teamSquad);return true;
  }
  internal IEnumerable<Actor> TeamLocalForce(Squad squad,IEnumerable<Actor> own){
      if(squad.IsTargetValid) own=own.Concat(Squads.Where(s=>s!=squad&&s.Type==SquadType.Assault&&s.IsTargetValid&&(s.TargetActor.Location-squad.TargetActor.Location).LengthSquared<=144).SelectMany(s=>s.Units).Where(a=>!unitCannotBeOrdered(a)&&!IsRecoveringVeteran(a)&&(a.Location-squad.TargetActor.Location).LengthSquared<=576)).Distinct();
   var peer=TeamPartner();if(squad!=teamSquad||!TeamObjectiveValid()||peer==null||peer.teamSquad==null||!peer.teamSquad.IsValid||peer.teamObjective!=teamObjective)return own;
   return own.Concat(peer.teamSquad.Units.Where(a=>!peer.unitCannotBeOrdered(a)&&!peer.IsRecoveringVeteran(a)&&(a.Location-teamObjective.Location).LengthSquared<=576)).Distinct();
  }
  internal bool TeamCanAttack(Squad squad,IEnumerable<Actor> enemies){return AttackOrFleeFuzzy.Default.CanAttack(TeamLocalForce(squad,squad.Units),enemies);}
  internal bool HoldForTeamAttack(Squad squad){
   if(squad!=teamSquad||!TeamObjectiveValid())return false;var peer=TeamPartner();if(peer==null||peer.Strategy.HoldingOffense)return false;
   if(!squad.Units.Any(a=>(a.Location-teamObjective.Location).LengthSquared<=324))return false;
   if(peer.teamSquad!=null&&peer.teamSquad.Units.Count(a=>(a.Location-teamObjective.Location).LengthSquared<=576)>=4)return false;
   if(teamWaitSince<0)teamWaitSince=World.WorldTick;if(World.WorldTick-teamWaitSince>=375)return false;
   if(World.WorldTick>=nextTeamLog){nextTeamLog=World.WorldTick+125;LogOperation(squad,"wait_reason=team_partner duration="+(World.WorldTick-teamWaitSince));}
   foreach(var a in squad.Units.Where(a=>!a.IsIdle))bot.QueueOrder(new Order("Stop",a,false));return true;
  }
 }
}
