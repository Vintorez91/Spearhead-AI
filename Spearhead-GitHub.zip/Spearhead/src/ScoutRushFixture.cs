using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {internal Actor[] ReconTrialUnits => reconGroups.SelectMany(g=>g.Units).ToArray();}
 sealed class RushTrialBot : IBot {
  public Player Player{get;private set;} public IBotInfo Info=>null; readonly Action<Order> observe;
  public RushTrialBot(Player p,Action<Order> observer){Player=p;observe=observer;}public void Activate(Player p){Player=p;}
  public void QueueOrder(Order order){observe(order);Player.World.IssueOrder(order);}
 }
 public partial class AITestMetrics {
  public static string RushTrialExpectedMap; public static bool RushTrialSwap;public static string RushTrialVariant="new";
  Player rtOwn,rtEnemy; Actor[] rtDefenders,rtWave,rtBuildings;RushTrialBot rtBot; IBotTick[] rtModules;
  readonly HashSet<Actor> rtScouts=new HashSet<Actor>();readonly Dictionary<uint,CPos> rtInitialPositions=new Dictionary<uint,CPos>();
  int rtDetection=-1,rtResponse=-1,rtContact=-1,rtDamage=-1,rtScoutPeak,rtInitialBuildingHp;string rtResponseKind="";CPos rtRally;
  bool TrialAlive(Actor a)=>a.IsInWorld&&!a.IsDead;
  void ObserveRushOrder(Order o){
   if(rtDetection<0||rtResponse>=0||rtOwn==null)return;
   if(o.OrderString!="Attack"&&o.OrderString!="AttackMove"&&o.OrderString!="Move")return;
   if(!o.Target.IsValidFor(rtOwn.PlayerActor))return;
   var pos=rtOwn.World.Map.CellContaining(o.Target.CenterPosition);
   var attacksWave=rtWave.Any(a=>TrialAlive(a)&&(a.Location-pos).LengthSquared<64);
   var returnsHome=(pos-rtOwn.HomeLocation).LengthSquared<144;
   if(attacksWave||returnsHome){rtResponse=rtOwn.World.WorldTick;rtResponseKind=o.OrderString;}
  }
  void CheckScoutRush(World world){
   if(world.WorldTick==2){if(world.Map.Title!=RushTrialExpectedMap)throw new InvalidOperationException("Requested map was substituted: "+RushTrialExpectedMap+" -> "+world.Map.Title); Console.WriteLine("RUSH-TRIAL MAP "+world.Map.Title+" bounds="+world.Map.Bounds);foreach(var p in world.Players.Where(p=>p.IsBot))foreach(var b in p.PlayerActor.TraitsImplementing<ModularBot>())b.IsEnabled=false;
    world.AddFrameEndTask(w=>{
     rtOwn=w.Players.First(p=>p.InternalName==(RushTrialSwap?"Multi0":"Multi1"));rtEnemy=w.Players.First(p=>p.Playable&&!p.Spectating&&p.RelationshipWith(rtOwn)==PlayerRelationship.Enemy);
     foreach(var a in w.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&(a.Owner==rtOwn||a.Owner==rtEnemy)&&a.Info.HasTraitInfo<MobileInfo>()).ToArray())a.Dispose();
     rtBuildings=w.Actors.Where(a=>a.Owner==rtOwn&&a.IsInWorld&&!a.IsDead&&a.Info.HasTraitInfo<BuildingInfo>()).ToArray();rtInitialBuildingHp=rtBuildings.Sum(a=>a.TraitOrDefault<IHealth>()?.HP??0);
     var mobile=w.Map.Rules.Actors["e1"].TraitInfo<MobileInfo>();var loco=rtOwn.PlayerActor.World.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==mobile.Locomotor);var domain=new DomainIndex(w);
     var ownCells=w.Map.FindTilesInAnnulus(rtOwn.HomeLocation,5,9).Where(c=>mobile.CanEnterCell(w,null,c)).OrderBy(c=>c.X).ThenBy(c=>c.Y).Take(8).ToArray();
     if(ownCells.Length!=8)throw new InvalidOperationException("Missing defender fixture cells");
     rtDefenders=ownCells.Select((c,i)=>w.CreateActor(i<6?"e1":"e3",new TypeDictionary{new OwnerInit(rtOwn),new LocationInit(c)})).ToArray();foreach(var a in rtDefenders)rtInitialPositions[a.ActorID]=a.Location;
     var center=new CPos(w.Map.Bounds.Left+w.Map.Bounds.Width/2,w.Map.Bounds.Top+w.Map.Bounds.Height/2);
     rtRally=w.Map.FindTilesInAnnulus(rtOwn.HomeLocation,42,48).Where(c=>mobile.CanEnterCell(w,null,c)&&domain.IsPassable(rtOwn.HomeLocation,c,loco)).OrderBy(c=>(c-center).LengthSquared).ThenBy(c=>c.X).ThenBy(c=>c.Y).First();
     var enemyCells=w.Map.FindTilesInAnnulus(rtRally,0,5).Where(c=>mobile.CanEnterCell(w,null,c)&&domain.IsPassable(c,rtOwn.HomeLocation,loco)).OrderBy(c=>(c-rtRally).LengthSquared).ThenBy(c=>c.X).ThenBy(c=>c.Y).Take(10).ToArray();
     rtWave=enemyCells.Select((c,i)=>w.CreateActor(i<8?"e1":"e2",new TypeDictionary{new OwnerInit(rtEnemy),new LocationInit(c)})).ToArray();if(rtWave.Length!=10)throw new InvalidOperationException("Missing rush fixture cells");
     rtBot=new RushTrialBot(rtOwn,ObserveRushOrder);
     rtModules=rtOwn.PlayerActor.TraitsImplementing<IBotTick>().Where(t=>t is ImprovedStrategyBotModule||t is ImprovedSquadManagerBotModule||t.GetType().Name=="SquadManagerBotModule").ToArray();
     if(rtModules.Length==0)throw new InvalidOperationException("No active squad modules"); foreach(var t in rtModules){var field=t.GetType().GetField("bot",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic);if(field!=null&&field.FieldType==typeof(IBot))field.SetValue(t,rtBot);}
     File.WriteAllText(Path.Combine(Platform.SupportDir,"rush-setup.txt"),"variant="+RushTrialVariant+" home="+rtOwn.HomeLocation+" rally="+rtRally+" defenders="+string.Join(";",rtDefenders.Select(a=>a.Info.Name+":"+a.Location))+" wave="+string.Join(";",rtWave.Select(a=>a.Info.Name+":"+a.Location))+" launch_tick=750");
    });
   }
   if(world.WorldTick<10||rtOwn==null)return;
   if(rtDetection<0&&rtWave.Any(a=>TrialAlive(a)&&a.CanBeViewedByPlayer(rtOwn)))rtDetection=world.WorldTick;
   foreach(var t in rtModules)if(t.IsTraitEnabled())t.BotTick(rtBot);
   var manager=rtOwn.PlayerActor.TraitOrDefault<ImprovedSquadManagerBotModule>();if(manager!=null){foreach(var a in manager.ReconTrialUnits)rtScouts.Add(a);rtScoutPeak=Math.Max(rtScoutPeak,manager.ReconTrialUnits.Length);}
   if(world.WorldTick==750)foreach(var a in rtWave)world.IssueOrder(new Order("AttackMove",a,Target.FromCell(world,rtOwn.HomeLocation),false));
   if(rtContact<0&&rtWave.Any(a=>TrialAlive(a)&&rtBuildings.Any(b=>TrialAlive(b)&&(a.Location-b.Location).LengthSquared<144)))rtContact=world.WorldTick;
   var currentHp=rtBuildings.Sum(a=>TrialAlive(a)?a.TraitOrDefault<IHealth>()?.HP??0:0);if(rtDamage<0&&currentHp<rtInitialBuildingHp)rtDamage=world.WorldTick;
   if(world.WorldTick%125==0)Console.WriteLine("RUSH-TRIAL tick="+world.WorldTick+" variant="+RushTrialVariant+" detected="+rtDetection+" response="+rtResponse+" contact="+rtContact+" building_damage="+(rtInitialBuildingHp-currentHp)+" scouts="+rtScoutPeak);
   if(world.WorldTick==3500){
    var fields=new[]{"variant","faction","home_x","home_y","rally_x","rally_y","launch_tick","detection_tick","response_tick","response_kind","contact_tick","first_damage_tick","building_hp_lost","buildings_lost","own_units_lost","own_credits_lost","enemy_units_lost","own_army_remaining","enemy_army_remaining","scouts_peak","scouts_lost","scouts_credits_lost","moved_defenders","explored_cells"};
    var values=new[]{RushTrialVariant,rtOwn.Faction.InternalName,rtOwn.HomeLocation.X.ToString(),rtOwn.HomeLocation.Y.ToString(),rtRally.X.ToString(),rtRally.Y.ToString(),"750",rtDetection.ToString(),rtResponse.ToString(),rtResponseKind,rtContact.ToString(),rtDamage.ToString(),(rtInitialBuildingHp-currentHp).ToString(),rtBuildings.Count(a=>!TrialAlive(a)).ToString(),rtDefenders.Count(a=>!TrialAlive(a)).ToString(),rtDefenders.Where(a=>!TrialAlive(a)).Sum(a=>a.Info.TraitInfo<ValuedInfo>().Cost).ToString(),rtWave.Count(a=>!TrialAlive(a)).ToString(),rtDefenders.Where(TrialAlive).Sum(a=>a.Info.TraitInfo<ValuedInfo>().Cost).ToString(),rtWave.Where(TrialAlive).Sum(a=>a.Info.TraitInfo<ValuedInfo>().Cost).ToString(),rtScoutPeak.ToString(),rtScouts.Count(a=>!TrialAlive(a)).ToString(),rtScouts.Where(a=>!TrialAlive(a)).Sum(a=>a.Info.TraitInfo<ValuedInfo>().Cost).ToString(),rtDefenders.Count(a=>TrialAlive(a)&&a.Location!=rtInitialPositions[a.ActorID]).ToString(),world.Map.AllCells.Count(c=>rtOwn.Shroud.IsExplored(c)).ToString()};
    File.WriteAllText(Path.Combine(Platform.SupportDir,"rush-result.csv"),string.Join(",",fields)+"\n"+string.Join(",",values)+"\n");Console.WriteLine("RUSH-TRIAL COMPLETE");Game.Exit();
   }
  }
 }
}


