#region Copyright & License Information
/*
 * Copyright 2007-2020 The OpenRA Developers (see AUTHORS)
 * This file is part of OpenRA, which is free software. It is made
 * available to you under the terms of the GNU General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version. For more
 * information, see COPYING.
 */
#endregion

using System.Linq;
using OpenRA.Traits;

namespace OpenRA.Mods.Common.Traits.AITest.Squads
{
	abstract class GroundStateBase : StateBase
	{
		protected virtual bool ShouldFlee(Squad owner)
		{
			return ShouldFlee(owner, enemies => { var flee=!owner.SquadManager.TeamCanAttack(owner,enemies); if(flee)owner.SquadManager.TraceAttack(owner,"nearby_threat_retreat","enemy_ids="+string.Join("|",enemies.Select(a=>a.ActorID))); return flee; });
		}

		        protected bool RejectGroundAttack(Squad owner, System.Collections.Generic.IEnumerable<Actor> defenders) {
            if (!owner.SquadManager.LocalCommitAllowed(owner)) return true;
            if (!owner.SquadManager.TeamCanAttack(owner,defenders)) { owner.SquadManager.TraceAttack(owner,"target_defenders_rejected","defender_ids="+string.Join("|",defenders.Select(a=>a.ActorID))); return true; }
            if (ShouldFlee(owner)) { owner.SquadManager.TraceAttack(owner,"nearby_threat_retreat"); return true; }
            return false;
        }
        protected Actor FindClosestEnemy(Squad owner)
		{
			return owner.SquadManager.ChooseOperationTarget(owner);
		}
	}

	class GroundUnitsIdleState : GroundStateBase, IState
	{
		public void Activate(Squad owner) { }

		public void Tick(Squad owner)
		{
			if (!owner.IsValid)
				return;

			if (owner.SquadManager.TryQueueBreakthrough(owner)) return;
            if (!owner.IsTargetValid)
			{
				if(owner.SquadManager.ContinueRememberedAttack(owner))return;
                var closestEnemy = FindClosestEnemy(owner);
				if (closestEnemy == null)
                {
                    owner.SquadManager.LogAttackWait(owner,"no_reachable_target",0);
                    owner.SquadManager.ExploreSquad(owner);
                    return;
                }

				owner.TargetActor = closestEnemy;
			}

			var enemyUnits = owner.World.FindActorsInCircle(owner.TargetActor.CenterPosition, WDist.FromCells(owner.SquadManager.Info.IdleScanRadius))
				.Where(owner.SquadManager.IsPreferredEnemyUnit).ToList();

			if (enemyUnits.Count == 0)
				return;

			if (owner.SquadManager.TeamCanAttack(owner, enemyUnits))
			{
				if(owner.SquadManager.HoldForMassAssembly(owner))return;
                owner.SquadManager.QueueApproach(owner);

				// We have gathered sufficient units. Attack the nearest enemy unit.
				owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsAttackMoveState(), true);
			}
			else
				owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true);
		}

		public void Deactivate(Squad owner) { }
	}

	class GroundUnitsAttackMoveState : GroundStateBase, IState
	{
		int lastUpdatedTick;
        int formationWaitSince = -1;
		CPos? lastLeaderLocation;
		Actor lastTarget;

		public void Activate(Squad owner) { }

		public void Tick(Squad owner)
		{
			if (!owner.IsValid)
				return;

			if (owner.SquadManager.TryQueueBreakthrough(owner)) return;
            if (!owner.IsTargetValid)
			{
				if(owner.SquadManager.ContinueRememberedAttack(owner))return;
                var closestEnemy = FindClosestEnemy(owner);
				if (closestEnemy != null)
					owner.TargetActor = closestEnemy;
				else
				{
					if (owner.SquadManager.ApproachKnownLocation(owner)) return;
                    owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true);
					return;
				}
			}

            if (owner.SquadManager.RaidShouldWithdraw(owner)) { owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true); return; }
            if (owner.SquadManager.HoldForJointAttack(owner)) return;
            var targetDefenders = owner.World.FindActorsInCircle(owner.TargetActor.CenterPosition, WDist.FromCells(10))
                .Where(owner.SquadManager.IsPreferredEnemyUnit).ToArray();
            if (RejectGroundAttack(owner, targetDefenders))
            {
                owner.SquadManager.MarkUnreachable(owner.TargetActor);
                owner.SquadManager.HoldRejectedAttack(owner);
                owner.TargetActor = null;
                owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true);
                return;
            }
            var leader = owner.Units.ClosestTo(owner.TargetActor.CenterPosition);
			if (leader == null)
				return;

			if (leader.Location != lastLeaderLocation)
			{
				lastLeaderLocation = leader.Location;
				lastUpdatedTick = owner.World.WorldTick;
			}

			if (owner.TargetActor != lastTarget)
			{
				lastTarget = owner.TargetActor;
				lastUpdatedTick = owner.World.WorldTick;
			}

			// HACK: Drop back to the idle state if we haven't moved in 2.5 seconds
			// This works around the squad being stuck trying to attack-move to a location
			// that they cannot path to, generating expensive pathfinding calls each tick.
			if (owner.World.WorldTick > lastUpdatedTick + 250 && !owner.Units.Any(BusyAttack))
			{
				owner.SquadManager.TraceAttack(owner,"no_progress","limit_ticks=250;elapsed="+(owner.World.WorldTick-lastUpdatedTick));
                owner.SquadManager.MarkUnreachable(owner.TargetActor);
                owner.SquadManager.HoldRejectedAttack(owner);
				owner.TargetActor = null;
				owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsIdleState(), true);
				return;
			}

			var ownUnits = owner.World.FindActorsInCircle(leader.CenterPosition, WDist.FromCells(owner.Units.Count) / 3)
				.Where(a => a.Owner == owner.Units.First().Owner && owner.Units.Contains(a)).ToHashSet();

			if(ownUnits.Count<owner.Units.Count&&formationWaitSince<0)formationWaitSince=owner.World.WorldTick;
            if (ownUnits.Count < owner.Units.Count && owner.World.WorldTick - formationWaitSince < 250 && !owner.Units.Any(BusyAttack))
			{
				// Since units have different movement speeds, they get separated while approaching the target.
				// Formation waiting is bounded; moving leaders must not reset the timer.
				owner.SquadManager.LogAttackWait(owner,"formation",owner.World.WorldTick-formationWaitSince);
                owner.Bot.QueueOrder(new Order("Stop", leader, false));

				var units = owner.Units.Where(a => !ownUnits.Contains(a)).ToArray();
				owner.Bot.QueueOrder(new Order("AttackMove", null, Target.FromCell(owner.World, leader.Location), false, groupedActors: units));
			}
			else
			{
				var enemies = owner.World.FindActorsInCircle(leader.CenterPosition, WDist.FromCells(owner.SquadManager.Info.AttackScanRadius))
					.Where(owner.SquadManager.IsPreferredEnemyUnit);
				var target = enemies.Where(a => a == owner.TargetActor || (a.Location-leader.Location).LengthSquared <= 36).ClosestTo(leader.CenterPosition);
				if (target != null)
				{
					owner.TargetActor = target;
					owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsAttackState(), true);
				}
				else
					owner.SquadManager.QueueApproach(owner);
			}

			if (ShouldFlee(owner))
				owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true);
		}

		public void Deactivate(Squad owner) { }
	}

	class GroundUnitsAttackState : GroundStateBase, IState
	{
		int lastUpdatedTick;

		CPos? lastLeaderLocation;
		Actor lastTarget;

		public void Activate(Squad owner) { }

		public void Tick(Squad owner)
		{
			if (!owner.IsValid)
				return;

			if (owner.SquadManager.TryQueueBreakthrough(owner)) return;
            if (!owner.IsTargetValid)
			{
				if(owner.SquadManager.ContinueRememberedAttack(owner))return;
                var closestEnemy = FindClosestEnemy(owner);
				if (closestEnemy != null)
					owner.TargetActor = closestEnemy;
				else
				{
					if (owner.SquadManager.ApproachKnownLocation(owner)) return;
                    owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true);
					return;
				}
			}

            if (owner.SquadManager.RaidShouldWithdraw(owner)) { owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true); return; }
            if (owner.SquadManager.HoldForJointAttack(owner)) return;
            var targetDefenders = owner.World.FindActorsInCircle(owner.TargetActor.CenterPosition, WDist.FromCells(10))
                .Where(owner.SquadManager.IsPreferredEnemyUnit).ToArray();
            if (RejectGroundAttack(owner, targetDefenders))
            {
                owner.SquadManager.MarkUnreachable(owner.TargetActor);
                owner.SquadManager.HoldRejectedAttack(owner);
                owner.TargetActor = null;
                owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true);
                return;
            }
            var leader = owner.Units.ClosestTo(owner.TargetActor.CenterPosition);
			if (leader.Location != lastLeaderLocation)
			{
				lastLeaderLocation = leader.Location;
				lastUpdatedTick = owner.World.WorldTick;
			}

			if (owner.TargetActor != lastTarget)
			{
				lastTarget = owner.TargetActor;
				lastUpdatedTick = owner.World.WorldTick;
			}

			// HACK: Drop back to the idle state if we haven't moved in 2.5 seconds
			// This works around the squad being stuck trying to attack-move to a location
			// that they cannot path to, generating expensive pathfinding calls each tick.
			if (owner.World.WorldTick > lastUpdatedTick + 250 && !owner.Units.Any(BusyAttack))
			{
				owner.SquadManager.TraceAttack(owner,"no_progress","limit_ticks=250;elapsed="+(owner.World.WorldTick-lastUpdatedTick));
                owner.SquadManager.MarkUnreachable(owner.TargetActor);
                owner.SquadManager.HoldRejectedAttack(owner);
				owner.TargetActor = null;
				owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsIdleState(), true);
				return;
			}

			foreach (var a in owner.Units) { if (BusyAttack(a)) continue; var local = owner.SquadManager.ChooseEffectiveLocalTarget(a, owner.TargetActor); if (local != null && (local != owner.TargetActor || CanAttackTarget(a, local))) owner.Bot.QueueOrder(new Order("Attack", a, Target.FromActor(local), false)); }

			if (ShouldFlee(owner))
				owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsFleeState(), true);
		}

		public void Deactivate(Squad owner) { }
	}

	class GroundUnitsFleeState : GroundStateBase, IState
	{
		public void Activate(Squad owner) { }

		public void Tick(Squad owner)
		{
			if (!owner.IsValid)
				return;

			GoToRandomOwnBuilding(owner);
			owner.FuzzyStateMachine.ChangeState(owner, new GroundUnitsIdleState(), true);
		}

		public void Deactivate(Squad owner) { owner.SquadManager.ReleaseUnits(owner); }
	}
}

















