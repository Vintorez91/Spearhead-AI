using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedSquadManagerBotModule
 {
  sealed class VeteranRecovery { public int Start; public Actor Repair; }
  readonly Dictionary<Actor,VeteranRecovery> veteranRecovery=new Dictionary<Actor,VeteranRecovery>();
  readonly Dictionary<Actor,int> veteranCooldown=new Dictionary<Actor,int>();
  readonly Dictionary<Actor,int> veteranLastCoveredHP=new Dictionary<Actor,int>();
  int nextVeteranTick;
  internal static int VeteranRank(Actor a) { if(a==null||a.Disposed)return 0; var xp=a.TraitOrDefault<GainsExperience>();return xp==null?0:xp.Level; }
  internal bool VeteranRecovering(Actor a) { return veteranRecovery.ContainsKey(a); }
  bool IsRecoveringVeteran(Actor a) { return veteranRecovery.ContainsKey(a); }
  void VeteranEvent(Actor a,string action,Actor repair=null) {
   Console.WriteLine("AI-VETERAN tick="+World.WorldTick+" unit="+a.ActorID+" rank="+VeteranRank(a)+" action="+action);
   var logger=World.WorldActor.TraitOrDefault<AITestMetrics>();if(logger!=null)logger.TelemetryVeteran(a,action,repair);
  }
  void ReinforceWithVeterans(IBot bot,Actor asset,Actor attacker,OpenRA.Mods.Common.Traits.AITest.Squads.Squad squad) {
   if(!new[]{"fact","proc","weap","powr","apwr"}.Contains(asset.Info.Name))return;
   var enemies=World.FindActorsInCircle(asset.CenterPosition,WDist.FromCells(12)).Where(a=>a.IsInWorld&&!a.IsDead&&a.CanBeViewedByPlayer(Player)&&Player.RelationshipWith(a.Owner)==PlayerRelationship.Enemy&&a.Info.HasTraitInfo<AttackBaseInfo>()).ToList();
   if(!enemies.Contains(attacker))enemies.Add(attacker);
   var defenders=World.FindActorsInCircle(asset.CenterPosition,WDist.FromCells(12)).Where(a=>a.Owner==Player&&a.IsInWorld&&!a.IsDead&&a.Info.HasTraitInfo<AttackBaseInfo>()&&!IsRecoveringVeteran(a)).ToList();
   if(defenders.Count>0&&OpenRA.Mods.Common.Traits.AITest.Squads.AttackOrFleeFuzzy.Default.CanAttack(defenders,enemies))return;
   foreach(var a in veteranRecovery.Keys.Where(a=>!a.Disposed&&a.IsInWorld&&!a.IsDead&&(a.Location-asset.Location).LengthSquared<=144&&OpenRA.Mods.Common.Traits.AITest.Squads.AttackOrFleeFuzzy.SuitableAttacker(a,attacker)).OrderByDescending(a=>a.Trait<Health>().HP/(double)a.Trait<Health>().MaxHP).ToArray()) {
    veteranRecovery.Remove(a);veteranCooldown[a]=World.WorldTick+250;
    bot.QueueOrder(new Order("Stop",a,false));TransferUnit(a,squad);VeteranEvent(a,"emergency_defence");defenders.Add(a);
    if(OpenRA.Mods.Common.Traits.AITest.Squads.AttackOrFleeFuzzy.Default.CanAttack(defenders,enemies))break;
   }
  }
  void UpdateVeterans(IBot bot) {
   if(World.WorldTick<nextVeteranTick)return;nextVeteranTick=World.WorldTick+25;
   var threats=World.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&a.OccupiesSpace!=null&&a.CanBeViewedByPlayer(Player)&&Player.RelationshipWith(a.Owner)==PlayerRelationship.Enemy&&a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
   Func<Actor,bool> pressured=a=>threats.Any(e=>(e.CenterPosition-a.CenterPosition).LengthSquared<100L*1024*1024);
   foreach(var a in World.Actors.Where(a=>a.Owner==Player&&a.IsInWorld&&!a.IsDead&&a.Info.HasTraitInfo<AttackBaseInfo>()&&(a.Info.HasTraitInfo<MobileInfo>()||a.Info.HasTraitInfo<AircraftInfo>())).ToArray()) {
    if(EngineerRaidOwns(a)||veteranRecovery.ContainsKey(a)||VeteranRank(a)==0)continue;
    int cooldown;if(veteranCooldown.TryGetValue(a,out cooldown)&&World.WorldTick<cooldown)continue;
    var hp=a.TraitOrDefault<Health>();if(hp==null)continue;
    int previousHp;if(veteranLastCoveredHP.TryGetValue(a,out previousHp)&&hp.HP>=previousHp&&!pressured(a))continue;
    var fraction=hp.HP/(double)hp.MaxHP;var limit=VeteranRank(a)>=3?0.60:0.45;
    if(fraction>=limit||!pressured(a)&&fraction>=0.25)continue;
    foreach(var squad in Squads)squad.Units.Remove(a);
    foreach(var group in reconGroups)group.Units.Remove(a);
    escortUnits.Remove(a);unitsHangingAroundTheBase.Remove(a);if(!activeUnits.Contains(a))activeUnits.Add(a);
    veteranRecovery[a]=new VeteranRecovery{Start=World.WorldTick};VeteranEvent(a,"withdraw");
   }
   foreach(var pair in veteranRecovery.ToArray()) {
    var a=pair.Key;var r=pair.Value;
    if(a.Disposed||a.IsDead||a.Owner!=Player){veteranRecovery.Remove(a);activeUnits.Remove(a);continue;}
    if(!a.IsInWorld)continue;
    var hp=a.Trait<Health>();var elapsed=World.WorldTick-r.Start;
    var repair=a.TraitOrDefault<Repairable>();var near=a.TraitOrDefault<RepairableNear>();
    var canHeal=VeteranRank(a)>=4||repair!=null||near!=null;
    if(hp.HP>=hp.MaxHP*0.85||!canHeal&&elapsed>=300&&!pressured(a)||elapsed>=1750) {
     VeteranEvent(a,hp.HP>=hp.MaxHP*0.85?"recovered":"return_after_cover");
     if(hp.HP>=hp.MaxHP*0.85)veteranLastCoveredHP.Remove(a);else veteranLastCoveredHP[a]=hp.HP;
     veteranRecovery.Remove(a);activeUnits.Remove(a);veteranCooldown[a]=World.WorldTick+500;FindNewUnits(bot);continue;
    }
    var money=Player.PlayerActor.Trait<PlayerResources>();var mobile=a.TraitOrDefault<Mobile>();var domain=new DomainIndex(World);
    var facility=World.Actors.Where(b=>b.Owner==Player&&!b.IsDead&&b.IsInWorld&&b.OccupiesSpace!=null&&b.Info.HasTraitInfo<BuildingInfo>())
     .Where(b=>repair!=null&&repair.Info.RepairActors.Contains(b.Info.Name)||near!=null&&near.Info.RepairActors.Contains(b.Info.Name))
     .Where(b=>mobile==null||domain.IsPassable(a.Location,b.Location,mobile.Locomotor))
     .Where(b=>threats.All(e=>(e.Location-b.Location).LengthSquared>100))
     .OrderBy(b=>(a.Location-b.Location).LengthSquared).FirstOrDefault();
    if(facility!=null&&money.Cash+money.Resources>=300) {
     if(r.Repair!=facility||a.IsIdle){r.Repair=facility;bot.QueueOrder(new Order(repair!=null?"Repair":"RepairNear",a,Target.FromActor(facility),false));VeteranEvent(a,"repair",facility);}
     continue;
    }
    r.Repair=null;
    if(!a.IsIdle&&elapsed>25)continue;
    var home=World.Actors.Where(b=>b.Owner==Player&&!b.IsDead&&b.IsInWorld&&b.Info.Name=="fact"&&threats.All(e=>(e.Location-b.Location).LengthSquared>144))
     .OrderBy(b=>(b.Location-a.Location).LengthSquared).FirstOrDefault();
    if(home==null)continue;
    var cell=World.Map.FindTilesInAnnulus(home.Location,3,7).Where(c=>Player.Shroud.IsExplored(c)&&(mobile==null||domain.IsPassable(a.Location,c,mobile.Locomotor)))
     .OrderBy(c=>(c-home.Location).LengthSquared).Select(c=>(CPos?)c).FirstOrDefault();
    if(cell.HasValue)bot.QueueOrder(new Order("Move",a,Target.FromCell(World,cell.Value),false));
   }
   foreach(var a in veteranCooldown.Keys.Where(a=>a.Disposed||a.IsDead).ToArray()){veteranCooldown.Remove(a);veteranLastCoveredHP.Remove(a);}
  }
 }
 public partial class AITestMetrics
 {
  StreamWriter veteranLog;
  void InitializeVeteranTelemetry(string prefix) {
   veteranLog=new StreamWriter(prefix+"-veterans.csv");
   veteranLog.WriteLine("tick,id,type,owner,event,rank,experience,hp,max_hp,x,y,repair_id,repair_type");
  }
  public void TelemetryVeteran(Actor a,string kind,Actor repair=null) {
   if(veteranLog==null||a.Disposed)return;
   var xp=a.TraitOrDefault<GainsExperience>();var hp=a.TraitOrDefault<Health>();
   veteranLog.WriteLine(Csv(a.World.WorldTick,a.ActorID,a.Info.Name,a.Owner.InternalName,kind,xp==null?0:xp.Level,xp==null?0:xp.Experience,hp==null?0:hp.HP,hp==null?0:hp.MaxHP,a.Location.X,a.Location.Y,repair==null?"":repair.ActorID.ToString(),repair==null?"":repair.Info.Name));
  }
 }
}





