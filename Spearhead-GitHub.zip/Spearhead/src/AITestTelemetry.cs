using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest
{
    public class AITestActorTelemetryInfo : TraitInfo<AITestActorTelemetry> { }
    public class AITestActorTelemetry : INotifyCreated, INotifyAttack, INotifyDamage, INotifyCapture, INotifyResourceAccepted
    {
        int previousHp;
        void INotifyCreated.Created(Actor self){previousHp=self.TraitOrDefault<IHealth>()?.HP??0;}
        void INotifyAttack.PreparingAttack(Actor self,in Target target,Armament arm,Barrel barrel){}
        void INotifyAttack.Attacking(Actor self,in Target target,Armament arm,Barrel barrel){self.World.WorldActor.TraitOrDefault<AITestMetrics>()?.NavalShot(self,target,arm.Info.Weapon);}
        void INotifyCapture.OnCapture(Actor self, Actor captor, Player oldOwner, Player newOwner, BitSet<CaptureType> types)
        {
            var logger = self.World.WorldActor.TraitOrDefault<AITestMetrics>();
            if (logger != null) logger.TelemetryCapture(self, captor, oldOwner, newOwner);
        }
        void INotifyResourceAccepted.OnResourceAccepted(Actor self, Actor harvester, string resourceType, int count, int value)
        {
            if (self != harvester) return; // Second argument is the accepting refinery; notification is broadcast to owner actors.
            var logger = self.World.WorldActor.TraitOrDefault<AITestMetrics>();
            if (logger != null) logger.TelemetryIncome(self, self.Owner, count * value, "refinery_accepted", null);
        }
        void INotifyDamage.Damaged(Actor self, AttackInfo e)
        {
            var logger = self.World.WorldActor.TraitOrDefault<AITestMetrics>();
            var hp=self.TraitOrDefault<IHealth>()?.HP??0;
            if(logger!=null)logger.NavalDamage(self,e.Attacker,Math.Max(0,previousHp-hp));previousHp=hp;
            if (logger != null) logger.TelemetryDamage(self, e);
        }
    }
    public partial class AITestMetrics
    {
        sealed class LastActor { public Actor Actor; public string Owner; public CPos Cell; public int Cost; }
        readonly Dictionary<uint, LastActor> telemetryActors = new Dictionary<uint, LastActor>();
        StreamWriter actorLog, eventLog, economyLog, knowledgeLog;
        int nextTelemetry, nextActorScan;
        static string Csv(params object[] values)
        {
            return string.Join(",", values.Select(v => "\"" + Convert.ToString(v, CultureInfo.InvariantCulture).Replace("\"", "\"\"") + "\""));
        }
        void InitializeTelemetry(World world, string metricsPath)
        {
            var prefix = Path.Combine(Path.GetDirectoryName(metricsPath), Path.GetFileNameWithoutExtension(metricsPath));
            actorLog = new StreamWriter(prefix + "-actors.csv");
            eventLog = new StreamWriter(prefix + "-events.csv");
            economyLog = new StreamWriter(prefix + "-economy.csv");
            knowledgeLog = new StreamWriter(prefix + "-knowledge.csv");
            actorLog.WriteLine("tick,id,type,owner,ai,kind,cell_x,cell_y,world_x,world_y,hp,max_hp,cost,idle,activity,role,target_id,target_x,target_y,visible_multi0,visible_multi1,visible_multi2,visible_multi3");
            eventLog.WriteLine("tick,event,id,type,owner,x,y,cost,source_id,source_type,source_owner,source_x,source_y,requested_damage,hp_after,detail");
            economyLog.WriteLine("tick,player,ai,cash,resources,capacity,army_value,buildings_value,harvesters,idle_combat,idle_queues,total_queues,queued_items,plan,focus_x,focus_y,visible_enemies,remembered_enemies,recovering_expansion,earned,spent,logged_source_income,unattributed_earned");
            knowledgeLog.WriteLine("tick,player,enemy_id,type,last_seen_tick,remembered_x,remembered_y,currently_visible");
            InitializeNavalLogs(prefix);
            InitializeDecisions(prefix);
            nextTelemetry = 0; nextActorScan = 0;
        }
        static int ActorCost(Actor a) { var value = a.Info.TraitInfoOrDefault<ValuedInfo>(); return value == null ? 0 : value.Cost; }
        public void TelemetryOperation(Player player, Squads.Squad squad, string text)
        {
            if (eventLog == null || !squad.IsValid) return;
            var a = squad.Units.First(); eventLog.WriteLine(Csv(a.World.WorldTick, "tactic", a.ActorID, a.Info.Name, player.InternalName, a.Location.X, a.Location.Y, "", "", "", "", "", "", "", "", text));
        }
        public void TelemetryDamage(Actor self, AttackInfo e)
        {
            if (eventLog == null || self.OccupiesSpace == null) return;
            var source = e.Attacker; var positioned = source != null && source.IsInWorld && source.OccupiesSpace != null;
            var health = self.TraitOrDefault<Health>();
            if (health != null) DecisionDamage(self, source, health.HP);
            eventLog.WriteLine(Csv(self.World.WorldTick, "damage", self.ActorID, self.Info.Name, self.Owner.InternalName,
                self.Location.X, self.Location.Y, ActorCost(self), source == null ? "" : source.ActorID.ToString(), source == null ? "" : source.Info.Name,
                source == null ? "" : source.Owner.InternalName, positioned ? source.Location.X.ToString() : "", positioned ? source.Location.Y.ToString() : "",
                e.Damage.Value, health == null ? "" : health.HP.ToString(), "requested damage may include overkill; negative means healing"));
        }
        void TelemetryTick(World world)
        {
            if (actorLog == null) return;
            if (world.WorldTick >= nextActorScan)
            {
                nextActorScan = world.WorldTick + 25;
                var current = world.Actors.Where(a => !a.IsDead && a.IsInWorld && a.OccupiesSpace != null).ToArray();
                DecisionScan(world, current);
                var ids = new HashSet<uint>(current.Select(a => a.ActorID));
                foreach (var old in telemetryActors.Where(kv => !ids.Contains(kv.Key)).ToArray())
                {
                    var a = old.Value;
                    eventLog.WriteLine(Csv(world.WorldTick, a.Actor.IsDead ? "destroyed" : "removed", old.Key, a.Actor.Info.Name, a.Owner, a.Cell.X, a.Cell.Y, a.Cost, "", "", "", "", "", "", "", "last observed location; removed can mean sold or transformed"));
                    telemetryActors.Remove(old.Key);
                }
                foreach (var a in current)
                {
                    LastActor old;
                    if (!telemetryActors.TryGetValue(a.ActorID, out old))
                        eventLog.WriteLine(Csv(world.WorldTick, "appeared", a.ActorID, a.Info.Name, a.Owner.InternalName, a.Location.X, a.Location.Y, ActorCost(a), "", "", "", "", "", "", "", "spawn, production or deployment; polled every 25 ticks"));
                    else if (old.Owner != a.Owner.InternalName)
                        eventLog.WriteLine(Csv(world.WorldTick, "owner_changed", a.ActorID, a.Info.Name, a.Owner.InternalName, a.Location.X, a.Location.Y, ActorCost(a), "", "", old.Owner, "", "", "", "", "capture or transfer"));
                    telemetryActors[a.ActorID] = new LastActor { Actor = a, Owner = a.Owner.InternalName, Cell = a.Location, Cost = ActorCost(a) };
                }
            }
            if (world.WorldTick >= nextTelemetry) { nextTelemetry = world.WorldTick + 125; TelemetrySnapshot(world); NavalSnapshot(world); FlushTelemetry(); }
        }
        void TelemetrySnapshot(World world)
        {
            if (actorLog == null) return;
            var players = world.Players.Where(p => p.IsBot && p.Playable).ToArray();
            var actors = world.Actors.Where(a => !a.IsDead && a.IsInWorld && a.OccupiesSpace != null).ToArray();
            DecisionScan(world, actors);
            DecisionSnapshot(world, actors);
            var managers = players.ToDictionary(p => p, p => p.PlayerActor.TraitOrDefault<ImprovedSquadManagerBotModule>());
            foreach (var a in actors)
            {
                var health = a.TraitOrDefault<Health>(); ImprovedSquadManagerBotModule manager; managers.TryGetValue(a.Owner, out manager); if (manager != null && manager.IsTraitDisabled) manager = null;
                var target = manager == null ? null : manager.TelemetryTarget(a);
                var kind = a.Info.HasTraitInfo<BuildingInfo>() ? "building" : a.Info.HasTraitInfo<MobileInfo>() || a.Info.HasTraitInfo<AircraftInfo>() ? "unit" : "other";
                var role = a.Info.HasTraitInfo<HarvesterInfo>() ? "Harvester" : a.Info.Name == "e6" ? "Engineer" : a.Info.Name == "mcv" ? "MCV" : manager == null ? "" : manager.TelemetryRole(a);
                actorLog.WriteLine(Csv(world.WorldTick, a.ActorID, a.Info.Name, a.Owner.InternalName, a.Owner.BotType, kind, a.Location.X, a.Location.Y,
                    a.CenterPosition.X, a.CenterPosition.Y, health == null ? "" : health.HP.ToString(), health == null ? "" : health.MaxHP.ToString(), ActorCost(a), a.IsIdle,
                    a.CurrentActivity == null ? "" : a.CurrentActivity.GetType().Name, role, target == null ? "" : target.ActorID.ToString(), target == null ? "" : target.Location.X.ToString(), target == null ? "" : target.Location.Y.ToString(),
                    players.Length > 0 && a.CanBeViewedByPlayer(players[0]), players.Length > 1 && a.CanBeViewedByPlayer(players[1]), players.Length > 2 && a.CanBeViewedByPlayer(players[2]), players.Length > 3 && a.CanBeViewedByPlayer(players[3])));
            }
            foreach (var player in players)
            {
                var own = actors.Where(a => a.Owner == player).ToArray(); var resources = player.PlayerActor.Trait<PlayerResources>();
                var army = own.Where(a => a.Info.HasTraitInfo<AttackBaseInfo>() && (a.Info.HasTraitInfo<MobileInfo>() || a.Info.HasTraitInfo<AircraftInfo>())).ToArray();
                var queues = world.Actors.Where(a => a.Owner == player && !a.IsDead && a.IsInWorld).SelectMany(a => a.TraitsImplementing<ProductionQueue>()).Where(q => q.BuildableItems().Any()).ToArray();
                var strategy = player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>(); if (strategy != null && strategy.IsTraitDisabled) strategy = null;
                var expansion = player.PlayerActor.TraitOrDefault<ImprovedMcvManagerBotModule>();
                economyLog.WriteLine(Csv(world.WorldTick, player.InternalName, player.BotType, resources.Cash, resources.Resources, resources.ResourceCapacity,
                    army.Sum(ActorCost), own.Where(a => a.Info.HasTraitInfo<BuildingInfo>()).Sum(ActorCost), own.Count(a => a.Info.HasTraitInfo<HarvesterInfo>()), army.Count(a => a.IsIdle),
                    queues.Count(q => !q.AllQueued().Any()), queues.Length, string.Join(";", queues.SelectMany(q => q.AllQueued()).Select(q => q.Item)), strategy == null ? "" : strategy.Plan.ToString(),
                    strategy == null || !strategy.Focus.HasValue ? "" : strategy.Focus.Value.X.ToString(), strategy == null || !strategy.Focus.HasValue ? "" : strategy.Focus.Value.Y.ToString(),
                    strategy == null ? "" : strategy.VisibleEnemies.Length.ToString(), strategy == null ? "" : strategy.KnownEnemies.Length.ToString(), expansion != null && expansion.RecoveringExpansion, resources.Earned, resources.Spent, LoggedIncome(player), resources.Earned - LoggedIncome(player)));
                if (strategy != null) foreach (var enemy in strategy.KnownEnemies)
                    knowledgeLog.WriteLine(Csv(world.WorldTick, player.InternalName, enemy.Id, enemy.Info.Name, enemy.Seen, enemy.Position.X, enemy.Position.Y, strategy.VisibleEnemies.Any(a => a.ActorID == enemy.Id)));
            }
        }
        void FlushTelemetry()
        { if (actorLog != null) actorLog.Flush(); if (eventLog != null) eventLog.Flush(); if (economyLog != null) economyLog.Flush(); if (knowledgeLog != null) knowledgeLog.Flush(); FlushDecisions(); }
    }
}









