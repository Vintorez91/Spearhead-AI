using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  sealed class AttackTraceState { public int Id,Next,LastMoved; public CPos Position; public string Decision="",Details="",Source=""; public uint Target; public bool Positioned; public readonly Dictionary<string,int> Samples=new Dictionary<string,int>(); }
  int nextTraceId;
  readonly Dictionary<Squad,AttackTraceState> attackTraces=new Dictionary<Squad,AttackTraceState>();
  internal void TraceAttack(Squad squad,string decision,string details="",CPos? destination=null,string source=null) {
   var logger=World.WorldActor.TraitOrDefault<AITestMetrics>();if(logger==null||!squad.IsValid)return;
   AttackTraceState state;if(!attackTraces.TryGetValue(squad,out state))attackTraces[squad]=state=new AttackTraceState{Id=++nextTraceId,LastMoved=World.WorldTick};
   var target=squad.IsTargetValid?squad.TargetActor:null;
   var goal=destination??(target==null?(CPos?)null:target.Location);
   var leader=goal.HasValue?squad.Units.OrderBy(a=>(a.Location-goal.Value).LengthSquared).FirstOrDefault():squad.Units.FirstOrDefault();if(leader==null)return;
   if(!state.Positioned||state.Position!=leader.Location){state.Position=leader.Location;state.Positioned=true;state.LastMoved=World.WorldTick;}
   var targetId=target==null?0:target.ActorID;
   var changed=state.Decision!=decision||state.Target!=targetId||state.Source!=(source??"direct");
   var sampleKey=targetId+":"+decision+":"+(source??"direct"); int sampleAt;if(state.Samples.TryGetValue(sampleKey,out sampleAt)&&World.WorldTick-sampleAt<125)return; if(state.Samples.Count>256)state.Samples.Clear();state.Samples[sampleKey]=World.WorldTick;
   var previous=state.Decision;var previousDetails=state.Details;
   state.Next=World.WorldTick+125;state.Decision=decision;state.Target=targetId;state.Details=details;state.Source=source??"direct";
   logger.TraceAttackRow(World.WorldTick,Player.InternalName,state.Id,squad.Type.ToString(),decision,previous,changed,previousDetails,state.Source,targetId,goal,leader.Location,World.WorldTick-state.LastMoved,squad.Units.Count,squad.Units.Count(a=>a.IsIdle),details);
   foreach(var stale in attackTraces.Keys.Where(s=>!Squads.Contains(s)||!s.IsValid).ToArray())attackTraces.Remove(stale);
  }
 }
 public partial class AITestMetrics {
  StreamWriter attackTraceLog;
  void InitializeAttackTrace(string prefix){attackTraceLog=new StreamWriter(prefix+"-attack-trace.csv");attackTraceLog.WriteLine("tick,player,squad_id,role,decision,previous_decision,changed,previous_details,knowledge_source,target_id,goal_x,goal_y,leader_x,leader_y,distance_cells,ticks_without_leader_movement,units,idle_units,details");}
  internal void TraceAttackRow(int tick,string player,int id,string role,string decision,string previous,bool changed,string previousDetails,string source,uint target,CPos? goal,CPos leader,int stalled,int units,int idle,string details){if(attackTraceLog!=null)attackTraceLog.WriteLine(Csv(tick,player,id,role,decision,previous,changed,previousDetails,source,target,goal.HasValue?goal.Value.X.ToString():"",goal.HasValue?goal.Value.Y.ToString():"",leader.X,leader.Y,goal.HasValue?(goal.Value-leader).Length.ToString():"",stalled,units,idle,details));}
 }
}

