using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Primitives;
using OpenRA.Mods.Common.Warheads;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedBaseBuilderBotModule
 {
  Actor defenceAnchor; CPos defenceDirection; bool defenceThreat, defenceNeedsAir; int nextDefenceReview;
  internal Actor TargetedDefenceAnchor { get { ReviewDefence(); return defenceAnchor; } }
  void ReviewDefence() {
   if(world.WorldTick<nextDefenceReview && defenceAnchor!=null && !defenceAnchor.IsDead && defenceAnchor.IsInWorld) return;
   nextDefenceReview=world.WorldTick+125; defenceAnchor=null;
   var own=world.Actors.Where(a=>a.Owner==player&&!a.IsDead&&a.IsInWorld).ToArray();
   var strategy=player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>(); if(strategy!=null) strategy.Refresh();
   var known=strategy==null?new ImprovedStrategyBotModule.Observation[0]:strategy.KnownEnemies;
   var yards=own.Where(a=>a.Info.Name=="fact").ToArray();
   var anchors=yards.Concat(own.Where(a=>a.Info.Name=="proc"&&!yards.Any(y=>(y.Location-a.Location).LengthSquared<144))).ToArray();
   var air=known.Where(e=>e.Armed&&e.Info.HasTraitInfo<AircraftInfo>()&&world.WorldTick-e.Seen<=1500).ToArray();
   double best=double.MinValue;
   foreach(var anchor in anchors) {
    var forward=(anchor.Location-player.HomeLocation).LengthSquared>324;
    var threats=known.Where(e=>e.Armed&&(e.Position-anchor.Location).LengthSquared<900).ToArray();
    var urgent=threats.Any(e=>(e.Position-anchor.Location).LengthSquared<225);
    var count=own.Count(a=>a.Info.HasTraitInfo<BuildingInfo>()&&a.Info.HasTraitInfo<AttackBaseInfo>()&&!IsAirDefence(a.Info)&&(a.Location-anchor.Location).LengthSquared<225);
    var nearbyAir=air.Count(e=>(e.Position-anchor.Location).LengthSquared<=400);
    var aaCount=own.Count(a=>a.Info.HasTraitInfo<BuildingInfo>()&&IsAirDefence(a.Info)&&(a.Location-anchor.Location).LengthSquared<225);
    var needsAir=(air.Length>=3||nearbyAir>0)&&aaCount<(air.Length>=6||nearbyAir>=3?2:1);
    var cap=urgent?4:forward?2:1; if(count>=cap&&!needsAir) continue;
    var score=(needsAir?100:0)+(urgent?150:0)+(forward?50:0)+threats.Length*10-count*30;
    if(score<=best) continue;
    best=score; defenceAnchor=anchor; defenceThreat=urgent; defenceNeedsAir=needsAir;
    defenceDirection=threats.OrderBy(e=>(e.Position-anchor.Location).LengthSquared).Select(e=>(CPos?)e.Position).FirstOrDefault()??known.OrderBy(e=>(e.Position-anchor.Location).LengthSquared).Select(e=>(CPos?)e.Position).FirstOrDefault()??anchor.Location;
   }
  }
  internal ActorInfo ChooseTargetedDefence(IEnumerable<ActorInfo> buildable) {
   ReviewDefence(); if(defenceAnchor==null) return null;
   if(!defenceThreat&&playerResources.Cash+playerResources.Resources<1200) return null;
   if(!defenceThreat&&!defenceNeedsAir&&GetDefenceChokes(defenceAnchor).Count==0) return null;
   var strategy=player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>();
   var threats=strategy==null?new ImprovedStrategyBotModule.Observation[0]:strategy.KnownEnemies.Where(e=>e.Armed&&(e.Position-defenceAnchor.Location).LengthSquared<900).ToArray();
   var candidates=buildable.Where(a=>a.HasTraitInfo<BuildingInfo>()&&a.HasTraitInfo<AttackBaseInfo>()).ToArray();
   if(defenceNeedsAir){
    var antiAir=candidates.Where(IsAirDefence).Where(a=>!Info.BuildingLimits.ContainsKey(a.Name)||world.Actors.Count(o=>o.Owner==player&&!o.IsDead&&o.Info.Name==a.Name)<Info.BuildingLimits[a.Name])
     .OrderByDescending(a=>DefenceMatchup(a,strategy.KnownEnemies.Where(e=>e.Armed&&e.Info.HasTraitInfo<AircraftInfo>()&&world.WorldTick-e.Seen<=1500).ToArray())).FirstOrDefault();
    if(antiAir!=null)return antiAir;
   }
   return candidates
    .Where(a=>!Info.BuildingLimits.ContainsKey(a.Name)||world.Actors.Count(o=>o.Owner==player&&!o.IsDead&&o.Info.Name==a.Name)<Info.BuildingLimits[a.Name])
    .Where(a=>threats.Length>0||new[]{"pbox","hbox","ftur"}.Contains(a.Name))
    .Where(a=>threats.Length==0||DefenceMatchup(a,threats)>0)
    .OrderByDescending(a=>DefenceMatchup(a,threats)).FirstOrDefault();
  }
  bool IsAirDefence(ActorInfo candidate){return candidate.TraitInfos<ArmamentInfo>().Any(a=>world.Map.Rules.Weapons[a.Weapon.ToLowerInvariant()].IsValidTarget(new BitSet<TargetableType>("Air", "AirborneActor")));}
  double DefenceMatchup(ActorInfo candidate, ImprovedStrategyBotModule.Observation[] enemies) {
   var cost=candidate.TraitInfoOrDefault<ValuedInfo>(); var price=cost==null?1000:Math.Max(1,cost.Cost);
   if(enemies.Length==0) return 1.0/price;
   double damage=0; foreach(var arm in candidate.TraitInfos<ArmamentInfo>()) {
    var weapon=world.Map.Rules.Weapons[arm.Weapon.ToLowerInvariant()];
    foreach(var enemy in enemies.Where(e=>weapon.IsValidTarget(e.TargetTypes)))
     foreach(var wh in weapon.Warheads.OfType<DamageWarhead>())
      damage+=Math.Max(0,wh.Damage)*(enemy.Armor!=null&&wh.Versus.ContainsKey(enemy.Armor)?wh.Versus[enemy.Armor]/100.0:1)*weapon.Burst/Math.Max(1,weapon.ReloadDelay)*enemy.Value;
   }
   return damage/price;
  }
  internal CPos? FindTargetedDefenceLocation(string actorType) {
   ReviewDefence(); if(defenceAnchor==null) return null;
   var info=world.Map.Rules.Actors[actorType];var building=info.TraitInfo<BuildingInfo>();
   var locomotor=world.WorldActor.TraitsImplementing<Locomotor>().FirstOrDefault(l=>l.Info.Name=="foot");
   var domain=new DomainIndex(world);
   var own=world.Actors.Where(a=>a.Owner==player&&!a.IsDead&&a.IsInWorld).ToArray();
   var candidates=world.Map.FindTilesInAnnulus(defenceAnchor.Location,3,12)
    .Where(c=>world.CanPlaceBuilding(c,info,building,null)&&building.IsCloseEnoughToBase(world,player,info,c))
    .Where(c=>own.Where(a=>a.Info.Name=="proc"||a.Info.Name=="weap"||a.Info.Name=="fact").All(a=>(a.Location-c).LengthSquared>=16));
      var chokes=GetDefenceChokes(defenceAnchor);
   var range=info.TraitInfos<ArmamentInfo>().Select(a=>world.Map.Rules.Weapons[a.Weapon.ToLowerInvariant()].Range.Length/1024.0).DefaultIfEmpty(0).Max();
   var cell=candidates.Where(c=>player.Shroud.IsExplored(c)).OrderByDescending(c=>{
    var open=locomotor==null?25:world.Map.FindTilesInCircle(c,2).Count(n=>player.Shroud.IsExplored(n)&&domain.IsPassable(defenceAnchor.Location,n,locomotor));
    var narrow=open>=6&&open<=16?30:0;
        var coverage=chokes.Where(choke=>(choke.Cell-c).Length<=range).Select(choke=>80+choke.Routes*15-choke.Width*5-(choke.Cell-c).Length*2).DefaultIfEmpty(0).Max();
    return coverage+narrow*0.2-(c-defenceDirection).Length*0.3-(c-defenceAnchor.Location).Length*0.3;
   }).Select(c=>(CPos?)c).FirstOrDefault();
   if(cell.HasValue) Console.WriteLine("AI-CHOKE placement="+cell.Value+" covering="+string.Join(";",chokes.Where(choke=>(choke.Cell-cell.Value).Length<=range).Select(choke=>choke.Cell.ToString())));
   if(cell.HasValue) Console.WriteLine("AI-DEFENCE anchor="+defenceAnchor.Location+" forward="+((defenceAnchor.Location-player.HomeLocation).LengthSquared>324)+" threat="+defenceThreat+" building="+actorType+" location="+cell.Value);
   return cell;
  }
 }
}



