using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  readonly Dictionary<Actor,Actor> navalEscorts=new Dictionary<Actor,Actor>();
  internal Actor NavalEscortedCapital(Actor unit){Actor capital;return navalEscorts.TryGetValue(unit,out capital)?capital:null;}
  void AssignNavalEscorts(Actor[] ships,Actor[] visible){
   var capitals=ships.Where(a=>a.Info.Name=="ca"||a.Info.Name=="msub").Where(a=>NavalMissionTarget(a)!=null&&NavalVisibleEnemy(NavalMissionTarget(a))||visible.Any(t=>t.Info.HasTraitInfo<BuildingInfo>()&&NavalTargetSuitable(a,t)&&NavalFirePosition(a,t).HasValue)).ToArray();
   foreach(var unit in navalEscorts.Keys.ToArray())if(!ships.Contains(unit)||!capitals.Contains(navalEscorts[unit])){navalEscorts.Remove(unit);NavalMission m;if(navalMissions.TryGetValue(unit,out m)&&m.Mode=="guard"){m.Destination=null;m.Target=null;m.Ordered=-10000;}}
   foreach(var capital in capitals){
    var remaining=2-navalEscorts.Count(k=>k.Value==capital);
    var candidates=ships.Where(a=>a!=capital&&!navalEscorts.ContainsKey(a)&&(a.Info.Name=="dd"||a.Info.Name=="ss"||a.Info.Name=="pt"))
     .Where(a=>World.WorldActor.Trait<IPathFinder>().PathExistsForLocomotor(a.Trait<Mobile>().Locomotor,a.Location,capital.Location))
     .OrderBy(a=>a.Info.Name=="dd"?0:a.Info.Name=="ss"?1:2).ThenBy(a=>(a.Location-capital.Location).LengthSquared).Take(Math.Max(0,remaining));
    foreach(var unit in candidates){navalEscorts[unit]=capital;Console.WriteLine("AI-NAVAL ESCORT tick="+World.WorldTick+" unit="+unit.ActorID+" capital="+capital.ActorID+" assigned=True");}
   }
  }
  bool QueueNavalEscort(Squad squad,Actor unit,NavalMission mission,Actor[] visible){
   Actor capital;if(!navalEscorts.TryGetValue(unit,out capital))return false;
   var threats=visible.Where(e=>NavalTargetSuitable(unit,e)||e.Info.HasTraitInfo<AircraftInfo>()&&AttackOrFleeFuzzy.SuitableAttacker(unit,e))
    .Where(e=>e.TraitOrDefault<Mobile>()!=null||e.Info.HasTraitInfo<AircraftInfo>())
    .Where(e=>(e.Location-capital.Location).LengthSquared<=144)
    .Where(e=>(e.Location-capital.Location).LengthSquared<=36||AttackOrFleeFuzzy.EffectiveDamage(e,new[]{capital,unit})>0).ToArray();
   var retained=mission.Target!=null&&threats.Contains(mission.Target)?mission.Target:null;
   var target=retained??threats.OrderByDescending(e=>AttackOrFleeFuzzy.EffectiveDamage(e,new[]{capital,unit})).ThenBy(e=>(e.Location-capital.Location).LengthSquared).FirstOrDefault();
   if(target!=null){
    var position=NavalFirePosition(unit,target);
    // Intercept locally, never chase a target far away from the protected ship.
    if(position.HasValue&&(position.Value-capital.Location).LengthSquared<=144){
     if(mission.Target!=target){mission.Target=target;mission.Destination=position;mission.Ordered=-10000;mission.Progress=World.WorldTick;mission.Mode="intercept";Console.WriteLine("AI-NAVAL ESCORT tick="+World.WorldTick+" unit="+unit.ActorID+" mode=intercept target="+target.ActorID);}
     return false;
    }
   }
   mission.Target=null;
   if((unit.Location-capital.Location).LengthSquared<=36){
    if(mission.Mode!="guard"&&!unit.IsIdle)squad.Bot.QueueOrder(new Order("Stop",unit,false));
    mission.Mode="guard";mission.Destination=null;mission.Progress=World.WorldTick;return true;
   }
   var mobile=unit.Trait<Mobile>();var finder=World.WorldActor.Trait<IPathFinder>();
   var center=capital.Location;NavalMission capMission;if(navalMissions.TryGetValue(capital,out capMission)&&capMission.Destination.HasValue)center=capMission.Destination.Value;
   if(mission.Mode=="guard"&&!unit.IsIdle&&mission.Destination.HasValue&&(mission.Destination.Value-center).LengthSquared<=36)return true;
   var guard=World.Map.FindTilesInAnnulus(center,2,5).Where(c=>Player.Shroud.IsExplored(c)&&mobile.Info.CanEnterCell(World,unit,c))
    .Where(c=>!navalEscorts.Any(k=>k.Key!=unit&&navalMissions.ContainsKey(k.Key)&&navalMissions[k.Key].Destination==c))
    .OrderBy(c=>(unit.Location-c).LengthSquared).Where(c=>finder.PathExistsForLocomotor(mobile.Locomotor,unit.Location,c)).Select(c=>(CPos?)c).FirstOrDefault();
   if(guard.HasValue&&(mission.Mode!="guard"||unit.IsIdle||!mission.Destination.HasValue||(mission.Destination.Value-guard.Value).LengthSquared>36)){
    squad.Bot.QueueOrder(new Order("Move",unit,Target.FromCell(World,guard.Value),false));mission.Destination=guard;mission.Mode="guard";mission.Ordered=World.WorldTick;mission.Progress=World.WorldTick;
    Console.WriteLine("AI-NAVAL ESCORT tick="+World.WorldTick+" unit="+unit.ActorID+" mode=guard capital="+capital.ActorID+" water="+guard);
   }
   return true;
  }
 }
}
