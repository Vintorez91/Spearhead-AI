# Testing and limits

The 40-game schedule is a development benchmark, not a randomized statistical evaluation of a single frozen release. Revisions changed during the run, and the last four use early scouting plus expansion-placement logging. Compare version columns before making claims.

Games use the accelerated test harness except spectator games. The harness supplies a construction yard, power plant, barracks and refinery to both sides. User release games use normal lobby starts. At 60 game minutes a match may time out; assessed outcomes are recorded separately. User-confirmed outcomes retain their reason. The seed parameter does not guarantee identical gameplay randomness.

Directed tests checked scouting recruitment/recall, expansion-placement diagnostic transitions and other development behaviors. The later fixed-rush scouting experiment disabled production, repairs and expansion to isolate behavior. It produced mixed results and was stopped; oil capture income and continuing production were not represented. An earlier scouting run had mismatched map configuration and is invalid, excluded from benchmark evidence.

Do not interpret absent bot orders as absent unit response: automatic targeting can fire without a bot order. Geometric distance alone does not establish a bad route. Repeated telemetry samples are not independent incidents.

The public-menu packaging must be checked independently from the development harness: stock start units, no injected buildings, available bot label, normal production and complete match. Local validation status is recorded in VALIDATION.md.
