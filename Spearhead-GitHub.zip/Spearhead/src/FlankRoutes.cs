using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
    public partial class ImprovedSquadManagerBotModule
    {
        sealed class FlankRoute { public uint TargetId; public CPos Waypoint; public bool Complete; public List<CPos> Path; public int Index; }
        readonly Dictionary<Squad, FlankRoute> flankRoutes = new Dictionary<Squad, FlankRoute>();

        internal void QueueApproach(Squad squad)
        {
            if (!squad.IsTargetValid) return;
            var target = squad.TargetActor;
            var leader = squad.Units.Where(a=>!a.IsDead&&a.IsInWorld&&a.TraitOrDefault<Mobile>()!=null).OrderBy(a=>(a.Location-target.Location).LengthSquared).FirstOrDefault();
            if (leader == null) return;
            FlankRoute route;
            if (!flankRoutes.TryGetValue(squad, out route) || route.TargetId != target.ActorID)
            {
                List<CPos> path;
                if(!OffensiveRouteReady(squad,target,out path)){HoldRejectedAttack(squad);MarkUnreachable(target);return;}
                route=new FlankRoute {TargetId=target.ActorID,Path=path,Complete=path.Count==0};flankRoutes[squad]=route;
                if(!route.Complete){route.Index=Math.Min(5,path.Count-1);route.Waypoint=path[route.Index];Console.WriteLine("AI-FLANK safe route target="+target.Info.Name+" cells="+path.Count);}
            }
            if(!route.Complete&&(leader.Location-route.Waypoint).LengthSquared<9){route.Index=Math.Min(route.Index+6,route.Path.Count-1);route.Waypoint=route.Path[route.Index];if(route.Index==route.Path.Count-1&&(leader.Location-route.Waypoint).LengthSquared<9)route.Complete=true;}            
            var destination = route.Complete ? target.Location : route.Waypoint;
            var suitable = squad.Units.Where(a => AttackOrFleeFuzzy.SuitableAttacker(a, target)).ToArray();
            if (suitable.Length == 0) return;
                        var rookies = suitable.Where(a => VeteranRank(a) == 0).ToArray();
            var guarded = route.Complete && World.FindActorsInCircle(target.CenterPosition, WDist.FromCells(8)).Any(a => IsPreferredEnemyUnit(a) && a.Info.HasTraitInfo<AttackBaseInfo>());
            if (guarded && rookies.Length > 0) {
                squad.Bot.QueueOrder(new Order("AttackMove", null, Target.FromCell(World, destination), false, groupedActors: rookies));
                var delta = leader.Location - target.Location;
                var length = Math.Max(1, Math.Sqrt(delta.LengthSquared));
                var rear = destination + new CVec((int)Math.Round(delta.X / length * 2), (int)Math.Round(delta.Y / length * 2));
                foreach (var veteran in suitable.Except(rookies)) {
                    var mobile = veteran.TraitOrDefault<Mobile>();
                    var safe = World.Map.Contains(rear) && Player.Shroud.IsExplored(rear) && mobile != null && new DomainIndex(World).IsPassable(veteran.Location, rear, mobile.Locomotor);
                    squad.Bot.QueueOrder(new Order("AttackMove", veteran, Target.FromCell(World, safe ? rear : destination), false));
                }
            } else squad.Bot.QueueOrder(new Order("AttackMove", null, Target.FromCell(World, destination), false, groupedActors: suitable));
            foreach (var a in squad.Units.Except(suitable).Where(a => !a.IsIdle)) squad.Bot.QueueOrder(new Order("Stop", a, false));
        }
    }
}


