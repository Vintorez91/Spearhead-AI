using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  readonly Dictionary<Actor,CPos> navalRecoveryGoals=new Dictionary<Actor,CPos>();
  readonly Dictionary<Actor,int> navalRecoveryUntil=new Dictionary<Actor,int>();
  internal bool NavalRecoveryPending(Actor unit){return navalRecoveryGoals.ContainsKey(unit);}
  void RememberNavalContact(NavalMission mission){if(mission.Target!=null&&NavalVisibleEnemy(mission.Target)){mission.Contact=mission.Target.Location;mission.ContactSeen=World.WorldTick;}}
  bool RecoverNavalContact(Squad squad,Actor capital,NavalMission mission,Actor[] ships){
   if(!mission.Contact.HasValue||World.WorldTick-mission.ContactSeen>750||Player.Shroud.IsVisible(mission.Contact.Value))return false;
   var contact=mission.Contact.Value;
   var scout=ships.Where(a=>a!=capital&&(a.Info.Name=="pt"||a.Info.Name=="dd"||a.Info.Name=="ss"))
    .Where(a=>!navalRecoveryGoals.ContainsKey(a)||navalRecoveryGoals[a]==contact)
    .OrderBy(a=>a.Info.Name=="pt"?0:a.Info.Name=="dd"?1:2).ThenBy(a=>(a.Location-contact).LengthSquared).FirstOrDefault();
   if(scout==null)return false;
   if(navalRecoveryGoals.ContainsKey(scout))return true;
   var mobile=scout.Trait<Mobile>();var finder=World.WorldActor.Trait<IPathFinder>();
   var dangers=Strategy.KnownEnemies.Where(o=>o.Armed&&World.WorldTick-o.Seen<1500).Select(o=>o.Position).ToArray();
   var position=World.Map.FindTilesInAnnulus(contact,4,6).Where(c=>mobile.Info.CanEnterCell(World,scout,c)&&dangers.All(d=>(d-c).LengthSquared>36))
    .OrderBy(c=>(c-scout.Location).LengthSquared).Where(c=>finder.PathExistsForLocomotor(mobile.Locomotor,scout.Location,c)).Select(c=>(CPos?)c).FirstOrDefault();
   if(!position.HasValue)return false;
   navalRecoveryGoals[scout]=contact;navalRecoveryUntil[scout]=World.WorldTick+500;
   squad.Bot.QueueOrder(new Order("Move",scout,Target.FromCell(World,position.Value),false));
   Console.WriteLine("AI-NAVAL RECOVER tick="+World.WorldTick+" capital="+capital.ActorID+" scout="+scout.ActorID+" remembered="+contact+" water="+position);return true;
  }
  bool NavalRecoveryScout(Actor unit){
   CPos contact;if(!navalRecoveryGoals.TryGetValue(unit,out contact))return false;
   if(unit.IsDead||!unit.IsInWorld||Player.Shroud.IsVisible(contact)||World.WorldTick>=navalRecoveryUntil[unit]){navalRecoveryGoals.Remove(unit);navalRecoveryUntil.Remove(unit);return false;}
   return true;
  }
 }
}

