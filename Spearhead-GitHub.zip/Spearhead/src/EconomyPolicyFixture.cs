using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
using OpenRA.Traits;
using OpenRA.Primitives;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedStrategyBotModule { internal void ForceSituationProbe(){nextTick=0;Refresh();} }
 public partial class ImprovedSquadManagerBotModule {
  internal void ProbeAssignIdle(IBot bot){FindNewUnits(bot);}
  internal void ProbeWithdraw(ProbeBot bot,Actor unit){var s=RegisterNewSquad(bot,SquadType.Assault);s.Units.Add(unit);ProbeEconomicOperations(bot);}
 }
 public partial class AITestMetrics {
  Player policyOwn,policyEnemy;Actor policyForward,policyThreat,policyUnit,policyCoastTarget,policyHiddenTarget,policyScout,policyYard,policyWeakForward;CPos policySea;
  int policyWrongReturn,policyReturnOrders;bool policyHold,policyReleased,policyBlocked,policyConnected,policyHidden;string policyQueueChoice;bool policyProtectedForward;
  void CheckEconomyPolicy(World world){
   if(world.WorldTick==2){foreach(var p in world.Players.Where(p=>p.IsBot))foreach(var b in p.PlayerActor.TraitsImplementing<ModularBot>())b.IsEnabled=false;
    world.AddFrameEndTask(w=>{
     policyOwn=w.Players.First(p=>p.IsBot&&p.BotType=="improved");policyEnemy=w.Players.First(p=>p.Playable&&p.RelationshipWith(policyOwn)==PlayerRelationship.Enemy);
     var mobile=w.Map.Rules.Actors["2tnk"].TraitInfo<MobileInfo>();var proc=w.Map.Rules.Actors["proc"];var building=proc.TraitInfo<BuildingInfo>();
     var cell=w.Map.FindTilesInAnnulus(policyOwn.HomeLocation,28,40).First(c=>w.CanPlaceBuilding(c,proc,building,null)&&mobile.CanEnterCell(w,null,c+new CVec(8,0))&&mobile.CanEnterCell(w,null,c+new CVec(0,-5)));
     policyForward=w.CreateActor("proc",new TypeDictionary{new OwnerInit(policyOwn),new LocationInit(cell)});
     var factCell=w.Map.FindTilesInAnnulus(cell,5,8).First(c=>w.CanPlaceBuilding(c,w.Map.Rules.Actors["fact"],w.Map.Rules.Actors["fact"].TraitInfo<BuildingInfo>(),null));w.CreateActor("fact",new TypeDictionary{new OwnerInit(policyOwn),new LocationInit(factCell)});
     policyThreat=w.CreateActor("3tnk",new TypeDictionary{new OwnerInit(policyEnemy),new LocationInit(cell+new CVec(8,0))});policyUnit=w.CreateActor("2tnk",new TypeDictionary{new OwnerInit(policyOwn),new LocationInit(cell+new CVec(0,-5))});
     w.CreateActor("camera",new TypeDictionary{new OwnerInit(policyOwn),new LocationInit(policyThreat.Location)});
     Console.WriteLine("AI-POLICY TEST forward="+cell+" main="+policyOwn.HomeLocation);
    });
   }
   if(world.WorldTick==150){
    var strategy=policyOwn.PlayerActor.Trait<ImprovedStrategyBotModule>();strategy.ForceSituationProbe();if(strategy.HomeEnemies.Length==0||!strategy.HoldingOffense)throw new InvalidOperationException("Fixture did not create urgent visible economic threat");
    var manager=policyOwn.PlayerActor.Trait<ImprovedSquadManagerBotModule>();var bot=new ProbeBot(policyOwn);
    for(var i=0;i<30;i++){manager.ProbeWithdraw(bot,policyUnit);}
    var moves=bot.Orders.Where(o=>o.Subject==policyUnit&&o.OrderString=="Move").ToArray();policyReturnOrders=moves.Length;policyWrongReturn=moves.Count(o=>(o.Target.CenterPosition-policyForward.CenterPosition).LengthSquared>225L*1024*1024);
    if(EconomicDefenseEnabled&&policyWrongReturn>0)throw new InvalidOperationException("Economic defence sent retreat orders away from the threatened expansion");
    if(!EconomicDefenseEnabled&&policyWrongReturn==0)throw new InvalidOperationException("Baseline did not reproduce random main return");
    Console.WriteLine("AI-POLICY TEST return_orders="+policyReturnOrders+" distant_main_returns="+policyWrongReturn);
    world.AddFrameEndTask(w=>policyThreat.Dispose());
   }
   if(world.WorldTick==300){var manager=policyOwn.PlayerActor.Trait<ImprovedSquadManagerBotModule>();policyOwn.PlayerActor.Trait<ImprovedStrategyBotModule>().ForceSituationProbe();manager.ProbeEconomicOperations(new ProbeBot(policyOwn));policyHold=manager.EconomicDefenseHolding;if(EconomicDefenseEnabled&&!policyHold)throw new InvalidOperationException("Defence hold lost immediately after threat disappearance");world.AddFrameEndTask(w=>{w.CreateActor("e1",new TypeDictionary{new OwnerInit(policyEnemy),new LocationInit(policyOwn.HomeLocation+new CVec(8,0))});policyWeakForward=w.CreateActor("e1",new TypeDictionary{new OwnerInit(policyEnemy),new LocationInit(policyForward.Location+new CVec(8,0))});});}
   if(world.WorldTick==450){var manager=policyOwn.PlayerActor.Trait<ImprovedSquadManagerBotModule>();manager.ProbeAssignIdle(new ProbeBot(policyOwn));policyOwn.PlayerActor.Trait<ImprovedStrategyBotModule>().ForceSituationProbe();manager.ProbeEconomicOperations(new ProbeBot(policyOwn));var guard=manager.Squads.FirstOrDefault(s=>s.Type==SquadType.Protection);policyProtectedForward=guard!=null&&guard.IsTargetValid&&guard.TargetActor==policyWeakForward;if(EconomicDefenseEnabled&&!policyProtectedForward)throw new InvalidOperationException("Hold did not assign actual protection squad to the forward threat");}
   if(world.WorldTick==1000){var manager=policyOwn.PlayerActor.Trait<ImprovedSquadManagerBotModule>();manager.ProbeEconomicOperations(new ProbeBot(policyOwn));policyReleased=!manager.EconomicDefenseHolding;if(!policyReleased)throw new InvalidOperationException("Defence hold never expired");
    world.AddFrameEndTask(w=>{
     var ship=w.Map.Rules.Actors["ca"].TraitInfo<MobileInfo>();var power=w.Map.Rules.Actors["powr"];var info=power.TraitInfo<BuildingInfo>();var coast=w.Map.AllCells.Where(c=>w.CanPlaceBuilding(c,power,info,null)).Select(c=>new{Cell=c,Water=w.Map.FindTilesInAnnulus(c,7,10).Where(t=>ship.CanEnterCell(w,null,t)).Select(t=>(CPos?)t).FirstOrDefault()}).First(x=>x.Water.HasValue);policySea=coast.Water.Value;
     policyYard=w.CreateActor(policyOwn.Faction.InternalName=="russia"||policyOwn.Faction.InternalName=="ukraine"?"spen":"syrd",new TypeDictionary{new OwnerInit(policyOwn),new LocationInit(policySea)});
     policyCoastTarget=w.CreateActor("powr",new TypeDictionary{new OwnerInit(policyEnemy),new LocationInit(coast.Cell)});
     policyHiddenTarget=w.CreateActor("powr",new TypeDictionary{new OwnerInit(policyEnemy),new LocationInit(w.Map.AllCells.Where(c=>w.CanPlaceBuilding(c,power,info,null)).OrderByDescending(c=>(c-coast.Cell).LengthSquared).First())});
     foreach(var name in new[]{"dome","weap","atek","stek"}){var a=w.Map.Rules.Actors[name];var pos=w.Map.FindTilesInAnnulus(policyOwn.HomeLocation,8,25).First(c=>w.CanPlaceBuilding(c,a,a.TraitInfo<BuildingInfo>(),null));w.CreateActor(name,new TypeDictionary{new OwnerInit(policyOwn),new LocationInit(pos)});}
    });
   }
   if(world.WorldTick==1100){
    var strategy=policyOwn.PlayerActor.Trait<ImprovedStrategyBotModule>();strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation[0]);strategy.ResetNavalBudgetProbe();
    var capital=world.Map.Rules.Actors[policyOwn.Faction.InternalName=="russia"||policyOwn.Faction.InternalName=="ukraine"?"msub":"ca"];
    policyHidden=!strategy.AllowNavalInvestment(capital);if(NavalInvestmentEnabled&&!policyHidden)throw new InvalidOperationException("Unobserved target enabled capital production");
    var builder=policyOwn.PlayerActor.Trait<ImprovedUnitBuilderBotModule>();var weights=policyOwn.PlayerActor.Info.TraitInfo<ImprovedUnitBuilderBotModuleInfo>().UnitsToBuild;
    foreach(var key in weights.Keys.ToArray())weights[key]=key==capital.Name?100000:key=="dd"||key=="pt"||key=="ss"?1:0;
    var queue=LegacyAIUtils.FindQueues(policyOwn,"Ship").First();var method=builder.GetType().GetMethod("ChooseUnitToBuild",BindingFlags.NonPublic|BindingFlags.Instance);var choice=(ActorInfo)method.Invoke(builder,new object[]{queue});policyQueueChoice=choice==null?"none":choice.Name;
    if(!NavalInvestmentEnabled&&policyQueueChoice!=capital.Name)throw new InvalidOperationException("Baseline queue did not choose forced expensive capital");
    if(NavalInvestmentEnabled&&policyQueueChoice==capital.Name)throw new InvalidOperationException("Production queue bypassed naval policy");
    policyScout=world.CreateActor("dd",new TypeDictionary{new OwnerInit(policyOwn),new LocationInit(policySea+new CVec(0,3))});
    strategy.ResetNavalBudgetProbe();if(NavalInvestmentEnabled&&strategy.AllowNavalInvestment(world.Map.Rules.Actors["dd"]))throw new InvalidOperationException("Second no-target scout allowed");
    policyOwn.Shroud.ExploreAll();var inland=world.Map.AllCells.Where(c=>world.CanPlaceBuilding(c,world.Map.Rules.Actors["powr"],world.Map.Rules.Actors["powr"].TraitInfo<BuildingInfo>(),null)).OrderByDescending(c=>world.Map.FindTilesInCircle(c,capital.TraitInfos<ArmamentInfo>().Select(a=>world.Map.Rules.Weapons[a.Weapon.ToLowerInvariant()].Range.Length/1024).Max()).Count(t=>!world.Map.Rules.Actors["ca"].TraitInfo<MobileInfo>().CanEnterCell(world,null,t))).First();
    var fake=ObservePolicy(policyCoastTarget);fake.Position=inland;strategy.ProbeKnowledge(fake);strategy.ResetNavalBudgetProbe();policyBlocked=!strategy.AllowNavalInvestment(capital);
    // The inland check is diagnostic; map islands may all be within capital weapon range.
    strategy.ProbeKnowledge(ObservePolicy(policyCoastTarget));strategy.ResetNavalBudgetProbe();policyConnected=strategy.AllowNavalInvestment(capital);if(!policyConnected)throw new InvalidOperationException("Reachable known coast failed to allow capital production");
    Console.WriteLine("AI-POLICY TEST naval queue="+policyQueueChoice+" hidden_rejected="+policyHidden+" inland_rejected="+policyBlocked+" coast_allowed="+policyConnected);
   }
   if(world.WorldTick==1150){var text="PASS defense="+EconomicDefenseEnabled+" naval="+NavalInvestmentEnabled+" returns="+policyReturnOrders+" wrong_returns="+policyWrongReturn+" hold_after_contact="+policyHold+" released="+policyReleased+" protected_forward="+policyProtectedForward+" queue="+policyQueueChoice+" hidden_rejected="+policyHidden+" inland_rejected="+policyBlocked+" coast_allowed="+policyConnected;File.WriteAllText(Path.Combine(Platform.SupportDir,"policy-result.txt"),text);Console.WriteLine("AI-POLICY TEST "+text);Game.Exit();}
  }
  ImprovedStrategyBotModule.Observation ObservePolicy(Actor a){return new ImprovedStrategyBotModule.Observation{Id=a.ActorID,Info=a.Info,Owner=a.Owner,Position=a.Location,Seen=a.World.WorldTick,Value=a.GetSellValue(),Building=a.Info.HasTraitInfo<BuildingInfo>(),Armed=a.Info.HasTraitInfo<AttackBaseInfo>(),Armor=a.TraitsImplementing<Armor>().Where(t=>!t.IsTraitDisabled).Select(t=>t.Info.Type).FirstOrDefault(),TargetTypes=a.GetEnabledTargetTypes()};}
 }
}



