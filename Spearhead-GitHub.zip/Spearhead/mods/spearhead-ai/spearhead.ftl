bot-spearhead-ai = Spearhead AI
