using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
using OpenRA.Traits;
using OpenRA.Primitives;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 sealed class CombatProbeBot : IBot {
  readonly World world;public Player Player{get;private set;}public IBotInfo Info=>null;
  public int AttackOrders;
  public CombatProbeBot(World w,Player p){world=w;Player=p;}
  public void Activate(Player p){Player=p;}
  public void QueueOrder(Order o){if(o.OrderString=="Attack"||o.OrderString=="AttackMove")AttackOrders++;world.IssueOrder(o);}
 }
 public partial class AITestMetrics {
  Actor[] breakArmy,breakGuards; Actor breakObjective,breakCamera;
  Squad breakSquad; CombatProbeBot breakBot; ImprovedSquadManagerBotModule breakManager;
  object originalBreakState,originalBreakSquad; int guardClearTick=-1,objectiveTick=-1; bool breakReported,breakSetup;
  string breakMode,initialDecision;
  void SetupBreakCombat(World w) {
   foreach(var p in w.Players.Where(p=>p.IsBot))foreach(var b in p.PlayerActor.TraitsImplementing<ModularBot>())b.IsEnabled=false;
   w.AddFrameEndTask(world=>{
    var own=world.Players.First(p=>p.IsBot&&p.BotType=="improved");
    var enemy=world.Players.First(p=>p.Playable&&p.RelationshipWith(own)==PlayerRelationship.Enemy);
    var mobile=world.Map.Rules.Actors["2tnk"].TraitInfo<MobileInfo>();
    var start=world.Map.FindTilesInAnnulus(own.HomeLocation,14,24).First(c=>mobile.CanEnterCell(world,null,c)&&!world.Actors.Any(a=>a.OccupiesSpace!=null&&a.Location==c));
    var loco=world.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==mobile.Locomotor);
    List<CPos> path=null;
    foreach(var dst in world.Map.AllCells.Where(c=>mobile.CanEnterCell(world,null,c)).OrderByDescending(c=>(c-start).LengthSquared).Take(40)){
     var candidate=FairNavigation.Route(world,own,loco,start,dst,0,new CPos[0],false);
     if(candidate.Count>=35){path=candidate;break;}
    }
    if(path==null)throw new InvalidOperationException("No fixture route");
    path.Insert(0,start);
    Func<string,Player,CPos,Actor> make=(name,p,c)=>world.CreateActor(name,new TypeDictionary{new OwnerInit(p),new LocationInit(c)});
    var powerSites=world.Map.FindTilesInAnnulus(enemy.HomeLocation,5,12).Where(c=>world.Map.Contains(c+new CVec(-1,-1))&&world.Map.Contains(c+new CVec(3,3))).ToArray(); make("powr",enemy,powerSites.First()); make("powr",enemy,powerSites.Last());
    var weak=TestScenario.EndsWith("-weak");breakMode=TestScenario.Substring("breakcombat-".Length);
    breakArmy=Enumerable.Range(0,weak?4:8).Select(i=>make(weak?"e1":"2tnk",own,path[i])).ToArray();
    var far=TestScenario.EndsWith("-far");var goalIndex=far?Math.Min(90,path.Count-1):27;
    var guardCells=new[]{path[goalIndex-10],path[goalIndex-8],path[goalIndex-6]};
    breakGuards=new[]{make("tsla",enemy,guardCells[0]),make("tsla",enemy,guardCells[1]),make("ftur",enemy,guardCells[2])};
    breakObjective=make("proc",enemy,path[goalIndex]);
    breakCamera=make(breakMode=="old"?"breakthrough.camera":"camera",own,breakMode=="old"?path[goalIndex]+new CVec(1,1):path[goalIndex-8]);
    own.Shroud.ExploreAll();
    breakManager=own.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
    breakBot=new CombatProbeBot(world,own);
    breakSquad=new Squad(breakBot,breakManager,SquadType.Assault,breakObjective);breakSquad.Units.AddRange(breakArmy);
    breakManager.Strategy.ProbeKnowledge(breakGuards.Select(a=>new ImprovedStrategyBotModule.Observation{
     Id=a.ActorID,Info=a.Info,Owner=enemy,Position=a.Location,Building=true,Armed=true,
     Seen=world.WorldTick-(breakMode=="old"?8000:0),Value=a.GetSellValue()}).ToArray());
    if(ProbeVariant=="original"){
     var manager=own.PlayerActor.TraitsImplementing<OpenRA.Mods.Common.Traits.SquadManagerBotModule>().First();
     var s=new OpenRA.Mods.Common.Traits.BotModules.Squads.Squad(breakBot,manager,OpenRA.Mods.Common.Traits.BotModules.Squads.SquadType.Assault,(breakObjective,WVec.Zero));
     foreach(var a in breakArmy)s.Units.Add(a);
     originalBreakSquad=s;
     var type=typeof(OpenRA.Mods.Common.Traits.BotModules.Squads.Squad).Assembly.GetType("OpenRA.Mods.Common.Traits.BotModules.Squads.GroundUnitsAttackState");
     originalBreakState=Activator.CreateInstance(type,true);
    }
    breakSetup=true;
    Console.WriteLine("AI-COMBAT SETUP variant="+ProbeVariant+" case="+breakMode+" units="+breakArmy.Length+" route_start="+start+" guards="+string.Join("|",guardCells));
   });
  }
  internal static readonly string ProbeVariant="corrected";
  void CheckBreakCombat(World world) {
   if(world.WorldTick==2&&!breakSetup)SetupBreakCombat(world);
   if(!breakSetup||breakReported||world.WorldTick<20)return;
   if(world.WorldTick==20) {
    if(!breakGuards.All(a=>a.TraitsImplementing<Armament>().Any(t=>!t.IsTraitDisabled&&!t.IsTraitPaused)))throw new InvalidOperationException("Defense unpowered or unarmed");
    Console.WriteLine("AI-COMBAT VISION guards="+breakGuards.Count(a=>a.CanBeViewedByPlayer(breakArmy[0].Owner))+" objective="+breakObjective.CanBeViewedByPlayer(breakArmy[0].Owner));
   }
   breakSquad.Units.RemoveAll(a=>a.IsDead||!a.IsInWorld);
   if(world.WorldTick%25==20&&breakSquad.IsValid&&!breakObjective.IsDead){
    if(ProbeVariant=="original")originalBreakState.GetType().GetMethod("Tick").Invoke(originalBreakState,new[]{originalBreakSquad});
    else {
     var handled=breakManager.TryQueueBreakthrough(breakSquad);
     if(initialDecision==null)initialDecision=breakManager.BreakthroughReason;
     if(!handled) {
      breakSquad.TargetActor=breakObjective;
      if(breakManager.LocalCommitAllowed(breakSquad)&&breakManager.TeamCanAttack(breakSquad,breakGuards.Where(a=>!a.IsDead&&a.CanBeViewedByPlayer(breakArmy[0].Owner)))) {
       if(breakArmy.Where(a=>!a.IsDead).Any(a=>(a.Location-breakObjective.Location).LengthSquared<=36)) {
        foreach(var u in breakSquad.Units){
         var local=breakManager.ChooseEffectiveLocalTarget(u,breakObjective);
         if(local!=null)breakBot.QueueOrder(new Order("Attack",u,Target.FromActor(local),false));
        }
       } else breakManager.QueueApproach(breakSquad);
      }
     }
    }
   }
   if(breakMode=="far"&&world.WorldTick==20&&(breakArmy[0].Location-breakObjective.Location).LengthSquared<=576)throw new InvalidOperationException("Far fixture is not outside local assessment radius");
   if(guardClearTick<0&&breakGuards.All(a=>a.IsDead||!a.IsInWorld))guardClearTick=world.WorldTick;
   if(objectiveTick<0&&(breakObjective.IsDead||!breakObjective.IsInWorld))objectiveTick=world.WorldTick;
   var end=objectiveTick>=0||breakArmy.All(a=>a.IsDead||!a.IsInWorld)||world.WorldTick>=2500
    ||(breakMode=="weak"||breakMode=="old")&&world.WorldTick>=250;
   if(!end)return;
   var lost=breakArmy.Where(a=>a.IsDead||!a.IsInWorld).Sum(a=>a.GetSellValue());
   Func<Actor,double> remaining=a=>a.IsDead||!a.IsInWorld?0:a.Trait<Health>().HP/(double)a.Trait<Health>().MaxHP;
   var ownDamage=breakArmy.Sum(a=>a.GetSellValue()*(1-remaining(a)));
   var enemyDamage=breakGuards.Concat(new[]{breakObjective}).Sum(a=>a.GetSellValue()*(1-remaining(a)));
   var line=string.Join(",",ProbeVariant,breakMode,world.WorldTick,initialDecision??"original",breakBot.AttackOrders,
    guardClearTick,objectiveTick,lost,Math.Round(ownDamage),Math.Round(enemyDamage),
    breakArmy.Count(a=>!a.IsDead&&a.IsInWorld),breakGuards.Count(a=>!a.IsDead&&a.IsInWorld));
   File.WriteAllText(Path.Combine(Platform.SupportDir,"combat-result.csv"),
    "variant,case,end_tick,decision,attack_orders,guards_clear_tick,objective_tick,lost_credits,hp_loss_credit_equivalent,enemy_damage_credit_equivalent,units_surviving,guards_surviving\n"+line+"\n");
   Console.WriteLine("AI-COMBAT RESULT "+line);
   breakReported=true;TelemetrySnapshot(world);FlushTelemetry();WriteDecisionSummary(world);Game.Exit();
  }
 }
}



