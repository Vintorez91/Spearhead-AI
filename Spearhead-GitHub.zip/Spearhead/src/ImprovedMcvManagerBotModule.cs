#region Copyright & License Information
/*
 * Copyright 2007-2020 The OpenRA Developers (see AUTHORS)
 * This file is part of OpenRA, which is free software. It is made
 * available to you under the terms of the GNU General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version. For more
 * information, see COPYING.
 */
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Traits;

namespace OpenRA.Mods.Common.Traits.AITest
{
	[Desc("Manages AI MCVs.")]
	public class ImprovedMcvManagerBotModuleInfo : ConditionalTraitInfo
	{
		[Desc("Actor types that are considered MCVs (deploy into base builders).")]
		public readonly HashSet<string> McvTypes = new HashSet<string>();

		[Desc("Actor types that are considered construction yards (base builders).")]
		public readonly HashSet<string> ConstructionYardTypes = new HashSet<string>();

		[Desc("Actor types that are able to produce MCVs.")]
		public readonly HashSet<string> McvFactoryTypes = new HashSet<string>();

		[Desc("Try to maintain at least this many ConstructionYardTypes, build an MCV if number is below this.")]
		public readonly int MinimumConstructionYardCount = 1;

		[Desc("Delay (in ticks) between looking for and giving out orders to new MCVs.")]
		public readonly int ScanForNewMcvInterval = 20;

		[Desc("Minimum distance in cells from center of the base when checking for MCV deployment location.")]
		public readonly int MinBaseRadius = 2;

		[Desc("Maximum distance in cells from center of the base when checking for MCV deployment location.",
			"Only applies if RestrictMCVDeploymentFallbackToBase is enabled and there's at least one construction yard.")]
		public readonly int MaxBaseRadius = 20;

		[Desc("Should deployment of additional MCVs be restricted to MaxBaseRadius if explicit deploy locations are missing or occupied?")]
		public readonly bool RestrictMCVDeploymentFallbackToBase = true;

		public override object Create(ActorInitializer init) { return new ImprovedMcvManagerBotModule(init.Self, this); }
	}

	public partial class ImprovedMcvManagerBotModule : ConditionalTrait<ImprovedMcvManagerBotModuleInfo>, IBotTick, IBotPositionsUpdated, IGameSaveTraitData
	{
		public CPos GetRandomBaseCenter()
		{
			var randomConstructionYard = world.Actors.Where(a => a.Owner == player &&
				Info.ConstructionYardTypes.Contains(a.Info.Name))
				.RandomOrDefault(world.LocalRandom);

			return randomConstructionYard != null ? randomConstructionYard.Location : initialBaseCenter;
		}

		readonly World world;
		readonly Player player;

		readonly Predicate<Actor> unitCannotBeOrdered;

		IBotPositionsUpdated[] notifyPositionsUpdated;
		IBotRequestUnitProduction[] requestUnitProduction;

		CPos initialBaseCenter;
		int scanInterval;
		bool firstTick = true;

		public ImprovedMcvManagerBotModule(Actor self, ImprovedMcvManagerBotModuleInfo info)
			: base(info)
		{
			world = self.World;
			player = self.Owner;
			unitCannotBeOrdered = a => a.Owner != player || a.IsDead || !a.IsInWorld;
		}

		protected override void Created(Actor self)
		{
			notifyPositionsUpdated = self.Owner.PlayerActor.TraitsImplementing<IBotPositionsUpdated>().ToArray();
			requestUnitProduction = self.Owner.PlayerActor.TraitsImplementing<IBotRequestUnitProduction>().ToArray();
		}

		protected override void TraitEnabled(Actor self)
		{
			// Avoid all AIs reevaluating assignments on the same tick, randomize their initial evaluation delay.
			scanInterval = world.LocalRandom.Next(Info.ScanForNewMcvInterval, Info.ScanForNewMcvInterval * 2);
		}

		void IBotPositionsUpdated.UpdatedBaseCenter(CPos newLocation)
		{
			initialBaseCenter = newLocation;
		}

		void IBotPositionsUpdated.UpdatedDefenseCenter(CPos newLocation) { }

		void IBotTick.BotTick(IBot bot)
		{
			if (firstTick)
			{
				DeployMcvs(bot, false);
				firstTick = false;
			}

			if (--scanInterval <= 0)
			{
				scanInterval = Info.ScanForNewMcvInterval;
				ObserveBaseLosses();
                DeployMcvs(bot, true);

				// No construction yards - Build a new MCV
				if (ShouldBuildMCV())
				{
					var unitBuilder = requestUnitProduction.FirstOrDefault(Exts.IsTraitEnabled);
					if (unitBuilder != null)
					{
						var mcvInfo = LegacyAIUtils.GetInfoByCommonName(Info.McvTypes, player);
						if (unitBuilder.RequestedProductionCount(bot, mcvInfo.Name) == 0)
							{ unitBuilder.RequestUnitProduction(bot, mcvInfo.Name); Console.WriteLine("AI-EXPANSION requesting MCV"); }
					}
				}
			}
		}

        readonly Dictionary<uint, CPos> previousYards = new Dictionary<uint, CPos>();
        readonly Dictionary<CPos, int> lostSites = new Dictionary<CPos, int>();
        int recoveryTarget;
        public bool RecoveringExpansion { get { return recoveryTarget > 0; } }
        void ObserveBaseLosses()
        {
            var yards = world.Actors.Where(a => a.Owner == player && !a.IsDead && a.IsInWorld && Info.ConstructionYardTypes.Contains(a.Info.Name)).ToArray();
            foreach (var old in previousYards.Where(kv => !yards.Any(a => a.ActorID == kv.Key)))
            {
                lostSites[old.Value] = world.WorldTick + 1500;
                recoveryTarget = Math.Max(recoveryTarget, Math.Min(3, previousYards.Count));
                expansionDestination = null; nextExpansionScan = 0;
                Console.WriteLine("AI-RECOVERY lost yard=" + old.Value + " target=" + recoveryTarget);
            }
            previousYards.Clear(); foreach (var yard in yards) previousYards[yard.ActorID] = yard.Location;
            if (recoveryTarget > 0 && yards.Length >= recoveryTarget)
            { recoveryTarget = 0; Console.WriteLine("AI-RECOVERY restored yards=" + yards.Length); }
        }
        public CPos? RecoveryScoutTarget
        {
            get { return RecoveringExpansion ? lostSites.Where(s => world.WorldTick >= s.Value && !player.Shroud.IsVisible(s.Key)).OrderBy(s => s.Value).Select(s => (CPos?)s.Key).FirstOrDefault() : null; }
        }
        bool MayRecover(ImprovedStrategyBotModule strategy)
        {
            return RecoveringExpansion && (strategy == null || strategy.Plan != StrategicPlan.Defend && strategy.CombatCount >= 4);
        }
        bool SiteCoolingDown(CPos cell)
        {
            return lostSites.Any(s => world.WorldTick < s.Value && (s.Key - cell).LengthSquared < 225);
        }
        readonly HashSet<CPos> knownResourceCells = new HashSet<CPos>();
        CPos? expansionDestination;
        int nextExpansionScan;

        CPos? FindExpansionLocation()
        {
            if (world.WorldTick < nextExpansionScan) return expansionDestination;
            nextExpansionScan = world.WorldTick + 100;
            var tileset = world.Map.Rules.TerrainInfo;
            var resources = new HashSet<byte>(world.Map.Rules.Actors["world"].TraitInfo<ResourceLayerInfo>().ResourceTypes.Values
                .Select(t => tileset.GetTerrainIndex(t.TerrainType)));
            foreach (var c in world.Map.AllCells.Where(c => player.Shroud.IsVisible(c)))
                if (resources.Contains(world.Map.GetTerrainIndex(c))) knownResourceCells.Add(c);
                else knownResourceCells.Remove(c);
            var own = world.Actors.Where(a => a.Owner == player && !a.IsDead).ToArray();
            var bases = own.Where(a => Info.ConstructionYardTypes.Contains(a.Info.Name) || a.Info.Name == "proc" && !lostSites.Keys.Any(c => (a.Location - c).LengthSquared < 225)).ToArray();
            var visibleDanger = world.Actors.Where(a => a.CanBeViewedByPlayer(player) && !a.IsDead &&
                player.RelationshipWith(a.Owner) == PlayerRelationship.Enemy && a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
            var resource = knownResourceCells.Where(c => bases.All(a => (a.Location - c).LengthSquared > 18 * 18))
                .Where(c => !SiteCoolingDown(c) && visibleDanger.All(a => (a.Location - c).LengthSquared > 15 * 15))
                .OrderByDescending(c => knownResourceCells.Count(r => (r - c).LengthSquared < 100) * 8 - (c - player.HomeLocation).Length)
                .Select(c => (CPos?)c).FirstOrDefault();
            // Keep the last scouted deployment site while it is under fog; never inspect hidden occupants.
            if (expansionDestination.HasValue && !SiteCoolingDown(expansionDestination.Value) && bases.All(a => (a.Location - expansionDestination.Value).LengthSquared > 144) &&
                visibleDanger.All(a => (a.Location - expansionDestination.Value).LengthSquared > 225))
                return expansionDestination;
            expansionDestination = null;
            if (!resource.HasValue) return null;
            var mcvInfo = world.Map.Rules.Actors["mcv"];
            var transforms = mcvInfo.TraitInfo<TransformsInfo>();
            var yardInfo = world.Map.Rules.Actors[transforms.IntoActor];
            var building = yardInfo.TraitInfo<BuildingInfo>();
            var mobile = mcvInfo.TraitInfo<MobileInfo>();
            var locomotor = world.WorldActor.TraitsImplementing<Locomotor>().First(l => l.Info.Name == mobile.Locomotor);
            var domain = new DomainIndex(world);
            expansionDestination = world.Map.FindTilesInAnnulus(resource.Value, 4, 8)
                .Where(c => player.Shroud.IsVisible(c) && domain.IsPassable(player.HomeLocation, c, locomotor))
                .Where(c => world.CanPlaceBuilding(c + transforms.Offset, yardInfo, building, null))
                .Select(c => (CPos?)c).FirstOrDefault();
            TraceProspectiveRefinery(expansionDestination);
            return expansionDestination;
        }

        public bool SavingForExpansion()
        {
            var strategy = player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>();
            // Keep refinery money protected while an expansion MCV travels or a new yard awaits its refinery.
            var funds=player.PlayerActor.Trait<PlayerResources>();
            var owned=world.Actors.Where(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead).ToArray();
            var yards=owned.Where(a=>Info.ConstructionYardTypes.Contains(a.Info.Name)).ToArray();
            var transit=yards.Length>0&&owned.Any(a=>Info.McvTypes.Contains(a.Info.Name));
            var needsRefinery=yards.Length>1&&yards.Any(y=>!owned.Any(a=>a.Info.Name=="proc"&&(a.Location-y.Location).LengthSquared<100));
            if((strategy==null||!strategy.HoldingOffense)&&(transit||needsRefinery)&&funds.Cash+funds.Resources<1800)return true;
            var suitable = world.WorldTick >= 1250 && LegacyAIUtils.CountBuildingByCommonName(Info.ConstructionYardTypes, player) > 0 &&
                LegacyAIUtils.CountBuildingByCommonName(Info.ConstructionYardTypes, player) < 3 && LegacyAIUtils.CountActorByCommonName(Info.McvTypes, player) == 0 &&
                (MayRecover(strategy) || world.Actors.Count(a => a.Owner == player && !a.IsDead && a.Info.HasTraitInfo<AttackBaseInfo>() && a.Info.HasTraitInfo<MobileInfo>()) >= 12) &&
                world.Actors.Any(a => a.Owner == player && a.Info.Name == "fix" && !a.IsDead) && FindExpansionLocation().HasValue;
            return strategy == null ? suitable : strategy.ReserveExpansionFunds(suitable, MayRecover(strategy));
        }        bool ShouldBuildMCV()
        {
            if (LegacyAIUtils.FindQueues(player, "Vehicle").Any(q => q.AllQueued().Any(i => Info.McvTypes.Contains(i.Item)))) return false;
            if (LegacyAIUtils.CountActorByCommonName(Info.McvTypes, player) > 0 ||
                LegacyAIUtils.CountBuildingByCommonName(Info.McvFactoryTypes, player) == 0) return false;
            var yards = LegacyAIUtils.CountBuildingByCommonName(Info.ConstructionYardTypes, player);
            var strategy = player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>(); if (strategy != null) strategy.Refresh();
            if (yards == 0) return true;
            if (strategy != null && !strategy.MayExpand && !MayRecover(strategy)) return false;
            var money = player.PlayerActor.Trait<PlayerResources>();
            return yards < 3 && world.WorldTick >= 1250 && money.Cash + money.Resources >= 4000 &&
                LegacyAIUtils.FindQueues(player, "Vehicle").Any(q => q.BuildableItems().Any(a => Info.McvTypes.Contains(a.Name))) && FindExpansionLocation().HasValue;
        }
		void DeployMcvs(IBot bot, bool chooseLocation)
		{
			var newMCVs = world.ActorsHavingTrait<Transforms>()
				.Where(a => a.Owner == player && a.IsIdle && Info.McvTypes.Contains(a.Info.Name));

			foreach (var mcv in newMCVs)
				DeployMcv(bot, mcv, chooseLocation);
		}

		// Find any MCV and deploy them at a sensible location.
		void DeployMcv(IBot bot, Actor mcv, bool move)
		{
			if (move)
			{
				// If we lack a base, we need to make sure we don't restrict deployment of the MCV to the base!
				var restrictToBase = Info.RestrictMCVDeploymentFallbackToBase && LegacyAIUtils.CountBuildingByCommonName(Info.ConstructionYardTypes, player) > 0;

				var transformsInfo = mcv.Info.TraitInfo<TransformsInfo>();
                var hasBase = LegacyAIUtils.CountBuildingByCommonName(Info.ConstructionYardTypes, player) > 0;
                var desiredLocation = hasBase ? FindExpansionLocation() : ChooseMcvDeployLocation(transformsInfo.IntoActor, transformsInfo.Offset, restrictToBase);
                if (hasBase && desiredLocation.HasValue)
                    Console.WriteLine("AI-EXPANSION MCV moving to discovered field near " + desiredLocation.Value);
				if (desiredLocation == null)
					return;

				bot.QueueOrder(new Order("Move", mcv, Target.FromCell(world, desiredLocation.Value), true));
			}

			// If the MCV has to move first, we can't be sure it reaches the destination alive, so we only
			// update base and defense center if the MCV is deployed immediately (i.e. at game start).
			// TODO: This could be adressed via INotifyTransform.
			foreach (var n in notifyPositionsUpdated)
			{
				n.UpdatedBaseCenter(mcv.Location);
				n.UpdatedDefenseCenter(mcv.Location);
			}

			bot.QueueOrder(new Order("DeployTransform", mcv, true));
		}

		CPos? ChooseMcvDeployLocation(string actorType, CVec offset, bool distanceToBaseIsImportant)
		{
			var actorInfo = world.Map.Rules.Actors[actorType];
			var bi = actorInfo.TraitInfoOrDefault<BuildingInfo>();
			if (bi == null)
				return null;

			// Find the buildable cell that is closest to pos and centered around center
			Func<CPos, CPos, int, int, CPos?> findPos = (center, target, minRange, maxRange) =>
			{
				var cells = world.Map.FindTilesInAnnulus(center, minRange, maxRange);

				// Sort by distance to target if we have one
				if (center != target)
					cells = cells.OrderBy(c => (c - target).LengthSquared);
				else
					cells = cells.Shuffle(world.LocalRandom);

				foreach (var cell in cells)
					if (world.CanPlaceBuilding(cell + offset, actorInfo, bi, null))
						return cell;

				return null;
			};

			var baseCenter = GetRandomBaseCenter();

			return findPos(baseCenter, baseCenter, Info.MinBaseRadius,
				distanceToBaseIsImportant ? Info.MaxBaseRadius : world.Map.Grid.MaximumTileSearchRange);
		}

		List<MiniYamlNode> IGameSaveTraitData.IssueTraitData(Actor self)
		{
			if (IsTraitDisabled)
				return null;

			return new List<MiniYamlNode>()
			{
				new MiniYamlNode("InitialBaseCenter", FieldSaver.FormatValue(initialBaseCenter))
			};
		}

		void IGameSaveTraitData.ResolveTraitData(Actor self, MiniYaml yaml)
        { var data = yaml.Nodes;
		
			if (self.World.IsReplay)
				return;

			var initialBaseCenterNode = data.FirstOrDefault(n => n.Key == "InitialBaseCenter");
			if (initialBaseCenterNode != null)
				initialBaseCenter = FieldLoader.GetValue<CPos>("InitialBaseCenter", initialBaseCenterNode.Value.Value);
		}
	}
}






