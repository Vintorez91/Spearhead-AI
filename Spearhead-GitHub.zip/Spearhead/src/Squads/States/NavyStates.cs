namespace OpenRA.Mods.Common.Traits.AITest.Squads {
 class NavyUnitsIdleState:IState {public void Activate(Squad owner){} public void Deactivate(Squad owner){} public void Tick(Squad owner){owner.SquadManager.TickNavalMissions(owner);} }
 class NavyUnitsAttackMoveState:IState {public void Activate(Squad owner){} public void Deactivate(Squad owner){} public void Tick(Squad owner){owner.SquadManager.TickNavalMissions(owner);} }
 class NavyUnitsAttackState:IState {public void Activate(Squad owner){} public void Deactivate(Squad owner){} public void Tick(Squad owner){owner.SquadManager.TickNavalMissions(owner);} }
 class NavyUnitsFleeState:IState {public void Activate(Squad owner){} public void Deactivate(Squad owner){} public void Tick(Squad owner){owner.SquadManager.TickNavalMissions(owner);} }
}
