using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Primitives;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 sealed class NavalProbeBot:IBot {
  readonly World world;public Player Player{get;private set;}public IBotInfo Info=>null;
  public readonly List<Order> Orders=new List<Order>(); public NavalProbeBot(World w,Player p){world=w;Player=p;}public void Activate(Player p){Player=p;}
  public void QueueOrder(Order o){Orders.Add(o);world.IssueOrder(o);}
 }
 public partial class AITestMetrics {
  bool navalSetup,navalDone;Actor navalCruiser,navalScout,navalSub,navalShore,navalEnemyShip,navalDestroyer;CPos navalStart,navalCoast;Squad navalSquad;NavalProbeBot navalBot;int navalHit=-1;int navalShoreHP;
  void CheckNavalFixture(World world){
   if(world.WorldTick==2){foreach(var p in world.Players.Where(p=>p.IsBot))foreach(var b in p.PlayerActor.TraitsImplementing<ModularBot>())b.IsEnabled=false;
    world.AddFrameEndTask(w=>{
     var own=w.Players.First(p=>p.IsBot&&p.BotType=="improved");
     var mobile=w.Map.Rules.Actors["ca"].TraitInfo<MobileInfo>();var power=w.Map.Rules.Actors["powr"];var building=power.TraitInfo<BuildingInfo>();
     var finder=w.WorldActor.Trait<IPathFinder>();var loco=w.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==mobile.Locomotor);
     CPos? coast=null,start=null;
     foreach(var c in w.Map.AllCells.Where(c=>w.CanPlaceBuilding(c,power,building,null))){
      var water=w.Map.FindTilesInAnnulus(c,5,9).Where(t=>mobile.CanEnterCell(w,null,t)).Select(t=>(CPos?)t).FirstOrDefault();if(!water.HasValue)continue;
      var far=w.Map.FindTilesInAnnulus(c,24,28).Where(t=>mobile.CanEnterCell(w,null,t)&&finder.PathExistsForLocomotor(loco,water.Value,t)).Select(t=>(CPos?)t).FirstOrDefault();if(!far.HasValue)continue;
      coast=c;start=far;break;
     }
     if(!coast.HasValue)throw new InvalidOperationException("No coastal naval fixture");navalStart=start.Value;navalCoast=coast.Value;
     Func<string,Player,CPos,Actor> make=(name,p,c)=>w.CreateActor(name,new TypeDictionary{new OwnerInit(p),new LocationInit(c)});
     navalScout=make("pt",own,navalStart);navalCruiser=make(TestScenario.EndsWith("missile")?"msub":"ca",own,w.Map.FindTilesInAnnulus(navalStart,2,4).First(c=>mobile.CanEnterCell(w,null,c)&&finder.PathExistsForLocomotor(loco,navalStart,c)));
     navalSub=make("ss",own,w.Map.FindTilesInAnnulus(navalStart,4,6).First(c=>mobile.CanEnterCell(w,null,c)&&finder.PathExistsForLocomotor(loco,navalStart,c)));
     var manager=own.PlayerActor.Trait<ImprovedSquadManagerBotModule>();manager.Strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation[0]);
     navalBot=new NavalProbeBot(w,own);navalSquad=new Squad(navalBot,manager,SquadType.Naval);navalSquad.Units.AddRange(new[]{navalScout,navalCruiser,navalSub});
     if(TestScenario.StartsWith("naval-escort")){navalDestroyer=make("dd",own,w.Map.FindTilesInAnnulus(navalStart,7,9).First(c=>mobile.CanEnterCell(w,null,c)&&finder.PathExistsForLocomotor(loco,navalStart,c)));navalSquad.Units.Add(navalDestroyer);}
     navalSetup=true;Console.WriteLine("AI-NAVAL TEST setup start="+navalStart+" coast="+navalCoast);
    });
   }
   if(!navalSetup||navalDone)return;
   if(world.WorldTick==20){
    navalSquad.Update();
    var scoutOrder=navalBot.Orders.FirstOrDefault(o=>o.Subject==navalScout&&o.OrderString=="Move");
    if(scoutOrder==null)throw new InvalidOperationException("Patrol boat did not scout");
    Console.WriteLine("AI-NAVAL TEST passed patrol boat scouts without enemy target");
    var hidden=world.Actors.First(a=>a.Info.Name=="fact"&&a.Owner.RelationshipWith(navalCruiser.Owner)==PlayerRelationship.Enemy);
    if(navalSquad.SquadManager.NavalFirePosition(navalCruiser,hidden).HasValue)throw new InvalidOperationException("Naval targeting used hidden enemy building");
    var subBot=new ProbeBot(navalSub.Owner);var subScout=new Squad(subBot,navalSquad.SquadManager,SquadType.Naval);subScout.Units.Add(navalSub);navalSquad.SquadManager.TickNavalMissions(subScout);
    if(!subBot.Orders.Any(o=>o.Subject==navalSub&&o.OrderString=="Move"))throw new InvalidOperationException("Submarine-only fleet did not explore");
    Console.WriteLine("AI-NAVAL TEST passed submarine-only fleet scouts; hidden enemy building rejected");
    navalCruiser.Owner.Shroud.ExploreAll();
    world.AddFrameEndTask(w=>{
     var enemy=w.Players.First(p=>p.Playable&&p.RelationshipWith(navalCruiser.Owner)==PlayerRelationship.Enemy);
     Func<string,Player,CPos,Actor> make=(name,p,c)=>w.CreateActor(name,new TypeDictionary{new OwnerInit(p),new LocationInit(c)});
     navalShore=make("powr",enemy,navalCoast);navalShoreHP=navalShore.Trait<IHealth>().HP;make("camera",navalCruiser.Owner,navalCoast);
     if(!TestScenario.StartsWith("naval-escort")){var mobile=navalSub.Trait<Mobile>();var finder=w.WorldActor.Trait<IPathFinder>();var shipCell=w.Map.FindTilesInAnnulus(navalSub.Location,12,15).First(c=>mobile.Info.CanEnterCell(w,navalSub,c)&&finder.PathExistsForLocomotor(mobile.Locomotor,navalSub.Location,c));
     navalEnemyShip=make("lst",enemy,shipCell);make("camera",navalSub.Owner,shipCell);}
    });
   }
   if(world.WorldTick>=125&&world.WorldTick%25==0){navalSquad.Units.RemoveAll(a=>a.IsDead||!a.IsInWorld);navalSquad.Update();}
   if(TestScenario.EndsWith("recovery")&&world.WorldTick==150)world.AddFrameEndTask(w=>{foreach(var a in w.Actors.Where(a=>a.Owner==navalCruiser.Owner&&a.Info.Name=="camera"&&(a.Location-navalCoast).LengthSquared<16).ToArray())a.Dispose();});
   if(TestScenario.EndsWith("recovery")&&world.WorldTick==250){if(!navalSquad.SquadManager.NavalRecoveryPending(navalScout))throw new InvalidOperationException("Lost coastal contact did not dispatch patrol recon");Console.WriteLine("AI-NAVAL TEST passed lost sight dispatches patrol recon to remembered location");}
   if(TestScenario.EndsWith("recovery")&&world.WorldTick==400)world.AddFrameEndTask(w=>w.CreateActor("camera",new TypeDictionary{new OwnerInit(navalCruiser.Owner),new LocationInit(navalCoast)}));
   if(TestScenario.StartsWith("naval-escort")&&world.WorldTick==300)world.AddFrameEndTask(w=>{var enemy=w.Players.First(p=>p.Playable&&p.RelationshipWith(navalCruiser.Owner)==PlayerRelationship.Enemy);var mobile=navalSub.Trait<Mobile>();var finder=w.WorldActor.Trait<IPathFinder>();var cell=w.Map.FindTilesInAnnulus(navalCruiser.Location,4,6).First(c=>mobile.Info.CanEnterCell(w,navalSub,c)&&finder.PathExistsForLocomotor(mobile.Locomotor,navalSub.Location,c));navalEnemyShip=w.CreateActor("pt",new TypeDictionary{new OwnerInit(enemy),new LocationInit(cell)});w.CreateActor("camera",new TypeDictionary{new OwnerInit(navalSub.Owner),new LocationInit(cell)});});
   if(TestScenario.StartsWith("naval-escort")&&world.WorldTick==150){
    if(navalSquad.SquadManager.NavalEscortedCapital(navalSub)!=navalCruiser||navalSquad.SquadManager.NavalEscortedCapital(navalDestroyer)!=navalCruiser)throw new InvalidOperationException("Escort pair not assigned to capital ship");
    if(navalBot.Orders.Any(o=>o.Subject==navalSub&&o.OrderString=="Attack"))throw new InvalidOperationException("Guard submarine exposed itself without a threat");
    if(!navalSub.GetEnabledTargetTypes().ToString().Contains("Underwater"))throw new InvalidOperationException("Idle escort submarine did not remain submerged");
    Console.WriteLine("AI-NAVAL TEST passed destroyer/submarine assigned; submarine quietly submerged before threat");
   }
   if(!TestScenario.StartsWith("naval-escort")&&world.WorldTick==150){
    Console.WriteLine("AI-NAVAL TEST diagnostic visible="+navalShore.CanBeViewedByPlayer(navalCruiser.Owner)+" damage="+AttackOrFleeFuzzy.EffectiveDamage(navalCruiser,new[]{navalShore})+" position="+navalSquad.SquadManager.NavalFirePosition(navalCruiser,navalShore));
    if(!navalBot.Orders.Any(o=>o.Subject==navalCruiser&&(o.OrderString=="Move"||o.OrderString=="Attack")))throw new InvalidOperationException("Cruiser did not approach coastal target");
    if(!navalBot.Orders.Any(o=>o.Subject==navalSub&&o.OrderString=="Move"&&navalSquad.SquadManager.NavalMissionTarget(navalSub)==navalEnemyShip))throw new InvalidOperationException("Submarine did not approach visible ship");
    if(navalBot.Orders.Any(o=>o.OrderString=="Stop"))throw new InvalidOperationException("Fleet formation stop interrupted naval missions");
    Console.WriteLine("AI-NAVAL TEST passed submarine approaches ship; cruiser advances independently; no formation stop");
   }
   if(navalShore!=null&&(navalShore.IsDead||navalShore.Trait<IHealth>().HP<navalShoreHP)&&navalHit<0){navalHit=world.WorldTick;Console.WriteLine("AI-NAVAL TEST coastal damage tick="+navalHit);}
   if(world.WorldTick>=1800||world.WorldTick>600&&navalShore!=null&&navalShore.IsDead){
    navalDone=true;
    var attacks=navalBot.Orders.Where(o=>o.Subject==navalCruiser&&o.OrderString=="Attack"&&o.Target.Actor==navalShore).Count();
    if(!navalBot.Orders.Any(o=>o.Subject==navalSub&&o.OrderString=="Attack"&&o.Target.Actor==navalEnemyShip))throw new InvalidOperationException("Submarine never issued attack on ship");
    if(navalHit<0||attacks==0)throw new InvalidOperationException("Cruiser did not actually bombard coastal building");
    if(attacks>2)throw new InvalidOperationException("Stable bombardment was repeatedly restarted");
    if(TestScenario.StartsWith("naval-escort")){if(!navalBot.Orders.Any(o=>o.Subject==navalDestroyer&&o.OrderString=="Move"))throw new InvalidOperationException("Destroyer did not follow escort station");if(navalSquad.SquadManager.NavalEscortedCapital(navalSub)!=navalCruiser&&!navalShore.IsDead)throw new InvalidOperationException("Escort assignment changed unexpectedly");Console.WriteLine("AI-NAVAL TEST passed escort follows and intercepts; capital continues bombardment");}else if(navalBot.Orders.Count(o=>o.OrderString=="Stop")>0)throw new InvalidOperationException("Unexpected formation stop");
    File.WriteAllText(Path.Combine(Platform.SupportDir,"naval-result.txt"),"PASS: patrol scouting, submarine ship targeting, cruiser coastal bombardment. Damage tick="+navalHit+"; cruiser attack orders="+attacks+"; building destroyed="+navalShore.IsDead+"; final cruiser="+navalCruiser.Location+"; start="+navalStart);
    Console.WriteLine("AI-NAVAL TEST passed actual bombardment; limited repeat orders="+attacks);Game.Exit();
   }
  }
 }
}






