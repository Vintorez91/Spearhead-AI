using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedSquadManagerBotModule
 {
  readonly Dictionary<Squad,int> nextLocalAttackLog=new Dictionary<Squad,int>();
  internal bool LocalCommitAllowed(Squad squad) {
   if(!LocalAttackAssessment||!squad.IsTargetValid||(squad.Type!=SquadType.Assault&&squad.Type!=SquadType.Rush))return true;
   var contacting=squad.Units.Any(a=>(a.Location-squad.TargetActor.Location).LengthSquared<=144);
   var force=contacting?squad.Units.Where(a=>(a.Location-squad.TargetActor.Location).LengthSquared<=576).ToArray():squad.Units.ToArray();
   return CanCommitLocalAttack(squad,squad.TargetActor,force,"engage");
  }
  bool CanCommitLocalAttack(Squad squad,Actor target,IEnumerable<Actor> candidates,string reason) {
   if(target==null||target.IsDead||!target.IsInWorld||!target.CanBeViewedByPlayer(Player))return false;
   var domain=new DomainIndex(World);
   var input=TeamLocalForce(squad,candidates).Where(a=>!unitCannotBeOrdered(a)&&!IsRecoveringVeteran(a)).ToArray();
   var force=input.Where(a=>AttackOrFleeFuzzy.SuitableAttacker(a,target)).Where(a=>{var m=a.TraitOrDefault<Mobile>();return m==null||domain.IsPassable(a.Location,target.Location,m.Locomotor);}).ToArray();
   var visible=World.FindActorsInCircle(target.CenterPosition,WDist.FromCells(12)).Where(IsPreferredEnemyUnit).Where(a=>a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
   var remembered=Strategy==null?new ImprovedStrategyBotModule.Observation[0]:Strategy.KnownEnemies.Where(e=>e.Armed&&(e.Position-target.Location).LengthSquared<=144&&(e.Building||World.WorldTick-e.Seen<=1500)).ToArray();
   var resistance=remembered.Sum(e=>e.Value);
   var fresh=World.Map.FindTilesInCircle(target.Location,6).ToArray();
   var coverage=fresh.Length==0?0:fresh.Count(c=>Player.Shroud.IsVisible(c))/(double)fresh.Length;
   var uncertainty=coverage>=0.65?300:900;
   var value=(int)force.Sum(a=>Math.Max(1,a.GetSellValue())*(a.TraitOrDefault<Health>()==null?1:a.Trait<Health>().HP/(double)a.Trait<Health>().MaxHP));
   int committedUntil; var committed=committedAttack.TryGetValue(squad,out committedUntil)&&World.WorldTick<committedUntil;
   var poke=harassment.ContainsKey(squad)&&harassment[squad];
   var uncertaintyCost=poke?uncertainty*0.35:uncertainty;
   var threshold=committed?1.00:poke?1.15:1.25;
   var allowed=force.Length>0&&value>=(resistance+uncertaintyCost)*threshold&&AttackOrFleeFuzzy.Default.CanAttack(force,visible);
   if(poke&&remembered.Any(e=>e.Building))allowed=false;
   if(allowed&&!committed)committedAttack[squad]=World.WorldTick+500;
   foreach(var stale in committedAttack.Keys.Where(s=>!Squads.Contains(s)||!s.IsValid).ToArray())committedAttack.Remove(stale);
      var rejected=input.Where(a=>!force.Contains(a)).Select(a=>a.ActorID+":"+(!AttackOrFleeFuzzy.SuitableAttacker(a,target)?"unsuitable_weapon":"unreachable_domain"));
   var excluded=squad.Units.Where(a=>!input.Contains(a)).Select(a=>a.ActorID+":"+(unitCannotBeOrdered(a)?"unorderable":IsRecoveringVeteran(a)?"veteran_recovery":"outside_local_force"));
   var required=(resistance+uncertaintyCost)*threshold;
   var failure=force.Length==0?"no_suitable_force":value<required?"insufficient_value":poke&&remembered.Any(e=>e.Building)?"poke_defence_guard":!allowed?"weapon_matchup":"local_allowed";
   TraceAttack(squad,failure,"input="+input.Length+";effective="+force.Length+";own="+input.Count(a=>a.Owner==Player)+";allied="+input.Count(a=>a.Owner!=Player)+";value="+value+";resistance="+resistance+";uncertainty="+uncertainty+";uncertainty_cost="+uncertaintyCost+";threshold="+threshold+";required="+required+";coverage="+coverage+";gps_contacts="+(Strategy==null?0:Strategy.GpsContacts.Length)+";rejected="+string.Join("|",rejected)+";excluded="+string.Join("|",excluded)+";resistance_sources="+string.Join("|",remembered.Select(e=>e.Id+":"+e.Info.Name+":value="+e.Value+":age="+(World.WorldTick-e.Seen)))+";visible_defenders="+string.Join("|",visible.Select(a=>a.ActorID+":"+a.Info.Name)));
   int next;if(reason=="vanguard"||!nextLocalAttackLog.TryGetValue(squad,out next)||World.WorldTick>=next) {
    nextLocalAttackLog[squad]=World.WorldTick+125;
    LogOperation(squad,"local assessment reason="+reason+" target="+target.ActorID+" input="+input.Length+" effective="+force.Length+" value="+value+" resistance="+resistance+" uncertainty="+uncertainty+" threshold="+threshold+" committed="+committed+" allowed="+allowed);
    var logger=World.WorldActor.TraitOrDefault<AITestMetrics>();if(logger!=null)logger.TelemetryLocalAttack(Player,target,input.Length,force.Length,value,resistance,uncertainty,coverage,allowed,reason);
   }
   foreach(var stale in nextLocalAttackLog.Keys.Where(s=>!Squads.Contains(s)||!s.IsValid).ToArray())nextLocalAttackLog.Remove(stale);
   return allowed;
  }
 }
 public partial class AITestMetrics
 {
  StreamWriter localAttackLog;
  void InitializeLocalAttackTelemetry(string prefix) {InitializeAttackTrace(prefix);localAttackLog=new StreamWriter(prefix+"-local-attacks.csv");localAttackLog.WriteLine("tick,player,target_id,target_type,x,y,input_units,effective_units,hp_weighted_value,known_resistance,uncertainty,visible_area_fraction,allowed,reason");}
  public void TelemetryLocalAttack(Player player,Actor target,int input,int effective,int value,int resistance,int uncertainty,double coverage,bool allowed,string reason) {
   if(localAttackLog!=null)localAttackLog.WriteLine(Csv(target.World.WorldTick,player.InternalName,target.ActorID,target.Info.Name,target.Location.X,target.Location.Y,input,effective,value,resistance,uncertainty,coverage,allowed,reason));
  }
 }
}




