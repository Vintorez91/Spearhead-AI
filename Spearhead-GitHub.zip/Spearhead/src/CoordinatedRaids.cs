using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedSquadManagerBotModule
 {
  sealed class JointOperation { public Squad Main, Raid; public int WaitingSince = -1; public bool Released; }
  readonly Dictionary<Squad, JointOperation> jointOperations = new Dictionary<Squad, JointOperation>();
  readonly Dictionary<Squad, int> raidContact = new Dictionary<Squad, int>();
  void LogOperation(Squad squad, string text) {
   Console.WriteLine("AI-TACTIC tick="+World.WorldTick+" "+text);
   var logger=World.WorldActor.TraitOrDefault<AITestMetrics>(); if(logger!=null) logger.TelemetryOperation(Player,squad,text);
  }
  internal bool HoldForJointAttack(Squad squad) {
   if(HoldForTeamAttack(squad))return true;
   if(HoldForMassAssembly(squad))return true;
   if(Strategy!=null&&(Strategy.Plan==StrategicPlan.AllIn||Strategy.Plan==StrategicPlan.Finish))return false;
   JointOperation op;
   if(!jointOperations.TryGetValue(squad,out op) || op.Released || !squad.IsTargetValid) return false;
   var other=op.Main==squad?op.Raid:op.Main;
   if(!other.IsValid || !Squads.Contains(other)) {op.Released=true; return false;}
   if(!other.IsTargetValid) return false;
   Func<Squad,bool> ready=s => s.Units.Any(a => (a.CenterPosition-s.TargetActor.CenterPosition).LengthSquared<144L*1024*1024);
   if(!ready(squad)) return false;
   var danger=World.FindActorsInCircle(squad.CenterPosition,WDist.FromCells(6)).Any(a=>IsPreferredEnemyUnit(a)&&a.Info.HasTraitInfo<AttackBaseInfo>());
   if(ready(other)||danger||(op.WaitingSince>=0&&World.WorldTick-op.WaitingSince>=250)) {
    op.Released=true; LogOperation(squad,"joint attack released; paired main and economic raid"); return false;
   }
   if(op.WaitingSince<0) {op.WaitingSince=World.WorldTick;LogOperation(squad,"staging waits up to 250 ticks for partner");}
   foreach(var a in squad.Units.Where(a=>!a.IsIdle)) bot.QueueOrder(new Order("Stop",a,false));
   return true;
  }
  internal bool RaidShouldWithdraw(Squad squad) {
   if(!harassment.ContainsKey(squad)||!harassment[squad]||!squad.IsValid) return false;
   var contact=squad.IsTargetValid&&squad.Units.Any(a=>(a.CenterPosition-squad.TargetActor.CenterPosition).LengthSquared<100L*1024*1024);
   if(contact&&!raidContact.ContainsKey(squad)) raidContact[squad]=World.WorldTick;
   int started; if(!raidContact.TryGetValue(squad,out started)) return false;
   var hurt=squad.Units.Any(a=>{var hp=a.TraitOrDefault<Health>();return hp!=null&&hp.HP<hp.MaxHP*0.6;});
   var threats=World.FindActorsInCircle(squad.CenterPosition,WDist.FromCells(10)).Where(a=>IsPreferredEnemyUnit(a)&&a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
   if(!squad.IsTargetValid || hurt || World.WorldTick-started>=300 || threats.Length>0&&!AttackOrFleeFuzzy.Default.CanAttack(squad.Units,threats)) {
    raidContact.Remove(squad); LogOperation(squad,"economic raid disengages to preserve units"); return true;
   }
   return false;
  }
 }
}



