using System;
using System.IO;
using System.Linq;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest {
 public static class ExpansionPlacementTrace {
  public static void Write(World world,Player player,string phase,uint site,CPos center,int footprintValid,int adjacentValid,int nearbyRefineries,int funds,int queues,string queued,string reason){
   var path=Path.Combine(Platform.SupportDir,"expansion-placement.csv");
   if(!File.Exists(path))File.WriteAllText(path,"tick,player,phase,site_id,site_x,site_y,footprint_valid_cells,base_adjacent_cells,nearby_refineries,funds,building_queues,queued_items,reason\n");
   File.AppendAllText(path,world.WorldTick+","+player.InternalName+","+phase+","+site+","+center.X+","+center.Y+","+footprintValid+","+adjacentValid+","+nearbyRefineries+","+funds+","+queues+","+queued+","+reason+"\n");
   Console.WriteLine("AI-EXPANSION-PLACEMENT tick="+world.WorldTick+" phase="+phase+" site="+site+" cell="+center+" footprint_valid="+footprintValid+" base_adjacent="+adjacentValid+" funds="+funds+" queues="+queues+" items="+queued+" reason="+reason);
  }
 }
 public partial class ImprovedBaseBuilderBotModule {
  int nextExpansionTrace;readonly System.Collections.Generic.Dictionary<uint,int> firstExpansionTrace=new System.Collections.Generic.Dictionary<uint,int>();
  internal void TraceExpansionPlacement(bool force=false){
   if(!force&&world.WorldTick<nextExpansionTrace)return;nextExpansionTrace=world.WorldTick+250;
   var own=world.Actors.Where(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead).ToArray();var refineries=own.Where(a=>Info.RefineryTypes.Contains(a.Info.Name)).ToArray();
   var queues=Info.BuildingQueues.SelectMany(c=>LegacyAIUtils.FindQueues(player,c)).Distinct().ToArray();var items=queues.SelectMany(q=>q.AllQueued()).ToArray();var refinery=world.Map.Rules.Actors["proc"];var bi=refinery.TraitInfo<BuildingInfo>();var funds=playerResources.Cash+playerResources.Resources;var canProduce=queues.Any(q=>q.BuildableItems().Any(a=>a.Name=="proc"));
   foreach(var yard in own.Where(a=>Info.ConstructionYardTypes.Contains(a.Info.Name))){
    var nearby=refineries.Count(r=>(r.Location-yard.Location).LengthSquared<100);if(nearby>0&&!firstExpansionTrace.ContainsKey(yard.ActorID))continue;
    if(!firstExpansionTrace.ContainsKey(yard.ActorID))firstExpansionTrace[yard.ActorID]=world.WorldTick;
    var valid=world.Map.FindTilesInAnnulus(yard.Location,2,9).Where(c=>world.CanPlaceBuilding(c,refinery,bi,null)).ToArray();var adjacent=valid.Count(c=>bi.IsCloseEnoughToBase(world,player,refinery,c));
    var proc=items.FirstOrDefault(i=>i.Item=="proc");var reason=nearby>0?"refinery_present":queues.Length==0?"no_building_queue":!canProduce?"refinery_not_buildable":adjacent==0?"no_valid_adjacent_placement":proc!=null?(proc.Done?"refinery_ready_to_place":funds==0?"refinery_in_progress_no_funds":"refinery_in_progress"):items.Length>0?"queue_busy_other_building":funds<refinery.TraitInfo<ValuedInfo>().Cost?"insufficient_funds_no_refinery_queued":"idle_queue_no_refinery_selected";
    ExpansionPlacementTrace.Write(world,player,"deployed",yard.ActorID,yard.Location,valid.Length,adjacent,nearby,funds,queues.Length,string.Join(";",items.Select(i=>i.Item+(i.Done?":ready":":building"))),reason);
    if(nearby>0)firstExpansionTrace.Remove(yard.ActorID);
   }
  }
 }
 public partial class ImprovedMcvManagerBotModule {
  CPos? lastLoggedExpansionDestination;
  void TraceProspectiveRefinery(CPos? destination){
   if(!destination.HasValue||destination==lastLoggedExpansionDestination)return;lastLoggedExpansionDestination=destination;
   var transforms=world.Map.Rules.Actors["mcv"].TraitInfo<TransformsInfo>();var yardInfo=world.Map.Rules.Actors[transforms.IntoActor].TraitInfo<BuildingInfo>();var center=destination.Value+transforms.Offset;var yardTiles=yardInfo.Tiles(center).ToArray();var proc=world.Map.Rules.Actors["proc"];var bi=proc.TraitInfo<BuildingInfo>();
   var valid=world.Map.FindTilesInAnnulus(center,2,9).Count(c=>player.Shroud.IsExplored(c)&&world.CanPlaceBuilding(c,proc,bi,null)&&!bi.Tiles(c).Any(t=>yardTiles.Contains(t)));
   var funds=player.PlayerActor.Trait<PlayerResources>();ExpansionPlacementTrace.Write(world,player,"planned",0,center,valid,-1,0,funds.Cash+funds.Resources,-1,"",valid==0?"no_explored_refinery_footprint_at_planned_yard":"prospective_footprint_available_adjacency_not_yet_verified");
  }
 }
}
