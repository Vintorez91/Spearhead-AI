using System;
using System.IO;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedMcvManagerBotModule{internal void ProbeProspectiveTrace(CPos cell){TraceProspectiveRefinery(cell);}}
 public partial class AITestMetrics {
  Player placementOwn;Actor placementYard;CPos placementProc;
  void CheckPlacementTrace(World world){
   if(world.WorldTick==2){foreach(var p in world.Players.Where(p=>p.IsBot))foreach(var bot in p.PlayerActor.TraitsImplementing<ModularBot>())bot.IsEnabled=false;world.AddFrameEndTask(w=>{
    placementOwn=w.Players.First(p=>p.BotType=="improved");var fact=w.Map.Rules.Actors["fact"];var bi=fact.TraitInfo<BuildingInfo>();var proc=w.Map.Rules.Actors["proc"];var pi=proc.TraitInfo<BuildingInfo>();
    var spot=w.Map.FindTilesInAnnulus(placementOwn.HomeLocation,25,40).Where(c=>w.CanPlaceBuilding(c,fact,bi,null)).First(c=>w.Map.FindTilesInAnnulus(c,3,8).Any(t=>w.CanPlaceBuilding(t,proc,pi,null)&&!pi.Tiles(t).Intersect(bi.Tiles(c)).Any()));
    placementYard=w.CreateActor("fact",new TypeDictionary{new OwnerInit(placementOwn),new LocationInit(spot)});w.CreateActor("camera",new TypeDictionary{new OwnerInit(placementOwn),new LocationInit(spot)});
   });}
   if(world.WorldTick==250){placementOwn.PlayerActor.Trait<ImprovedBaseBuilderBotModule>().TraceExpansionPlacement(true);placementOwn.PlayerActor.Trait<ImprovedMcvManagerBotModule>().ProbeProspectiveTrace(placementYard.Location-world.Map.Rules.Actors["mcv"].TraitInfo<TransformsInfo>().Offset);
    var lines=File.ReadAllLines(Path.Combine(Platform.SupportDir,"expansion-placement.csv"));if(!lines.Any(l=>l.Contains(",deployed,"))||!lines.Any(l=>l.Contains(",planned,")))throw new InvalidOperationException("Planned/deployed diagnostics missing");
    var proc=world.Map.Rules.Actors["proc"];var bi=proc.TraitInfo<BuildingInfo>();placementProc=world.Map.FindTilesInAnnulus(placementYard.Location,2,9).First(c=>world.CanPlaceBuilding(c,proc,bi,null)&&bi.IsCloseEnoughToBase(world,placementOwn,proc,c));world.AddFrameEndTask(w=>w.CreateActor("proc",new TypeDictionary{new OwnerInit(placementOwn),new LocationInit(placementProc)}));
   }
   if(world.WorldTick==500){placementOwn.PlayerActor.Trait<ImprovedBaseBuilderBotModule>().TraceExpansionPlacement(true);var lines=File.ReadAllLines(Path.Combine(Platform.SupportDir,"expansion-placement.csv"));if(!lines.Any(l=>l.EndsWith(",refinery_present")))throw new InvalidOperationException("Completed refinery not recorded");File.WriteAllText(Path.Combine(Platform.SupportDir,"placement-result.txt"),"PASS planned site, missing refinery and completed refinery recorded");Game.Exit();}
  }
 }
}
