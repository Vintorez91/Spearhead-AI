# Attribution

Spearhead includes modified/adapted OpenRA bot implementation and rule configuration. OpenRA is copyright its contributors and distributed under the GNU General Public License version 3. Existing notices in source files are retained. This package contains corresponding C# source and build instructions for the included OpenRA.AITest.dll. Engine assemblies and proprietary game assets must be obtained separately. Development involved human direction and OpenAI Codex assistance; neither organization endorses this experimental mod.
