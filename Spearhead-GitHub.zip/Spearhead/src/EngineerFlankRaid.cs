using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  readonly HashSet<uint> raidHandled=new HashSet<uint>(); public int RaidCaptured {get;private set;}
  internal void StartRaidFixture(Actor transport,Actor[] engineers,Actor[] targets,List<CPos> path){raidTransport=transport;ReserveRaidActor(transport);raidEngineers.AddRange(engineers);foreach(var e in engineers)ReserveRaidActor(e);raidBuildings.AddRange(targets);engineerRaidPath=path;engineerRaidPhase=1;raidLoadingStarted=World.WorldTick;engineerRaidDeadline=World.WorldTick+2250;}
  int raidLoadingStarted; bool raidFastCommit; Actor raidTransport; readonly List<Actor> raidEngineers=new List<Actor>(); readonly List<Actor> raidBuildings=new List<Actor>();
  List<CPos> engineerRaidPath; int engineerRaidStep, engineerRaidPhase, engineerRaidDeadline, engineerRaidNext, engineerRaidCooldown;
  internal bool EngineerRaidOwns(Actor actor){return actor==raidTransport||raidEngineers.Contains(actor);}
  void ReserveRaidActor(Actor a){foreach(var s in Squads)s.Units.Remove(a);foreach(var g in reconGroups)g.Units.Remove(a);escortUnits.Remove(a);unitsHangingAroundTheBase.Remove(a);if(!activeUnits.Contains(a))activeUnits.Add(a);}
  void EndEngineerRaid(IBot bot,string reason){
   Console.WriteLine("AI-ENGINEER-RAID end reason="+reason);
   if(raidTransport!=null&&!raidTransport.IsDead&&raidTransport.IsInWorld){if(raidTransport.Trait<Cargo>().PassengerCount>0){engineerRaidPhase=4;bot.QueueOrder(new Order("Move",raidTransport,Target.FromCell(World,Player.HomeLocation),false));Console.WriteLine("AI-ENGINEER-RAID retreat passengers stay aboard");return;} activeUnits.Remove(raidTransport);}
   foreach(var e in raidEngineers){if(e.IsInWorld&&!e.IsDead)bot.QueueOrder(new Order("Move",e,Target.FromCell(World,Player.HomeLocation),false));activeUnits.Remove(e);}
   raidEngineers.Clear();raidBuildings.Clear();raidHandled.Clear();raidTransport=null;engineerRaidPath=null;raidFastCommit=false;engineerRaidPhase=0;engineerRaidCooldown=World.WorldTick+4500;
  }
  void UpdateEngineerRaid(IBot bot){
   if(World.WorldTick<engineerRaidNext)return;engineerRaidNext=World.WorldTick+75;
   var strategy=Strategy;if(strategy==null)return;strategy.Refresh();
   var dangers=strategy.KnownEnemies.Where(e=>e.Armed).Select(e=>e.Position).ToArray();
   if(engineerRaidPhase==0){
    if(World.WorldTick<engineerRaidCooldown||strategy.HoldingOffense||strategy.CombatCount<18||strategy.ArmyValue<9000)return;
    var expansion=Player.PlayerActor.TraitOrDefault<ImprovedMcvManagerBotModule>();if(expansion!=null&&expansion.SavingForExpansion())return;
    var money=Player.PlayerActor.Trait<PlayerResources>();if(money.Cash+money.Resources<3500)return;
    var candidates=World.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&a.CanBeViewedByPlayer(Player)&&Player.RelationshipWith(a.Owner)==PlayerRelationship.Enemy&&a.Info.HasTraitInfo<CapturableInfo>()&&new[]{"fact","weap","proc","dome","stek","atek","powr","apwr"}.Contains(a.Info.Name))
     .Where(a=>dangers.All(d=>(a.Location-d).LengthSquared>100)).OrderByDescending(a=>a.Info.Name=="fact"?5:a.Info.Name=="weap"?4:a.Info.Name=="proc"?3:1).Take(6).ToArray();
    if(candidates.Length<2)return;
    var transport=World.Actors.FirstOrDefault(a=>a.Owner==Player&&a.Info.Name=="apc"&&a.IsInWorld&&!a.IsDead&&a.IsIdle&&VeteranRank(a)==0&&!IsRecoveringVeteran(a)&&!IsEscort(a)&&a.Trait<Cargo>().PassengerCount==0 && a.Trait<Health>().HP>=a.Trait<Health>().MaxHP*0.85 && dangers.All(d=>(d-a.Location).LengthSquared>144) && World.Actors.Any(b=>b.Owner==Player&&b.IsInWorld&&!b.IsDead&&(b.Info.Name=="fact"||b.Info.Name=="weap")&&(b.Location-a.Location).LengthSquared<=144));
    var builder=Player.PlayerActor.TraitsImplementing<IBotRequestUnitProduction>().FirstOrDefault(Exts.IsTraitEnabled);if(builder==null)return;
    if(transport==null){if(LegacyAIUtils.FindQueues(Player,"Vehicle").Any(q=>q.BuildableItems().Any(a=>a.Name=="apc"))&&builder.RequestedProductionCount(bot,"apc")==0&&!LegacyAIUtils.FindQueues(Player,"Vehicle").Any(q=>q.AllQueued().Any(i=>i.Item=="apc"))){builder.RequestUnitProduction(bot,"apc");Console.WriteLine("AI-ENGINEER-RAID requesting APC for observed opportunity");engineerRaidCooldown=World.WorldTick+750;}return;}
    var mobile=transport.Trait<Mobile>();var path=FairNavigation.Route(World,Player,mobile.Locomotor,transport.Location,candidates[0].Location,4,dangers);
    if(path.Count==0)return;
    var nearby=candidates.Where(a=>(a.Location-candidates[0].Location).LengthSquared<=100).Take(3).ToArray();if(nearby.Length<2)return;
    raidTransport=transport;ReserveRaidActor(transport);raidBuildings.AddRange(nearby);engineerRaidPath=path;engineerRaidStep=0;engineerRaidPhase=1;raidLoadingStarted=World.WorldTick;engineerRaidDeadline=World.WorldTick+2250;
    Console.WriteLine("AI-ENGINEER-RAID planned targets="+nearby.Length+" route="+path.Count);
   }
   if(raidTransport==null||raidTransport.IsDead||!raidTransport.IsInWorld||raidTransport.Owner!=Player){EndEngineerRaid(bot,"transport_lost");return;}
   if(engineerRaidPhase==4){if((raidTransport.Location-Player.HomeLocation).LengthSquared<=36&&dangers.All(d=>(d-raidTransport.Location).LengthSquared>=100)){if(raidTransport.Trait<Cargo>().PassengerCount>0)bot.QueueOrder(new Order("Unload",raidTransport,false));else EndEngineerRaid(bot,"safe_return");}else if(raidTransport.IsIdle)bot.QueueOrder(new Order("Move",raidTransport,Target.FromCell(World,Player.HomeLocation),false));return;}
   if(World.WorldTick>engineerRaidDeadline||(strategy.HoldingOffense&&engineerRaidPhase==1)){EndEngineerRaid(bot,"danger_or_timeout");return;}
   var cargo=raidTransport.Trait<Cargo>();
   if(engineerRaidPhase==1){
    var assigned=Player.PlayerActor.Trait<ImprovedNeutralCaptureBotModule>();
    foreach(var engineer in World.Actors.Where(a=>a.Owner==Player&&a.Info.Name=="e6"&&a.IsInWorld&&!a.IsDead&&a.IsIdle&&!assigned.EngineerAssigned(a)&&!raidEngineers.Contains(a)).OrderBy(a=>(a.Location-raidTransport.Location).LengthSquared).Take(raidBuildings.Count-raidEngineers.Count)){raidEngineers.Add(engineer);ReserveRaidActor(engineer);}
    var builder=Player.PlayerActor.TraitsImplementing<IBotRequestUnitProduction>().FirstOrDefault(Exts.IsTraitEnabled);
    var queued=LegacyAIUtils.FindQueues(Player,"Infantry").Sum(q=>q.AllQueued().Count(i=>i.Item=="e6"));
    if(builder!=null&&raidEngineers.Count+queued+builder.RequestedProductionCount(bot,"e6")<raidBuildings.Count)builder.RequestUnitProduction(bot,"e6");
    foreach(var engineer in raidEngineers.Where(a=>a.IsInWorld&&!a.IsDead))bot.QueueOrder(new Order("EnterTransport",engineer,Target.FromActor(raidTransport),false));
    if(cargo.PassengerCount<raidBuildings.Count){
     if(cargo.PassengerCount<2||World.WorldTick-raidLoadingStarted<625)return;
     var boarded=raidEngineers.Where(a=>!a.IsDead&&!a.IsInWorld).Take(cargo.PassengerCount).ToArray();
     if(boarded.Length!=cargo.PassengerCount)return;
     foreach(var late in raidEngineers.Except(boarded).ToArray()){activeUnits.Remove(late);if(late.IsInWorld&&!late.IsDead)bot.QueueOrder(new Order("Move",late,Target.FromCell(World,Player.HomeLocation),false));}
     raidEngineers.Clear();raidEngineers.AddRange(boarded);raidBuildings.RemoveRange(boarded.Length,raidBuildings.Count-boarded.Length);
     Console.WriteLine("AI-ENGINEER-RAID depart without late third engineer");
    }
    engineerRaidPhase=2;engineerRaidDeadline=World.WorldTick+2250;Console.WriteLine("AI-ENGINEER-RAID loaded engineers="+cargo.PassengerCount);
   }
   if(engineerRaidPhase==2){
    var memories=strategy.KnownEnemies;
    var targets=raidBuildings.Where(a=>memories.Any(e=>e.Id==a.ActorID)||a.CanBeViewedByPlayer(Player)&&a.IsInWorld&&!a.IsDead&&a.Owner!=Player).ToArray();
    if(targets.Length==0){EndEngineerRaid(bot,"targets_unavailable");return;}
    var distance=targets.Min(a=>{var memory=memories.FirstOrDefault(e=>e.Id==a.ActorID);return ((memory==null?a.Location:memory.Position)-raidTransport.Location).LengthSquared;});
    var threat=dangers.Any(d=>(d-raidTransport.Location).LengthSquared<64)||engineerRaidPath.Skip(engineerRaidStep).Any(c=>dangers.Any(d=>(c-d).LengthSquared<100));
    var foot=raidEngineers.FirstOrDefault(a=>!a.IsDead);
    if(distance<=64&&foot!=null&&targets.Any(a=>a.CanBeViewedByPlayer(Player)&&FairNavigation.CaptureAccess(World,Player,foot.Trait<Mobile>().Locomotor,raidTransport.Location,a.Location,new CPos[0]))){
     bot.QueueOrder(new Order("Unload",raidTransport,false));engineerRaidPhase=3;engineerRaidDeadline=World.WorldTick+1500;
     Console.WriteLine("AI-ENGINEER-RAID decision=unload_commit distance2="+distance+" threat="+threat);return;
    }
    var health=raidTransport.Trait<Health>();
    if(threat&&(distance>196||health.HP<health.MaxHP/4)){EndEngineerRaid(bot,"threat_before_commit_or_critical_hp");return;}
    if(threat&&!raidFastCommit){raidFastCommit=true;Console.WriteLine("AI-ENGINEER-RAID decision=fast_commit distance2="+distance+" hp="+health.HP);}
    if((raidTransport.Location-engineerRaidPath[engineerRaidStep]).LengthSquared<9)engineerRaidStep=Math.Min(engineerRaidStep+6,engineerRaidPath.Count-1);
    if(engineerRaidStep==engineerRaidPath.Count-1&&(raidTransport.Location-engineerRaidPath[engineerRaidStep]).LengthSquared<9){bot.QueueOrder(new Order("Unload",raidTransport,false));engineerRaidPhase=3;Console.WriteLine("AI-ENGINEER-RAID unloading on safe flank");}
    else bot.QueueOrder(new Order("Move",raidTransport,Target.FromCell(World,engineerRaidPath[engineerRaidStep]),false));
    return;
   }
   if(engineerRaidPhase==3){
    var remaining=0;
    for(var i=0;i<raidEngineers.Count;i++){
     var target=raidBuildings[i];var engineer=raidEngineers[i];
     if(target.Owner==Player){
      if(!raidHandled.Add(target.ActorID))continue;RaidCaptured++;
      if(target.CanBeViewedByPlayer(Player)){var keep=(target.Info.Name=="fact"||target.Info.Name=="weap")&&dangers.All(d=>(d-target.Location).LengthSquared>144);if(!keep&&target.Info.HasTraitInfo<SellableInfo>()&&target.IsInWorld&&!target.IsDead){bot.QueueOrder(new Order("Sell",target,false));Console.WriteLine("AI-ENGINEER-RAID sell captured "+target.Info.Name);}else Console.WriteLine("AI-ENGINEER-RAID retain captured "+target.Info.Name);}
      continue;
     }
     if(engineer.IsDead||!engineer.IsInWorld||!target.CanBeViewedByPlayer(Player)||target.IsDead)continue;
     if(!FairNavigation.CaptureAccess(World,Player,engineer.Trait<Mobile>().Locomotor,engineer.Location,target.Location,new CPos[0]))continue;
     remaining++;
     if(engineer.IsIdle)bot.QueueOrder(new Order("CaptureActor",engineer,Target.FromActor(target),false));
    }
    if(remaining==0&&cargo.PassengerCount==0)EndEngineerRaid(bot,"completed_or_targets_unavailable");
   }
  }
 }
}






