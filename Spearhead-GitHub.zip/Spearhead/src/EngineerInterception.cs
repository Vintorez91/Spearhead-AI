using System;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  int nextEngineerInterception;
  readonly System.Collections.Generic.Dictionary<Actor,Actor> engineerDefenders = new System.Collections.Generic.Dictionary<Actor,Actor>();
  internal bool IsEngineerDefender(Actor unit) { return engineerDefenders.ContainsKey(unit); }
  internal bool InfantryPinned(Actor unit) {
   return unit.TraitsImplementing<TakeCover>().Any(t=>!t.IsTraitDisabled &&
    ((IRenderInfantrySequenceModifier)t).IsModifyingSequence);
  }
  internal bool EngineerThreat(Actor enemy) {
   if(enemy==null||enemy.IsDead||!enemy.IsInWorld||!enemy.CanBeViewedByPlayer(Player)
    ||enemy.Owner.RelationshipWith(Player)!=PlayerRelationship.Enemy||!enemy.TraitsImplementing<Captures>().Any(c=>!c.IsTraitDisabled))return false;
   var capture=enemy.TraitOrDefault<CaptureManager>();var mobile=enemy.TraitOrDefault<Mobile>();
   if(capture==null||mobile==null)return false;
   return World.FindActorsInCircle(enemy.CenterPosition,WDist.FromCells(6)).Any(b=>b.Owner==Player&&!b.IsDead&&b.IsInWorld
    &&(b.Info.Name=="fact"||b.Info.Name=="weap"||b.Info.Name=="barr"||b.Info.Name=="tent"||b.Info.Name=="proc")
    &&b.TraitOrDefault<CaptureManager>()!=null&&capture.CanTarget(b.Trait<CaptureManager>())
    &&World.WorldActor.Trait<IPathFinder>().PathExistsForLocomotor(mobile.Locomotor,enemy.Location,b.Location));
  }
  void UpdateEngineerInterceptions(IBot bot) {
   foreach(var d in engineerDefenders.Keys.Where(a=>a.IsDead||!a.IsInWorld||IsRecoveringVeteran(a)||EngineerRaidOwns(a)||!EngineerThreat(engineerDefenders[a])).ToArray())
    engineerDefenders.Remove(d);
   if(World.WorldTick<nextEngineerInterception)return;nextEngineerInterception=World.WorldTick+25;
   var assigned=new System.Collections.Generic.HashSet<Actor>();
   foreach(var threat in World.Actors.Where(EngineerThreat).OrderBy(a=>a.ActorID).ToArray()) {
    var defenders=World.FindActorsInCircle(threat.CenterPosition,WDist.FromCells(8))
     .Where(a=>a.Owner==Player&&!a.IsDead&&a.IsInWorld&&!assigned.Contains(a)
      &&!a.Info.HasTraitInfo<BuildingInfo>()&&a.TraitOrDefault<Mobile>()!=null&&!a.TraitsImplementing<Captures>().Any()&&!EngineerRaidOwns(a)&&!IsRecoveringVeteran(a)&&!IsEscort(a)
      &&AttackOrFleeFuzzy.EffectiveDamage(a,new[]{threat})>0
      &&World.WorldActor.Trait<IPathFinder>().PathExistsForLocomotor(a.Trait<Mobile>().Locomotor,a.Location,threat.Location))
     .OrderBy(a=>engineerDefenders.TryGetValue(a,out var current)&&current==threat?0:1)
     .ThenBy(a=>(a.CenterPosition-threat.CenterPosition).Length)
     .ThenByDescending(a=>AttackOrFleeFuzzy.EffectiveDamage(a,new[]{threat})).Take(2).ToArray();
    foreach(var defender in defenders) {
     assigned.Add(defender);engineerDefenders[defender]=threat;
     foreach(var squad in Squads) squad.Units.Remove(defender);
     foreach(var group in reconGroups) group.Units.Remove(defender);
     unitsHangingAroundTheBase.Remove(defender);activeUnits.Remove(defender);
     bot.QueueOrder(new Order("Attack",defender,Target.FromActor(threat),false));
    }
    if(defenders.Length>0)Console.WriteLine("AI-TARGET engineer_intercept tick="+World.WorldTick+" engineer="+threat.ActorID+" defenders="+string.Join(",",defenders.Select(a=>a.ActorID)));
   }
  }
 }
}



