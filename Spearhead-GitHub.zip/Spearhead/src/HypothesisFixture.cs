using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using OpenRA.Traits;
using OpenRA.Primitives;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 sealed class ProbeBot : IBot {
  public Player Player {get; private set;}
  public IBotInfo Info => null;
  public readonly List<Order> Orders=new List<Order>();
  public ProbeBot(Player p){Player=p;}
  public void Activate(Player p){Player=p;}
  public void QueueOrder(Order o){Orders.Add(o);}
 }
 public partial class ImprovedStrategyBotModule {
  internal void ProbeKnowledge(params Observation[] observations) {
   known.Clear(); foreach(var o in observations)known[o.Id]=o;
   nextTick=world.WorldTick+10000; Plan=StrategicPlan.Pressure;
  }
 }
 public partial class AITestMetrics {
  Actor[] probeUnits, probeBreakUnits; Actor probeTarget, probeOther, probeFar; CPos probeGoal;
  void SetupHypothesisFixture(World world) {
   world.AddFrameEndTask(w=>{
    var own=w.Players.First(p=>p.IsBot&&p.BotType=="improved");
    var enemy=w.Players.First(p=>p.Playable&&p.RelationshipWith(own)==PlayerRelationship.Enemy);
    var mobile=w.Map.Rules.Actors["2tnk"].TraitInfo<MobileInfo>();
        var c=w.Map.FindTilesInAnnulus(own.HomeLocation,5,9).First(cell=>mobile.CanEnterCell(w,null,cell)&&!w.Actors.Any(a=>a.OccupiesSpace!=null&&a.Location==cell));
    var loco=w.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==mobile.Locomotor);
    List<CPos> terrainPath=null;
    foreach(var destination in w.Map.AllCells.Where(cell=>mobile.CanEnterCell(w,null,cell)).OrderByDescending(cell=>(cell-c).LengthSquared).Take(40)) {
     var path=FairNavigation.Route(w,own,loco,c,destination,0,new CPos[0],false);
     if(path.Count>=46){terrainPath=path;break;}
    }
    if(terrainPath==null)throw new InvalidOperationException("No suitable long terrain route for probe");
    terrainPath.Insert(0,c);
Func<string,Player,CPos,Actor> make=(name,p,pos)=>w.CreateActor(name,new TypeDictionary{new OwnerInit(p),new LocationInit(pos)});
    probeUnits=new[]{make("2tnk",own,c),make("2tnk",own,terrainPath[6]),make("2tnk",own,terrainPath[12])};
    probeBreakUnits=probeUnits.Concat(Enumerable.Range(1,5).Select(i=>make("2tnk",own,terrainPath[i]))).ToArray();
    probeTarget=make("harv",enemy,terrainPath[30]);
    make("e1",own,terrainPath[31]);
    probeGoal=terrainPath[44];
    var far=w.Map.FindTilesInAnnulus(probeTarget.Location,25,30).First(cell=>mobile.CanEnterCell(w,null,cell));
    probeFar=make("2tnk",own,far);
    var other=w.Map.FindTilesInAnnulus(probeTarget.Location,13,18).First(cell=>mobile.CanEnterCell(w,null,cell));
    probeOther=make("harv",enemy,other);make("e1",own,other+new CVec(1,0));
    own.Shroud.ExploreAll();
   });
  }
  void CheckHypothesisFixture(World world) {
   if(world.WorldTick!=20||probeUnits==null)return;
   probeUnits[0].Owner.PlayerActor.Trait<ImprovedSquadManagerBotModule>()
    .RunHypothesisProbe(probeUnits,probeBreakUnits,probeTarget,probeOther,probeFar,probeGoal);
   Console.WriteLine("AI-PROBE COMPLETED all directed rule checks");
  }
 }
 public partial class ImprovedSquadManagerBotModule {
  internal void RunHypothesisProbe(Actor[] units,Actor[] tanks,Actor target,Actor other,Actor far,CPos goal) {
   var savedBot=bot;var record=new ProbeBot(Player);bot=record;
   try {
    var squad=new Squad(record,this,SquadType.Assault,target);
    squad.Units.AddRange(units); Squads.Clear();Squads.Add(squad);
    var originalManager=Player.PlayerActor.TraitsImplementing<OpenRA.Mods.Common.Traits.SquadManagerBotModule>().First();
    var original=new OpenRA.Mods.Common.Traits.BotModules.Squads.Squad(record,originalManager,OpenRA.Mods.Common.Traits.BotModules.Squads.SquadType.Assault);
    foreach(var u in units)original.Units.Add(u);
    var baseType=typeof(OpenRA.Mods.Common.Traits.BotModules.Squads.Squad).Assembly.GetType("OpenRA.Mods.Common.Traits.BotModules.Squads.GroundStateBase");
    var originalLeader=(Actor)baseType.GetMethod("NewLeader",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,new object[]{original});
    Console.WriteLine("AI-PROBE original_leader="+originalLeader.ActorID+" original_x="+originalLeader.Location.X+" rear_x="+units[0].Location.X+" front_x="+units[2].Location.X);
    Strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation{Id=999990,Info=World.Map.Rules.Actors["fact"],Owner=target.Owner,Position=goal,Building=true,Seen=World.WorldTick,Value=2000});
    var advanced=ApproachKnownLocation(squad);
    var order=record.Orders.LastOrDefault(o=>o.OrderString=="AttackMove");
    Console.WriteLine("AI-PROBE route normal_order="+advanced+" waypoint="+(order==null?"none":World.Map.CellContaining(order.Target.CenterPosition).ToString())+" front="+units[2].Location+" original_leader="+originalLeader.Location);
    if(!advanced||order==null)throw new InvalidOperationException("Open route did not produce an advance order");
    var firstWaypoint=World.Map.CellContaining(order.Target.CenterPosition);
    var loco=units[2].Trait<Mobile>().Locomotor;
    var direct=FairNavigation.Route(World,Player,loco,units[2].Location,goal,3,new CPos[0]);
    var toWaypoint=FairNavigation.Route(World,Player,loco,units[2].Location,firstWaypoint,0,new CPos[0]);
    var afterWaypoint=FairNavigation.Route(World,Player,loco,firstWaypoint,goal,3,new CPos[0]);
    Console.WriteLine("AI-PROBE route_cost direct="+direct.Count+" via_waypoint="+(toWaypoint.Count+afterWaypoint.Count)+" extra_steps="+(toWaypoint.Count+afterWaypoint.Count-direct.Count));
    var reversed=new Squad(record,this,SquadType.Assault,target);
    reversed.Units.AddRange(units.Reverse());Squads.Add(reversed);record.Orders.Clear();
    if(!ApproachKnownLocation(reversed))throw new InvalidOperationException("Reversed open route rejected");
    var second=record.Orders.Last(o=>o.OrderString=="AttackMove");
    var secondWaypoint=World.Map.CellContaining(second.Target.CenterPosition);
    Console.WriteLine("AI-PROBE route reversed_waypoint="+secondWaypoint+" list_order_sensitive="+(firstWaypoint!=secondWaypoint));
    Squads.Clear();Squads.Add(squad);squad.Units.Clear();squad.Units.AddRange(units.Take(2));
    var neighbor=new Squad(record,this,SquadType.Assault,target);neighbor.Units.Add(units[2]);Squads.Add(neighbor);
    var nearby=TeamLocalForce(squad,squad.Units).Distinct().Count();
    neighbor.TargetActor=other;var unrelated=TeamLocalForce(squad,squad.Units).Distinct().Count();
    neighbor.TargetActor=target;neighbor.Units.Clear();neighbor.Units.Add(far);
    var distant=TeamLocalForce(squad,squad.Units).Distinct().Count();
    original.Units.Clear();foreach(var u in squad.Units)original.Units.Add(u);
    Console.WriteLine("AI-PROBE local primary=2 nearby="+nearby+" unrelated="+unrelated+" distant="+distant+" original_squad_members="+original.Units.Count);
    if(unrelated!=2||distant!=2)throw new InvalidOperationException("Unrelated or distant group counted as local");
    // Real route code with identical terrain and force: fresh and stale defense memory.
    squad.Units.Clear();squad.Units.AddRange(units);
    squad.Units.Clear();squad.Units.AddRange(tanks);
    var guardPos=target.Location+new CVec(-2,0);
    foreach(var testCase in new[]{0,1,2}) {
     var age=testCase==2?8000:0;var guardValue=testCase==0?600:5000;
     Strategy.ProbeKnowledge(new ImprovedStrategyBotModule.Observation{Id=999991,Info=World.Map.Rules.Actors["ftur"],Owner=target.Owner,Position=guardPos,Building=true,Armed=true,Seen=World.WorldTick-age,Value=guardValue});
     List<CPos> route;
     var ready=OffensiveRouteReady(squad,target,out route);
     var plain=FairNavigation.Route(World,Player,units[0].Trait<Mobile>().Locomotor,units[0].Location,target.Location,5,new CPos[0]);
     var enginePath=World.WorldActor.Trait<IPathFinder>().PathExistsForLocomotor(units[0].Trait<Mobile>().Locomotor,units[0].Location,target.Location);
     Console.WriteLine("AI-PROBE breakthrough guard_value="+guardValue+" age="+age+" ready="+ready+" route_cells="+route.Count+" plain_cells="+plain.Count+" official_path_exists="+enginePath+" army_value="+squad.Units.Sum(a=>a.GetSellValue()));
    }
   } finally { bot=savedBot; }
  }
 }
}


