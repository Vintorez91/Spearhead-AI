using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class AITestMetrics {
  StreamWriter navalLog;readonly Dictionary<uint,int> navalShots=new Dictionary<uint,int>();readonly Dictionary<uint,long> navalHpDamage=new Dictionary<uint,long>();readonly Dictionary<uint,int> navalIdleTicks=new Dictionary<uint,int>();int navalSample;
  static bool IsNavalActor(Actor a){return a!=null&&new[]{"ca","msub","ss","dd","pt"}.Contains(a.Info.Name);}
  void InitializeNavalLogs(string prefix){navalLog=new StreamWriter(prefix+"-naval.csv"){AutoFlush=true};navalLog.WriteLine("tick,event,id,type,owner,target_id,x,y,shots,hp_damage,no_visible_target_ticks,detail");}
  public void NavalShot(Actor self,Target target,string weapon){if(!IsNavalActor(self)||navalLog==null)return;int shots;navalShots.TryGetValue(self.ActorID,out shots);navalShots[self.ActorID]=++shots;navalLog.WriteLine(Csv(self.World.WorldTick,"shot",self.ActorID,self.Info.Name,self.Owner.InternalName,target.Type==TargetType.Actor?target.Actor.ActorID.ToString():"",self.Location.X,self.Location.Y,shots,"","",weapon));}
  public void NavalDamage(Actor victim,Actor attacker,int damage){if(!IsNavalActor(attacker)||navalLog==null||damage<=0)return;long total;navalHpDamage.TryGetValue(attacker.ActorID,out total);navalHpDamage[attacker.ActorID]=total+damage;navalLog.WriteLine(Csv(victim.World.WorldTick,"damage",attacker.ActorID,attacker.Info.Name,attacker.Owner.InternalName,victim.ActorID,"","","",damage,"","actual HP removed; capped by HP"));}
  void NavalSnapshot(World world){if(navalLog==null)return;var elapsed=navalSample==0?0:world.WorldTick-navalSample;navalSample=world.WorldTick;
   foreach(var a in world.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&IsNavalActor(a))){var manager=a.Owner.PlayerActor.TraitOrDefault<ImprovedSquadManagerBotModule>();var target=manager?.NavalMissionTarget(a);int idle,shots;long damage;navalIdleTicks.TryGetValue(a.ActorID,out idle);if(a.Owner.BotType=="improved"&&(target==null||!target.CanBeViewedByPlayer(a.Owner)))idle+=elapsed;navalIdleTicks[a.ActorID]=idle;navalShots.TryGetValue(a.ActorID,out shots);navalHpDamage.TryGetValue(a.ActorID,out damage);navalLog.WriteLine(Csv(world.WorldTick,"sample",a.ActorID,a.Info.Name,a.Owner.InternalName,target==null?"":target.ActorID.ToString(),a.Location.X,a.Location.Y,shots,damage,a.Owner.BotType=="improved"?idle.ToString():"",a.IsIdle?"idle":"active"));}
   foreach(var p in world.Players.Where(p=>p.Playable&&!p.Spectating)){var enemy=world.Actors.Count(a=>a.IsInWorld&&!a.IsDead&&a.Info.HasTraitInfo<BuildingInfo>()&&p.RelationshipWith(a.Owner)==PlayerRelationship.Enemy);navalLog.WriteLine(Csv(world.WorldTick,"enemy_buildings", "","",p.InternalName,"","","","","","",enemy));}
  }
 }
}
