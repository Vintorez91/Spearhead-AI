using OpenRA.Mods.Common.Traits;
namespace OpenRA.Mods.Common.Traits.AITest {
internal sealed class DomainIndex {
 readonly IPathFinder finder;
 public DomainIndex(World world) { finder=world.WorldActor.Trait<IPathFinder>(); }
 public bool IsPassable(CPos source,CPos target,Locomotor locomotor) { return finder.PathExistsForLocomotor(locomotor,source,target); }
}
}
namespace OpenRA.Mods.Common.Traits.AITest {
internal static class LegacyExtensions {
 public static Actor ClosestTo(this System.Collections.Generic.IEnumerable<Actor> actors, WPos position) { return System.Linq.Enumerable.FirstOrDefault(System.Linq.Enumerable.OrderBy(actors,a=>(a.CenterPosition-position).LengthSquared)); }
 public static string F(this string format, params object[] args) { return string.Format(format,args); }
 public static Actor ClosestTo(this System.Collections.Generic.IEnumerable<Actor> actors, Actor actor) { return System.Linq.Enumerable.FirstOrDefault(System.Linq.Enumerable.OrderBy(actors,a=>(a.CenterPosition-actor.CenterPosition).LengthSquared)); }
}
}
