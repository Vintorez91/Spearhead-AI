using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest
{
    public enum StrategicPlan { Reconnaissance, Pressure, Exploit, Defend, Regroup, BuildCounters, AllIn, Finish }
    public sealed class StrategicSituation
    {
        public bool HomeThreat, RecentLoss, Opportunity, KnownObjectives, Outmatched, Overwhelming, EnemyCrippled;
        public int CombatCount;
    }
    public class ImprovedStrategyBotModuleInfo : ConditionalTraitInfo
    {
        public override object Create(ActorInitializer init) { return new ImprovedStrategyBotModule(init.Self, this); }
    }
    public partial class ImprovedStrategyBotModule : ConditionalTrait<ImprovedStrategyBotModuleInfo>, IBotTick
    {
        public sealed class Observation
        {
            public uint Id; public Player Owner;
            public ActorInfo Info;
            public CPos Position;
            public int Seen, Value;
            public bool Building, Armed;
            public string Armor;
            public BitSet<TargetableType> TargetTypes;
        }
        readonly World world;
        readonly Player player;
        readonly Dictionary<uint, Observation> known = new Dictionary<uint, Observation>();
        Dictionary<uint, int> lastArmy = new Dictionary<uint, int>();
        int nextTick, regroupUntil, planSince, reserveSince = -1, reserveCooldownUntil;
        bool lastReserve; int reserveBestMoney, reserveProgressTick;
        bool sawEnemyProduction; int lastProductionCleared = -100000;
        readonly Dictionary<Player,int> enemyBaseSeen=new Dictionary<Player,int>();
        readonly Dictionary<Player,int> enemyProductionCleared=new Dictionary<Player,int>();
        readonly HashSet<Player> enemyProductionSeen=new HashSet<Player>();
        public int EstimatedLandArmy { get; private set; }
        public int EstimatedEnemyResistance { get; private set; }
        public StrategicPlan Plan { get; private set; }
        public CPos? Focus { get; private set; }
        public Actor[] VisibleEnemies { get; private set; } = new Actor[0];
        public Actor[] HomeEnemies { get; private set; } = new Actor[0];
        public Observation[] KnownEnemies { get { return known.Values.ToArray(); } }
        public int CombatCount { get; private set; }
        public int ArmyValue { get; private set; }
        public Actor[] AllyEnemies { get; private set; } = new Actor[0];
        public bool OpeningSecured { get { return world.WorldTick >= 4500 && ArmyValue >= 6000; } }
        public int AttackSize { get { return Plan == StrategicPlan.Finish ? 4 : Plan == StrategicPlan.AllIn ? 18 : Plan == StrategicPlan.Exploit ? 8 : Plan == StrategicPlan.BuildCounters || Plan == StrategicPlan.Regroup ? 18 : 12; } }
        public bool MayExpand { get { return Plan != StrategicPlan.Defend && Plan != StrategicPlan.Regroup && CombatCount >= 10 && OpeningSecured && AllyEnemies.Length == 0; } }
        public bool MayCapture { get { return Plan != StrategicPlan.Defend && CombatCount >= 8 && AllyEnemies.Length == 0; } }
        public bool HoldingOffense { get { return Plan == StrategicPlan.Defend || Plan == StrategicPlan.Regroup; } }
        public ImprovedStrategyBotModule(Actor self, ImprovedStrategyBotModuleInfo info) : base(info) { world = self.World; player = self.Owner; }
        public static StrategicPlan ChoosePlan(StrategicSituation s)
        {
            if (s.HomeThreat) return StrategicPlan.Defend;
            if (s.RecentLoss) return StrategicPlan.Regroup;
            if (s.EnemyCrippled && s.CombatCount >= 4) return StrategicPlan.Finish;
            if (s.Overwhelming && s.CombatCount >= 18) return StrategicPlan.AllIn;
            if (s.Opportunity && s.CombatCount >= 10) return StrategicPlan.Exploit;
            if (s.Outmatched) return StrategicPlan.BuildCounters;
            if (!s.KnownObjectives) return StrategicPlan.Reconnaissance;
            return StrategicPlan.Pressure;
        }
        public void Refresh()
        {
            if (world.WorldTick < nextTick) return;
            nextTick = world.WorldTick + 125; RefreshGpsContacts();
            var own = world.Actors.Where(a => a.Owner == player && !a.IsDead && a.IsInWorld).ToArray();
            var army = own.Where(a => a.Info.HasTraitInfo<MobileInfo>() && a.Info.HasTraitInfo<AttackBaseInfo>()).ToArray();
            CombatCount = army.Length;
            var values = army.ToDictionary(a => a.ActorID, a => Math.Max(1, a.Info.TraitInfoOrDefault<ValuedInfo>() == null ? 100 : a.Info.TraitInfo<ValuedInfo>().Cost));
            var lost = lastArmy.Where(kv => !values.ContainsKey(kv.Key)).Sum(kv => kv.Value);
            if (lost >= 600 && lost >= lastArmy.Values.Sum() * 0.25) regroupUntil = world.WorldTick + 500;
            lastArmy = values;
            VisibleEnemies = world.Actors.Where(a => a.OccupiesSpace != null && a.CanBeViewedByPlayer(player) && !a.IsDead && a.IsInWorld && !a.Info.HasTraitInfo<HuskInfo>() && player.RelationshipWith(a.Owner) == PlayerRelationship.Enemy).ToArray();
            foreach (var a in VisibleEnemies)
                known[a.ActorID] = new Observation { Id = a.ActorID, Owner = a.Owner, Info = a.Info, Position = a.Location, Seen = world.WorldTick,
                    Value = Math.Max(1, a.GetSellValue()), Building = a.Info.HasTraitInfo<BuildingInfo>(), Armed = a.Info.HasTraitInfo<AttackBaseInfo>(),
                    Armor = a.TraitsImplementing<Armor>().Where(t => !t.IsTraitDisabled).Select(t => t.Info.Type).FirstOrDefault(), TargetTypes = a.GetEnabledTargetTypes() };
                        foreach(var a in VisibleEnemies.Where(a=>IsEnemyProduction(a.Info))) {
                sawEnemyProduction=true;enemyProductionSeen.Add(a.Owner);enemyBaseSeen[a.Owner]=world.WorldTick;
            }
            foreach (var o in known.Values.ToArray())
                if ((!o.Building && world.WorldTick - o.Seen > 1500) || (player.Shroud.IsVisible(o.Position) && !VisibleEnemies.Any(a => a.ActorID == o.Id))) { if(IsEnemyProduction(o.Info)&&player.Shroud.IsVisible(o.Position)&&!VisibleEnemies.Any(a=>a.ActorID==o.Id)){lastProductionCleared=world.WorldTick;enemyProductionCleared[o.Owner]=world.WorldTick;} known.Remove(o.Id); }
            var economic = own.Where(a => a.Info.Name == "fact" || a.Info.Name == "proc" || a.Info.Name == "harv").ToArray();
            HomeEnemies = VisibleEnemies.Where(a => a.Info.HasTraitInfo<AttackBaseInfo>() && economic.Any(b => (a.CenterPosition - b.CenterPosition).LengthSquared < 144L * 1024 * 1024)).ToArray();
            var opportunity = VisibleEnemies.Any(a => (a.Info.HasTraitInfo<BuildingInfo>() || a.Info.HasTraitInfo<HarvesterInfo>()) && VisibleEnemies.Count(e => e.Info.HasTraitInfo<AttackBaseInfo>() && (e.CenterPosition - a.CenterPosition).LengthSquared < 64L * 1024 * 1024) <= 1);
            var ownValue = values.Values.Sum(); ArmyValue = ownValue;
            var allied = world.Actors.Where(a => a.Owner != player && player.RelationshipWith(a.Owner) == PlayerRelationship.Ally && a.CanBeViewedByPlayer(player) && !a.IsDead && a.IsInWorld).ToArray();
            var allyEconomy = allied.Where(a => a.Info.Name == "fact" || a.Info.Name == "proc" || a.Info.Name == "harv").ToArray();
            AllyEnemies = VisibleEnemies.Where(a => a.Info.HasTraitInfo<AttackBaseInfo>() && allyEconomy.Any(b => (a.CenterPosition - b.CenterPosition).LengthSquared < 144L * 1024 * 1024)).ToArray();
            var allyGuard = allied.Where(a => a.Info.HasTraitInfo<AttackBaseInfo>() && AllyEnemies.Any(e => (a.CenterPosition - e.CenterPosition).LengthSquared < 196L * 1024 * 1024)).ToArray();
            if (AllyEnemies.Length == 0 || Squads.AttackOrFleeFuzzy.Default.CanAttack(allyGuard, AllyEnemies)) AllyEnemies = new Actor[0];
            var defence = known.Values.Where(o => o.Armed && o.Building && world.WorldTick-o.Seen<=7500).Sum(o => o.Value);
                        var localGuard = army.Where(a => HomeEnemies.Any(e => (e.CenterPosition - a.CenterPosition).LengthSquared < 196L * 1024 * 1024)).ToArray();
            var threatValue = HomeEnemies.Sum(a => Math.Max(1, a.GetSellValue()));
            var urgent = HomeEnemies.Length > 0 && (threatValue >= 400 || HomeEnemies.Length >= 3) && !Squads.AttackOrFleeFuzzy.Default.CanAttack(localGuard, HomeEnemies);
                        var land=army.Where(a=>!new[]{"naval","lcraft","float","sub"}.Contains(a.Info.TraitInfo<MobileInfo>().Locomotor)&&!new[]{"e6","mcv","harv"}.Contains(a.Info.Name)).ToArray();
            EstimatedLandArmy=(int)land.Sum(a=>values[a.ActorID]*(a.TraitOrDefault<Health>()==null?1.0:a.Trait<Health>().HP/(double)a.Trait<Health>().MaxHP));
            var resistance=known.Values.Where(o=>o.Armed&&world.WorldTick-o.Seen<=(o.Building?7500:1500)&&(!o.Info.HasTraitInfo<MobileInfo>()||!new[]{"naval","lcraft","float","sub"}.Contains(o.Info.TraitInfo<MobileInfo>().Locomotor))).ToArray();
            var fresh=known.Values.Any(o=>world.WorldTick-o.Seen<=750&&(o.Building||o.Armed));
                        var opponents=world.Players.Where(p=>p.Playable&&!p.NonCombatant&&player.RelationshipWith(p)==PlayerRelationship.Enemy).ToArray();
            var recentBases=opponents.Count(p=>enemyBaseSeen.ContainsKey(p)&&world.WorldTick-enemyBaseSeen[p]<=1500);
            var uncertainty=opponents.Sum(p=>enemyBaseSeen.ContainsKey(p)&&world.WorldTick-enemyBaseSeen[p]<=1500?1200:4500);
            var confident=opponents.Length>0&&recentBases==opponents.Length;
            EstimatedEnemyResistance=resistance.Sum(o=>o.Value)+Math.Max(1200,uncertainty);
            var overwhelming=confident&&fresh&&land.Length>=18&&EstimatedLandArmy>=EstimatedEnemyResistance*1.8;
            if(Plan==StrategicPlan.AllIn&&confident&&known.Count>0&&EstimatedLandArmy>=EstimatedEnemyResistance*1.4)overwhelming=true;
            var crippled=opponents.Length>0&&opponents.All(p=>enemyProductionSeen.Contains(p)&&enemyProductionCleared.ContainsKey(p)&&world.WorldTick-enemyProductionCleared[p]<=7500)&&sawEnemyProduction&&world.WorldTick-lastProductionCleared<=7500&&!known.Values.Any(o=>IsEnemyProduction(o.Info))&&known.Values.Any(o=>o.Building)&&fresh&&land.Length>=4&&EstimatedLandArmy>=EstimatedEnemyResistance*1.5;
            var situation = new StrategicSituation { HomeThreat = urgent, RecentLoss = world.WorldTick < regroupUntil,
                Overwhelming = overwhelming, EnemyCrippled = crippled, Opportunity = opportunity, KnownObjectives = known.Count > 0, CombatCount = CombatCount, Outmatched = defence > ownValue * 0.8 && defence > 1500 };
            var chosen = ChoosePlan(situation);
            var logger=world.WorldActor.TraitOrDefault<AITestMetrics>();if(logger!=null)logger.TelemetryAttackDecision(world.WorldTick,player,chosen,EstimatedLandArmy,EstimatedEnemyResistance,uncertainty,recentBases,opponents.Length,VisibleEnemies.Length,known.Count,urgent,world.WorldTick<regroupUntil);
            // Respond immediately to danger; keep ordinary plans stable for ten game seconds.
            if (chosen != Plan && (chosen == StrategicPlan.Defend || chosen == StrategicPlan.Regroup || Plan == StrategicPlan.Defend || world.WorldTick - planSince >= 250))
            { Plan = chosen; planSince = world.WorldTick; Console.WriteLine("AI-PLAN tick=" + world.WorldTick + " plan=" + Plan + " army=" + CombatCount + " seen=" + VisibleEnemies.Length + " remembered=" + known.Count + " losses=" + lost + " landValue="+EstimatedLandArmy+" estimatedResistance="+EstimatedEnemyResistance); }
            Focus = Plan == StrategicPlan.Defend && HomeEnemies.Length > 0 ? (CPos?)HomeEnemies[0].Location : known.Values.OrderByDescending(o => ObjectiveValue(o)).Select(o => (CPos?)o.Position).FirstOrDefault();
        }
        static bool IsEnemyProduction(ActorInfo info) { return new[]{"fact","weap","barr","tent","afld","hpad","spen","syrd"}.Contains(info.Name); }
        double ObjectiveValue(Observation o)
        {
            double value = o.Info.HasTraitInfo<HarvesterInfo>() ? 1800 : o.Info.Name == "weap" || o.Info.Name == "fact" ? 1500 : o.Building ? 900 : 250;
            var guards = known.Values.Count(e => e.Armed && (e.Position - o.Position).LengthSquared < 64);
            return value / (1 + guards * 3 + (o.Position - player.HomeLocation).Length * 0.1);
        }
        public double ObjectiveWeight(Actor target)
        {
            if (!target.CanBeViewedByPlayer(player)) return 0;
            return (target.Info.HasTraitInfo<HarvesterInfo>() ? 1.8 : target.Info.Name == "weap" || target.Info.Name == "fact" ? 1.5 : 1) * (Plan == StrategicPlan.Exploit || Plan == StrategicPlan.Finish ? 1.4 : 1);
        }
        public bool ReserveExpansionFunds(bool suitableSite, bool recovery = false)
        {
            Refresh();
            var reserve = suitableSite && (MayExpand || recovery) && world.WorldTick >= reserveCooldownUntil;
            if (!reserve) reserveSince = -1;
            else if (reserveSince < 0) { reserveSince = world.WorldTick; reserveProgressTick = world.WorldTick; reserveBestMoney = 0; }
            else { var funds=player.PlayerActor.Trait<PlayerResources>(); var current=funds.Cash+funds.Resources; if(current>=reserveBestMoney+100){reserveBestMoney=current;reserveProgressTick=world.WorldTick;} if(world.WorldTick-reserveProgressTick>=2250||world.WorldTick-reserveSince>=6000){reserve=false;reserveSince=-1;reserveCooldownUntil=world.WorldTick+750;Console.WriteLine("AI-BUDGET expansion stalled; resume economy");} }
            if (reserve != lastReserve) { lastReserve = reserve; Console.WriteLine("AI-BUDGET expansionReserve=" + reserve + " plan=" + Plan); }
            return reserve;
        }
        void IBotTick.BotTick(IBot bot) { Refresh(); }
    }
}










