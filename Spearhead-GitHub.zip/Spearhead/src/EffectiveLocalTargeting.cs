using System;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Mods.Common.Warheads;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedSquadManagerBotModule
 {
  // Local preference only: macro targets and ongoing attacks remain owned by their squad state.
  internal Actor ChooseEffectiveLocalTarget(Actor unit, Actor fallback)
  {
   var arms = unit.TraitsImplementing<Armament>().Where(a => !a.IsTraitDisabled && !a.IsTraitPaused).ToArray();
   if (arms.Length == 0) return fallback;
   var radius = arms.Select(a => a.MaxRange().Length).DefaultIfEmpty(0).Max() + 1024;
   var candidates = World.FindActorsInCircle(unit.CenterPosition, new WDist(radius))
    .Where(a => a != unit && !a.IsDead && a.IsInWorld && a.Owner.RelationshipWith(Player) == PlayerRelationship.Enemy
     && a.CanBeViewedByPlayer(Player) && !a.Info.HasTraitInfo<HuskInfo>())
    .OrderBy(a => a.ActorID).ToArray();
   Actor best = null; double bestScore = 0;
   foreach (var candidate in candidates)
   {
    var score = LocalTargetScore(unit, candidate);
    if (score > bestScore) { best = candidate; bestScore = score; }
   }
   if (best == null) return InfantryPinned(unit) && LocalTargetScore(unit, fallback) <= 0 ? null : fallback;
   if (fallback != null && bestScore < LocalTargetScore(unit, fallback) * 1.25) return fallback;
   if (best != fallback)
    Console.WriteLine("AI-TARGET tick=" + World.WorldTick + " player=" + Player.InternalName + " unit=" + unit.ActorID + ":" + unit.Info.Name + " chosen=" + best.ActorID + ":" + best.Info.Name + " macro=" + (fallback == null ? "none" : fallback.ActorID + ":" + fallback.Info.Name) + " reason=effective_local_weapon");
   return best;
  }
  internal double LocalTargetScore(Actor unit, Actor target)
  {
   if (target == null || target.IsDead || !target.IsInWorld || !target.CanBeViewedByPlayer(Player)) return 0;
   var distance = (target.CenterPosition - unit.CenterPosition).Length;
   var margin = InfantryPinned(unit) ? 0 : 1024;
   var validArms = unit.TraitsImplementing<Armament>().Where(a => !a.IsTraitDisabled && !a.IsTraitPaused
    && a.Weapon.IsValidTarget(target.GetEnabledTargetTypes()) && distance >= a.Weapon.MinRange.Length && distance <= a.MaxRange().Length + margin).ToArray();
   if (validArms.Length == 0) return 0;
   var inRange = validArms.Any(a => distance <= a.MaxRange().Length);
   if (!inRange) {
    var mobile = unit.TraitOrDefault<Mobile>();
    if (mobile == null) return 0;
    // Require a reachable firing cell at most one cell away; do not accept long detours.
    var firingCell = World.Map.FindTilesInCircle(unit.Location, 1).Any(c =>
     (World.Map.CenterOfCell(c) - target.CenterPosition).Length <= validArms.Max(a => a.MaxRange().Length)
     && mobile.Info.CanEnterCell(World, unit, c) && Player.Shroud.IsExplored(c));
    if (!firingCell) return 0;
   }
   if (inRange) validArms = validArms.Where(a => distance <= a.MaxRange().Length).ToArray();
   else {
    var mobile = unit.Trait<Mobile>();
    validArms = World.Map.FindTilesInCircle(unit.Location,1)
     .Where(c=>mobile.Info.CanEnterCell(World,unit,c)&&Player.Shroud.IsExplored(c)
      &&World.WorldActor.Trait<IPathFinder>().PathExistsForLocomotor(mobile.Locomotor,unit.Location,c))
     .Select(c=>validArms.Where(a=>{
      var d=(World.Map.CenterOfCell(c)-target.CenterPosition).Length;
      return d>=a.Weapon.MinRange.Length&&d<=a.MaxRange().Length;
     }).ToArray()).OrderByDescending(a=>AttackOrFleeFuzzy.EffectiveDamage(unit,new[]{target},a)).FirstOrDefault();
    if(validArms==null||validArms.Length==0)return 0;
   }
   var damage = AttackOrFleeFuzzy.EffectiveDamage(unit, new[] { target }, validArms);
   var hp = target.TraitOrDefault<Health>();
   var finish = hp == null ? 1 : 1 + Math.Min(1, damage * 25 / Math.Max(1, hp.HP)) * Math.Min(1, target.GetSellValue() / 1500.0);
   var retaliation = World.FindActorsInCircle(unit.CenterPosition,WDist.FromCells(10))
    .Where(e=>!e.IsDead&&e.IsInWorld&&e.Owner.RelationshipWith(Player)==PlayerRelationship.Enemy&&e.CanBeViewedByPlayer(Player))
    .Sum(e=>AttackOrFleeFuzzy.EffectiveDamage(e,new[]{unit},e.TraitsImplementing<Armament>().Where(a=>{
     var d=(e.CenterPosition-unit.CenterPosition).Length;
     return d>=a.Weapon.MinRange.Length&&d<=a.MaxRange().Length+(inRange?0:1024);
    })));
   var danger = retaliation * 25 / Math.Max(1, unit.TraitOrDefault<Health>()?.HP ?? 1);
   double splash = 0;
   foreach(var arm in validArms)
    foreach(var wh in arm.Weapon.Warheads.OfType<SpreadDamageWarhead>()) {
     var ranges = wh.Range ?? wh.Falloff.Select((v,i)=>new WDist(i*wh.Spread.Length)).ToArray();
     foreach(var other in World.FindActorsInCircle(target.CenterPosition,new WDist(ranges.Max(r=>r.Length)))
      .Where(a=>a!=target&&!a.IsDead&&a.CanBeViewedByPlayer(Player)&&wh.IsValidAgainst(a,unit))) {
      var d=(other.CenterPosition-target.CenterPosition).Length;
      var index=Array.FindIndex(ranges,r=>r.Length>=d);
      if(index>=0) splash += wh.Falloff[Math.Min(index,wh.Falloff.Length-1)]/100.0
       *(other.Owner.RelationshipWith(Player)==PlayerRelationship.Enemy?0.5:-1);
     }
    }
   return damage * (inRange ? 1.3 : 0.8) * finish * Math.Max(0.1,1+Math.Min(2,splash))
    / (1.0 + distance / 10240.0 + Math.Min(4,danger)*(inRange?0.25:1));
  }
 }
}


