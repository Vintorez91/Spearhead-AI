param([Parameter(Mandatory=$true)][string]$EngineDir)
$ErrorActionPreference='Stop'
$engine=(Resolve-Path -LiteralPath $EngineDir).Path
dotnet build "$PSScriptRoot/Spearhead.csproj" -c Release "-p:OpenRAEngineDir=$engine"
if($LASTEXITCODE -ne 0){throw 'Build failed'}
Copy-Item "$PSScriptRoot/bin/Release/net6.0/OpenRA.AITest.dll" "$PSScriptRoot/mods/spearhead-ai/OpenRA.AITest.dll" -Force
