# Packaging validation

11 October 2026: source compilation passed with zero warnings and zero errors against release-20250330. OpenRA.Utility spearhead-ai --check-yaml completed successfully (exit 0), including shipped RA maps. It reported translation metadata warnings and unused inherited translation keys.

The public mod excludes test-world rules and uses LogoStripeLoadScreen; no fast-start buildings or test scenarios are attached to World. The DLL is the same compiled candidate used in full-game wins.

Public-menu play-through and installation on a clean second PC remain unverified. The package is an experimental preview, not a final cross-platform release.

