using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class AITestMetrics {
  Locomotor fixtureFoot; Player raidFixturePlayer; bool raidFixtureStarted; Actor fixtureApc; Actor[] fixtureEngineers,fixtureTargets,fixtureFence; int accessTest;
  void SetupOpportunityFixture(World world){world.AddFrameEndTask(w=>{
   var p=w.Players.First(a=>a.IsBot&&a.BotType=="improved");raidFixturePlayer=p;
   var enemy=w.Players.First(a=>a.InternalName=="Creeps");
   var info=w.Map.Rules.Actors["apc"].TraitInfo<MobileInfo>();var loco=w.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==info.Locomotor);
   var footInfo=w.Map.Rules.Actors["e6"].TraitInfo<MobileInfo>();var foot=w.WorldActor.TraitsImplementing<Locomotor>().First(l=>l.Info.Name==footInfo.Locomotor);
   fixtureFoot=foot;p.Shroud.ExploreAll();
   var clear=w.Map.FindTilesInAnnulus(p.HomeLocation,16,26).First(c=>w.Map.FindTilesInCircle(c,7).All(t=>w.Map.Contains(t)&&foot.MovementCostForCell(t)<short.MaxValue&&!w.Actors.Any(a=>a.OccupiesSpace!=null&&a.OccupiesSpace.OccupiedCells().Any(x=>x.Item1==t))));
   var targets=new List<Actor>();
   targets.Add(w.CreateActor("weap",new TypeDictionary {new OwnerInit(enemy),new LocationInit(clear),new SkipMakeAnimsInit()}));
   targets.Add(w.CreateActor("powr",new TypeDictionary {new OwnerInit(enemy),new LocationInit(clear+new CVec(4,0)),new SkipMakeAnimsInit()}));
   w.CreateActor("miss",new TypeDictionary {new OwnerInit(p),new LocationInit(clear+new CVec(1,7)),new SkipMakeAnimsInit()});
   var launch=w.Map.FindTilesInAnnulus(p.HomeLocation,6,10).First(c=>loco.MovementCostForCell(c)<short.MaxValue&&!w.Actors.Any(a=>a.OccupiesSpace!=null&&a.Location==c));
   var budget=w.Players.First(a=>a.IsBot&&a.BotType=="improved").PlayerActor.Trait<PlayerResources>();var cashBefore=budget.Cash;
   budget.TakeCash(Math.Max(0,budget.Cash-500),true);
   var expansionMcv=w.CreateActor("mcv",new TypeDictionary{new OwnerInit(p),new LocationInit(launch+new CVec(-1,0))});
   if(!p.PlayerActor.Trait<ImprovedMcvManagerBotModule>().SavingForExpansion())throw new InvalidOperationException("Refinery reserve was not retained while MCV is in transit");
   Console.WriteLine("AI-BUDGET TEST retained refinery reserve during MCV transit passed");
   expansionMcv.Dispose();budget.GiveCash(cashBefore-budget.Cash);
   var apc=w.CreateActor("apc",new TypeDictionary {new OwnerInit(p),new LocationInit(launch)});
   var engineers=new[]{w.CreateActor("e6",new TypeDictionary {new OwnerInit(p),new LocationInit(launch+new CVec(0,1))}),w.CreateActor("e6",new TypeDictionary {new OwnerInit(p),new LocationInit(launch+new CVec(1,1))})};
   var path=FairNavigation.Route(w,p,loco,launch,clear,4,new CPos[0],false);if(path.Count==0)throw new InvalidOperationException("Fixture has no APC route");
   fixtureApc=apc;fixtureEngineers=engineers;fixtureTargets=targets.ToArray();
   Console.WriteLine("AI-OPPORTUNITY TEST APC fixture route="+path.Count+" target="+clear);
  });}
  void CheckOpportunityFixture(World world){
   if(raidFixturePlayer==null)return;
   if(!raidFixtureStarted&&world.WorldTick>=25){
    var path=FairNavigation.Route(world,raidFixturePlayer,fixtureApc.Trait<Mobile>().Locomotor,fixtureApc.Location,fixtureTargets[0].Location,4,new CPos[0]);
    if(path.Count==0)throw new InvalidOperationException("Fixture explored route unavailable");
    raidFixturePlayer.PlayerActor.Trait<ImprovedSquadManagerBotModule>().StartRaidFixture(fixtureApc,fixtureEngineers,fixtureTargets,path);raidFixtureStarted=true;
   }
   if(!raidFixtureStarted)return;
   var foot=fixtureFoot;
   if(accessTest==0&&world.WorldTick>=30){
    var occupied=new HashSet<CPos>(fixtureTargets[1].OccupiesSpace.OccupiedCells().Select(c=>c.Item1));
    var steps=new[]{new CVec(1,0),new CVec(-1,0),new CVec(0,1),new CVec(0,-1)};
    var boundary=occupied.SelectMany(c=>steps.Select(step=>c+step)).Where(c=>!occupied.Contains(c)).Distinct().ToArray();
    world.AddFrameEndTask(w=>{fixtureFence=boundary.Select(c=>w.CreateActor("barb",new TypeDictionary{new OwnerInit(w.Players.First(p=>p.InternalName=="Neutral")),new LocationInit(c)})).ToArray();});accessTest=1;
   }
   if(accessTest==1&&world.WorldTick>=50){
    if(FairNavigation.CaptureAccess(world,raidFixturePlayer,foot,fixtureApc.Location,fixtureTargets[1].Location,new CPos[0]))throw new InvalidOperationException("Fenced building falsely marked reachable: visible fences="+fixtureFence.Count(a=>a.IsInWorld&&a.CanBeViewedByPlayer(raidFixturePlayer))+" total="+fixtureFence.Length);
    Console.WriteLine("AI-ACCESS TEST closed fence rejected passed");world.AddFrameEndTask(w=>{foreach(var fence in fixtureFence)fence.Dispose();});accessTest=2;
   }
   if(accessTest==2&&world.WorldTick>=75){
    if(!FairNavigation.CaptureAccess(world,raidFixturePlayer,foot,fixtureApc.Location,fixtureTargets[1].Location,new CPos[0]))throw new InvalidOperationException("Open building falsely marked unreachable");
    var capture=raidFixturePlayer.PlayerActor.Trait<ImprovedNeutralCaptureBotModule>();
    var freeOrigin=capture.CaptureOrigin(foot,true);
    if(!FairNavigation.CaptureAccess(world,raidFixturePlayer,foot,freeOrigin,fixtureTargets[1].Location,new CPos[0]))throw new InvalidOperationException("Capture origin cannot reach open target");
    Console.WriteLine("AI-ACCESS TEST home inside yard uses reachable capture origin passed origin="+freeOrigin);
    Console.WriteLine("AI-ACCESS TEST cleared fence reachable passed");accessTest=3;
   }
   var manager=raidFixturePlayer.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
   if(manager.RaidCaptured>=2){Console.WriteLine("AI-OPPORTUNITY TEST loaded, transported, unloaded, captured two buildings passed");TelemetrySnapshot(world);FlushTelemetry();WriteDecisionSummary(world);Game.Exit();}
   if(world.WorldTick>=SmokeExitTicks)throw new InvalidOperationException("APC fixture failed: captures="+manager.RaidCaptured);
  }
 }
}








