using System;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Primitives;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class AITestMetrics {
  Actor targetRocket, targetRifle, targetInfantry, targetTank, fixtureArtillery, fixtureBuilding; double splashBefore;
  void SetupTargetingFixture(World world) {
   world.AddFrameEndTask(w => {
    var own=w.Players.First(p=>p.IsBot&&p.BotType=="improved");
    var enemy=w.Players.First(p=>p.Playable&&own.RelationshipWith(p)==PlayerRelationship.Enemy);
    var offsets=new[] {new CVec(0,0),new CVec(0,1),new CVec(2,0),new CVec(2,1)};
    var mobile=w.Map.Rules.Actors["e1"].TraitInfo<MobileInfo>();
    var cell=w.Map.FindTilesInAnnulus(own.HomeLocation,5,9).First(c=>offsets.All(o=>w.Map.Contains(c+o)&&mobile.CanEnterCell(w,null,c+o)&&!w.Actors.Any(a=>a.OccupiesSpace!=null&&a.Location==c+o)));
    targetRocket=w.CreateActor("e3",new TypeDictionary{new OwnerInit(own),new LocationInit(cell)});
    targetRifle=w.CreateActor("e1",new TypeDictionary{new OwnerInit(own),new LocationInit(cell+offsets[1])});
    targetInfantry=w.CreateActor("e1",new TypeDictionary{new OwnerInit(enemy),new LocationInit(cell+offsets[2])});
    targetTank=w.CreateActor("3tnk",new TypeDictionary{new OwnerInit(enemy),new LocationInit(cell+offsets[3])});
   });
  }
  void CheckTargetingFixture(World world) {
   if(world.WorldTick==21&&targetRifle!=null) {
    var fixtureManager=targetRifle.Owner.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
    var trigger=new OpenRA.Primitives.BitSet<DamageType>("TriggerProne");
    targetRifle.InflictDamage(targetInfantry,new Damage(1,trigger));
    if(!fixtureManager.InfantryPinned(targetRifle))throw new InvalidOperationException("Infantry did not enter prone state");
    var range=targetRifle.TraitsImplementing<Armament>().Max(a=>a.MaxRange().Length);
    var cells=world.Map.FindTilesInAnnulus(targetRifle.Location,1,7);
    var cell=cells.First(c=> {
     var distance=(world.Map.CenterOfCell(c)-targetRifle.CenterPosition).Length;
     return distance>range&&distance<=range+1024&&world.Map.Rules.Actors["e1"].TraitInfo<MobileInfo>().CanEnterCell(world,null,c);
    });
    var outside=world.CreateActor("e1",new TypeDictionary{new OwnerInit(targetInfantry.Owner),new LocationInit(cell)});
    if(fixtureManager.LocalTargetScore(targetRifle,outside)!=0)throw new InvalidOperationException("Prone infantry counted out of range target");
    var before=fixtureManager.LocalTargetScore(targetRocket,targetTank);
    targetTank.InflictDamage(targetRocket,new Damage(targetTank.Trait<Health>().HP-100));
    var after=fixtureManager.LocalTargetScore(targetRocket,targetTank);
    if(after<=before)throw new InvalidOperationException("Wounded valuable target did not gain priority");
    Console.WriteLine("AI-TARGET TEST passed prone infantry excludes extra cell; wounded tank receives effective finishing bonus");
    world.AddFrameEndTask(w=> {
     var yard=w.Actors.First(a=>a.Owner==targetRifle.Owner&&a.Info.Name=="fact");
     var engCell=w.Map.FindTilesInAnnulus(yard.Location,2,4).First(c=>w.Map.Rules.Actors["e6"].TraitInfo<MobileInfo>().CanEnterCell(w,null,c));
     var engineer=w.CreateActor("e6",new TypeDictionary{new OwnerInit(targetInfantry.Owner),new LocationInit(engCell)});
     if(!fixtureManager.EngineerThreat(engineer))throw new InvalidOperationException("Nearby capture engineer not identified");
     if(fixtureManager.EngineerThreat(targetInfantry))throw new InvalidOperationException("Rifle mistaken for capture engineer");
     Console.WriteLine("AI-TARGET TEST passed enemy engineer near construction yard is urgent; ordinary infantry is not");
    });
   }
   if(world.WorldTick==22&&targetRocket!=null)world.AddFrameEndTask(w=>{
    var own=targetRocket.Owner;var enemy=targetInfantry.Owner;
    var mgr=own.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
    var cell=w.Map.FindTilesInAnnulus(targetInfantry.Location,5,6).First(c=>w.Map.Rules.Actors["arty"].TraitInfo<MobileInfo>().CanEnterCell(w,null,c));
    var arty=w.CreateActor("arty",new TypeDictionary{new OwnerInit(own),new LocationInit(cell)});
    fixtureArtillery=arty; var score=mgr.LocalTargetScore(arty,targetInfantry); splashBefore=score;
    if(score<=0)throw new InvalidOperationException("Artillery valid ranged infantry score zero");
    w.CreateActor("e1",new TypeDictionary{new OwnerInit(enemy),new LocationInit(targetInfantry.Location)});
    w.CreateActor("e1",new TypeDictionary{new OwnerInit(enemy),new LocationInit(targetInfantry.Location)});
    fixtureBuilding=w.CreateActor("powr",new TypeDictionary{new OwnerInit(enemy),new LocationInit(targetInfantry.Location)});
    
    var empty=OpenRA.Mods.Common.Traits.AITest.Squads.AttackOrFleeFuzzy.EffectiveDamage(arty,new[]{targetInfantry},Array.Empty<Armament>());
    if(empty!=0)throw new InvalidOperationException("Ineligible weapons counted");
    
   });
   if(world.WorldTick==23&&fixtureArtillery!=null) {
    var mgr=targetRocket.Owner.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
    var clustered=mgr.LocalTargetScore(fixtureArtillery,targetInfantry);
    if(clustered<=splashBefore)throw new InvalidOperationException("Infantry cluster did not improve splash score: "+splashBefore+" -> "+clustered);
    if(mgr.LocalTargetScore(fixtureArtillery,fixtureBuilding)<=0)throw new InvalidOperationException("Building excluded from local score");
    Console.WriteLine("AI-TARGET TEST passed splash prefers infantry cluster; vulnerable buildings eligible; excluded weapons contribute zero");
   }
   if(world.WorldTick!=20||targetRocket==null)return;
   var manager=targetRocket.Owner.PlayerActor.Trait<ImprovedSquadManagerBotModule>();
   var rocket=manager.ChooseEffectiveLocalTarget(targetRocket,targetInfantry);
   var rifle=manager.ChooseEffectiveLocalTarget(targetRifle,targetTank);
   if(rocket!=targetTank||rifle!=targetInfantry)throw new InvalidOperationException("Targeting fixture failed rocket="+rocket.Info.Name+" rifle="+rifle.Info.Name);
   Console.WriteLine("AI-TARGET TEST passed rocket prefers tank; rifle prefers infantry; both directly visible and in range");
  }
 }
}




