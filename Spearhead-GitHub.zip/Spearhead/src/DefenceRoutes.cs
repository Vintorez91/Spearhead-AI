using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedBaseBuilderBotModule
 {
  sealed class DefenceChoke { public CPos Cell; public int Width; public int Routes; }
  sealed class DefenceRouteCache { public int Tick; public string Goals; public int Explored; public List<DefenceChoke> Chokes; }
  readonly Dictionary<CPos,DefenceRouteCache> defenceRouteCache=new Dictionary<CPos,DefenceRouteCache>();
  readonly HashSet<CPos> defenceKnownOre=new HashSet<CPos>();
  int nextDefenceTerrainScan;
  int defenceExploredCount;
  static readonly CVec[] routeSteps={new CVec(1,0),new CVec(-1,0),new CVec(0,1),new CVec(0,-1)};
  List<DefenceChoke> GetDefenceChokes(Actor anchor) {
   var foot=world.WorldActor.TraitsImplementing<Locomotor>().FirstOrDefault(l=>l.Info.Name=="foot");
   if(foot==null)return new List<DefenceChoke>();
   if(world.WorldTick>=nextDefenceTerrainScan) {
    nextDefenceTerrainScan=world.WorldTick+750;
    var ore=new HashSet<byte>(world.Map.Rules.Actors["world"].TraitInfo<ResourceLayerInfo>().ResourceTypes.Values.Select(t=>world.Map.Rules.TerrainInfo.GetTerrainIndex(t.TerrainType)));
    defenceExploredCount=0;
    foreach(var c in world.Map.AllCells) {
     if(player.Shroud.IsExplored(c))defenceExploredCount++;
     if(!player.Shroud.IsVisible(c))continue;
     if(ore.Contains(world.Map.GetTerrainIndex(c)))defenceKnownOre.Add(c);else defenceKnownOre.Remove(c);
    }
   }
   var strategy=player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>();
   var goals=(strategy==null?Enumerable.Empty<CPos>():strategy.KnownEnemies.Where(e=>e.Building||e.Armed).OrderBy(e=>(e.Position-anchor.Location).LengthSquared).Select(e=>e.Position).Take(3))
    .Concat(world.Actors.Where(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead&&(a.Info.Name=="fact"||a.Info.Name=="proc")).Select(a=>a.Location))
    .Concat(defenceKnownOre.OrderBy(c=>(c-anchor.Location).LengthSquared));
   var selected=new List<CPos>();
   foreach(var c in goals) {
    if((c-anchor.Location).LengthSquared<144||selected.Any(g=>(g-c).LengthSquared<64)||!player.Shroud.IsExplored(c))continue;
    selected.Add(c);if(selected.Count==6)break;
   }
   var key=string.Join(";",selected.Select(c=>c.ToString()));DefenceRouteCache cache;
   if(defenceRouteCache.TryGetValue(anchor.Location,out cache)&&world.WorldTick<cache.Tick)return cache.Chokes;
   var found=new Dictionary<CPos,DefenceChoke>();
   Func<CPos,bool> pass=c=>world.Map.Contains(c)&&player.Shroud.IsExplored(c)&&foot.MovementCostForCell(c)<short.MaxValue;
   var parent=new Dictionary<CPos,CPos>();var queue=new Queue<CPos>();
   parent[anchor.Location]=anchor.Location;queue.Enqueue(anchor.Location);
   while(queue.Count>0&&parent.Count<8192) {
    var c=queue.Dequeue();foreach(var step in routeSteps) {
     var n=c+step;if(parent.ContainsKey(n)||(n-anchor.Location).LengthSquared>3600||!pass(n))continue;
     parent[n]=c;queue.Enqueue(n);
    }
   }
   foreach(var goal in selected) {
    if(!parent.ContainsKey(goal))continue;
    var path=new List<CPos>();var cursor=goal;
    while(cursor!=anchor.Location){path.Add(cursor);cursor=parent[cursor];}path.Add(anchor.Location);path.Reverse();
    for(int i=2;i<path.Count-2;i++) {
     var c=path[i];var distance=(c-anchor.Location).LengthSquared;if(distance<25||distance>576)continue;
     var direction=path[i+1]-path[i-1];
     if(direction.X!=0&&direction.Y!=0)continue; // Corners do not establish a corridor.
     var across=direction.X!=0?new CVec(0,1):new CVec(1,0);
     int width=1;bool unknown=false;
     foreach(var sign in new[]{-1,1})for(int offset=1;offset<=5;offset++) {
      var n=c+new CVec(across.X*sign*offset,across.Y*sign*offset);
      if(world.Map.Contains(n)&&!player.Shroud.IsExplored(n)){unknown=true;break;}
      if(!pass(n))break;width++;
     }
     if(unknown||width>4)continue;
     // A corridor must continue in both directions; avoid tiny pockets.
     if(!pass(path[i-2])||!pass(path[i+2]))continue;
     DefenceChoke choke;if(!found.TryGetValue(c,out choke))found[c]=choke=new DefenceChoke{Cell=c,Width=width};choke.Routes++;
    }
   }
   var result=found.Values.OrderByDescending(c=>c.Routes*10-c.Width).Take(24).ToList();
   defenceRouteCache[anchor.Location]=new DefenceRouteCache{Tick=world.WorldTick+750,Goals=key,Explored=defenceExploredCount,Chokes=result};
   foreach(var stale in defenceRouteCache.Keys.Where(c=>!world.Actors.Any(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead&&(a.Info.Name=="fact"||a.Info.Name=="proc")&&a.OccupiesSpace!=null&&a.Location==c)).ToArray())defenceRouteCache.Remove(stale);
   Console.WriteLine("AI-CHOKE anchor="+anchor.Location+" goals="+selected.Count+" visited="+parent.Count+" candidates="+result.Count+" cells="+string.Join(";",result.Take(4).Select(c=>c.Cell+"/width="+c.Width+"/routes="+c.Routes)));
   return result;
  }
 }
}


