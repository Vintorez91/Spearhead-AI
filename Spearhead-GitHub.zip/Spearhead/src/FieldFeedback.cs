using System;
using System.Linq;
using System.Collections.Generic;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest {
 public partial class ImprovedSquadManagerBotModule {
  sealed class AttackGoalMemory {public CPos Cell;public int Seen,Expires;public bool Building;}
  readonly Dictionary<Squad,AttackGoalMemory> attackGoals=new Dictionary<Squad,AttackGoalMemory>();
  readonly Dictionary<Squad,int> attackAdvanceAt=new Dictionary<Squad,int>();
  internal void RememberAttackGoal(Squad squad){
   if(!squad.IsTargetValid)return;
   var a=squad.TargetActor;var building=a.Info.HasTraitInfo<BuildingInfo>();
   AttackGoalMemory previous;
   if(attackGoals.TryGetValue(squad,out previous)&&breakthroughOriginal.ContainsKey(squad))return;
   attackGoals[squad]=new AttackGoalMemory{Cell=a.Location,Seen=World.WorldTick,Expires=World.WorldTick+(building?750:375),Building=building};
  }
  internal bool AdvanceAttackLocation(Squad squad,CPos goal,int radius){
   int last;if(attackAdvanceAt.TryGetValue(squad,out last)&&World.WorldTick-last<100)return true;
   var leader=squad.Units.Where(a=>!a.IsDead&&a.IsInWorld&&a.TraitOrDefault<Mobile>()!=null).OrderBy(a=>(a.Location-goal).LengthSquared).FirstOrDefault();
   if(leader==null)return false;
   var dangers=Strategy.KnownEnemies.Where(o=>o.Armed&&o.Building).Select(o=>o.Position).ToArray();
   var path=FairNavigation.Route(World,Player,leader.Trait<Mobile>().Locomotor,leader.Location,goal,radius,dangers);
   if(path.Count==0&&(leader.Location-goal).LengthSquared<=radius*radius&&dangers.All(d=>(d-leader.Location).LengthSquared>100))path.Add(leader.Location);
   if(path.Count==0){LogAttackWait(squad,"staging_route_blocked",0);return false;}
   var waypoint=path[Math.Min(11,path.Count-1)];
   squad.Bot.QueueOrder(new Order("AttackMove",null,Target.FromCell(World,waypoint),false,groupedActors:squad.Units.Where(a=>!a.IsDead&&a.IsInWorld&&!IsRecoveringVeteran(a)).ToArray()));
   attackAdvanceAt[squad]=World.WorldTick;
   TraceAttack(squad,"staging_advance","waypoint="+waypoint+";radius="+radius,goal,"known_location");
   Console.WriteLine("AI-ADVANCE tick="+World.WorldTick+" goal="+goal+" waypoint="+waypoint+" units="+squad.Units.Count);return true;
  }
  internal bool ContinueRememberedAttack(Squad squad){
   if(squad.Type!=SquadType.Assault||Strategy.HoldingOffense||OffenseRegrouping)return false;
   AttackGoalMemory goal;if(!attackGoals.TryGetValue(squad,out goal))return false;
   if(World.WorldTick>=goal.Expires||Player.Shroud.IsVisible(goal.Cell)){attackGoals.Remove(squad);return false;}
   return AdvanceAttackLocation(squad,goal.Cell,3);
  }
 }
 public partial class ImprovedBaseBuilderBotModule {
  internal IEnumerable<Actor> PreferredTechBases(){
   var strategy=player.PlayerActor.TraitOrDefault<ImprovedStrategyBotModule>();if(strategy!=null)strategy.Refresh();
   var threats=strategy==null?new ImprovedStrategyBotModule.Observation[0]:strategy.KnownEnemies.Where(e=>e.Armed&&world.WorldTick-e.Seen<=(e.Building?7500:1500)).ToArray();
   return world.Actors.Where(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead&&Info.ConstructionYardTypes.Contains(a.Info.Name))
    .OrderBy(a=>threats.Any(e=>(e.Position-a.Location).LengthSquared<225)?1:0)
    .ThenBy(a=>threats.Where(e=>(e.Position-a.Location).LengthSquared<625).Sum(e=>e.Value/(double)Math.Max(1,(e.Position-a.Location).LengthSquared)))
    .ThenBy(a=>(a.Location-player.HomeLocation).LengthSquared);
  }
 }
 public class ImprovedPriorityRepairBotModuleInfo:ConditionalTraitInfo {public override object Create(ActorInitializer init){return new ImprovedPriorityRepairBotModule(init.Self,this);}}
 public class ImprovedPriorityRepairBotModule:ConditionalTrait<ImprovedPriorityRepairBotModuleInfo>,IBotTick {
  readonly World world;readonly Player player;int nextTick;
  internal static bool Critical(Actor a){return new[]{"fact","atek","stek","dome","weap","proc","powr","apwr"}.Contains(a.Info.Name);}
  public ImprovedPriorityRepairBotModule(Actor self,ImprovedPriorityRepairBotModuleInfo info):base(info){world=self.World;player=self.Owner;}
  internal void ResetRepairProbe(){nextTick=0;}
  internal Actor[] Priorities(){
   var threats=world.Actors.Where(a=>a.IsInWorld&&!a.IsDead&&a.CanBeViewedByPlayer(player)&&a.Info.HasTraitInfo<AttackBaseInfo>()&&player.RelationshipWith(a.Owner)==PlayerRelationship.Enemy).ToArray();
   return world.Actors.Where(a=>a.Owner==player&&a.IsInWorld&&!a.IsDead&&a.TraitOrDefault<RepairableBuilding>()!=null&&!a.Trait<RepairableBuilding>().IsTraitDisabled&&a.TraitOrDefault<IHealth>()!=null&&a.Trait<IHealth>().HP<a.Trait<IHealth>().MaxHP)
    .OrderByDescending(a=>Critical(a)&&(a.Trait<IHealth>().HP<=a.Trait<IHealth>().MaxHP*0.3||threats.Any(e=>(e.Location-a.Location).LengthSquared<=144)))
    .ThenByDescending(Critical).ThenBy(a=>a.Trait<IHealth>().HP/(double)a.Trait<IHealth>().MaxHP).ToArray();
  }
  void IBotTick.BotTick(IBot bot){
   if(world.WorldTick<nextTick)return;nextTick=world.WorldTick+125;
   var money=player.PlayerActor.Trait<PlayerResources>();var scarce=money.Cash+money.Resources<1200;
   var damaged=Priorities();var chosen=damaged.Take(scarce?1:damaged.Length).ToHashSet();
   foreach(var a in damaged){var rb=a.Trait<RepairableBuilding>();var h=a.Trait<IHealth>();
    var wanted=chosen.Contains(a)&&(Critical(a)||h.HP<h.MaxHP*0.8);
    var enabled=rb.Repairers.Contains(player);
    if(enabled!=wanted){bot.QueueOrder(new Order("RepairBuilding",player.PlayerActor,Target.FromActor(a),false));Console.WriteLine("AI-REPAIR tick="+world.WorldTick+" unit="+a.ActorID+" type="+a.Info.Name+" enabled="+wanted+" scarce="+scarce);}
   }
  }
 }
}