using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using OpenRA.Traits;
using OpenRA.Primitives;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
 // Delegate to the original nonvirtual implementations; observe their actual credit changes.
 public class AITestLoggedCashTricklerInfo : CashTricklerInfo
 { public override object Create(ActorInitializer init) { return new AITestLoggedCashTrickler(this); } }
 public class AITestLoggedCashTrickler : CashTrickler, ITick
 {
  readonly Action<Actor> original;
  public AITestLoggedCashTrickler(CashTricklerInfo info) : base(info) {
   original=(Action<Actor>)Delegate.CreateDelegate(typeof(Action<Actor>),this,typeof(CashTrickler).GetMethod("OpenRA.Traits.ITick.Tick",BindingFlags.NonPublic|BindingFlags.Instance));
  }
  void ITick.Tick(Actor self) {
   var r=self.Owner.PlayerActor.TraitOrDefault<PlayerResources>(); var before=r==null?0:r.Earned;
   original(self);
   var log=self.World.WorldActor.TraitOrDefault<AITestMetrics>();
   if(log!=null&&r!=null&&r.Earned!=before) log.TelemetryIncome(self,self.Owner,r.Earned-before,"oil_tick",null);
  }
 }
 public class AITestLoggedCaptureCashInfo : GivesCashOnCaptureInfo
 { public override object Create(ActorInitializer init) { return new AITestLoggedCaptureCash(this); } }
 public class AITestLoggedCaptureCash : GivesCashOnCapture, INotifyCapture
 {
  readonly Action<Actor,Actor,Player,Player,BitSet<CaptureType>> original;
  public AITestLoggedCaptureCash(GivesCashOnCaptureInfo info) : base(info) {
   original=(Action<Actor,Actor,Player,Player,BitSet<CaptureType>>)Delegate.CreateDelegate(typeof(Action<Actor,Actor,Player,Player,BitSet<CaptureType>>),this,typeof(GivesCashOnCapture).GetMethod("OpenRA.Mods.Common.Traits.INotifyCapture.OnCapture",BindingFlags.NonPublic|BindingFlags.Instance));
  }
  void INotifyCapture.OnCapture(Actor self,Actor captor,Player oldOwner,Player newOwner,BitSet<CaptureType> types) {
   var r=newOwner.PlayerActor.TraitOrDefault<PlayerResources>(); var before=r==null?0:r.Earned;
   original(self,captor,oldOwner,newOwner,types);
   var log=self.World.WorldActor.TraitOrDefault<AITestMetrics>();
   if(log!=null&&r!=null&&r.Earned!=before) log.TelemetryIncome(self,newOwner,r.Earned-before,"capture_bonus",captor);
  }
 }
 public partial class ImprovedSquadManagerBotModule
 { internal Squad[] TelemetrySquads() { return Squads.Where(s=>s.IsValid).ToArray(); } }
 public partial class AITestMetrics
 {
  sealed class Op {
   public int Id,Start,Contact=-1,Arrival=-1,InitialValue,Lost,Killed,EconomicKills;
   public Player Player; public Squad Squad; public string Role; public Actor Target;
   public readonly HashSet<uint> Members=new HashSet<uint>(); public bool Ended;
  }
  sealed class EngineerRecord {
   public Actor Actor; public Player Owner; public int Start,Cost,Captures; public long Income; public string Status="active";
   public readonly HashSet<uint> Buildings=new HashSet<uint>();
  }
  sealed class SiteRecord {
   public uint Id; public Player Owner; public CPos Cell; public Actor Anchor;
   public int Start,LostAt=-1,Recoveries,RecoveryDelay=-1,Invested,DestroyedValue,AcceptedIncome,YardLostAt=-1,YardRecoveryDelay=-1,YardRecoveries; public bool HadYard,YardMissing;
   public readonly HashSet<uint> Buildings=new HashSet<uint>(); public bool Home;
  }
  sealed class SupportRecord {
   public int Id,Start,Arrival=-1,OpId; public Player Player; public Actor Threat,Asset;
   public int HpBefore; public bool Ended; public string EndReason;
  }
  sealed class CombatRecord { public int Lost,Killed,ArmyLost,ArmyKilled,BuildingLost,BuildingKilled,HarvesterLost,HarvesterKilled; }
  readonly Dictionary<Player,CombatRecord> combatRecords=new Dictionary<Player,CombatRecord>();
  sealed class YardLoss { public SiteRecord Site; public int Tick,McvTick=-1; }
  readonly Dictionary<Player,List<YardLoss>> yardLosses=new Dictionary<Player,List<YardLoss>>();
  readonly List<string> recoverySummaries=new List<string>();
  StreamWriter combatLog,recoveryLog;
  StreamWriter operationsLog, engineersLog, sitesLog, supportLog, incomeLog; string decisionPrefix;
  readonly Dictionary<Squad,Op> operations=new Dictionary<Squad,Op>();
  readonly Dictionary<uint,Op> unitOperations=new Dictionary<uint,Op>();
  readonly Dictionary<uint,EngineerRecord> engineerRecords=new Dictionary<uint,EngineerRecord>();
  readonly Dictionary<uint,SiteRecord> siteRecords=new Dictionary<uint,SiteRecord>();
  readonly Dictionary<Player,SupportRecord> supportRecords=new Dictionary<Player,SupportRecord>();
  readonly List<SupportRecord> supportHistory=new List<SupportRecord>();
  readonly Dictionary<string,long> sourceIncome=new Dictionary<string,long>();
  readonly Dictionary<uint,uint> incomeBeneficiaries=new Dictionary<uint,uint>();
  readonly HashSet<uint> fatalActors=new HashSet<uint>();
  int operationSerial,supportSerial;
  void InitializeDecisions(string prefix) {
   decisionPrefix=prefix;InitializeVeteranTelemetry(prefix);InitializeAttackDecisionTelemetry(prefix);InitializeLocalAttackTelemetry(prefix);
   combatLog=new StreamWriter(prefix+"-combat.csv");
   recoveryLog=new StreamWriter(prefix+"-recovery.csv");
   recoveryLog.WriteLine("tick,player,event,lost_site_id,lost_x,lost_y,loss_tick,replacement_site_id,replacement_x,replacement_y,delay_ticks,mcv_id,mcv_x,mcv_y");
   combatLog.WriteLine("tick,player,ai,loss_value,kill_value,army_loss_value,army_kill_value,building_loss_value,building_kill_value,harvester_loss_value,harvester_kill_value,exchange_ratio");
   operationsLog=new StreamWriter(prefix+"-operations.csv");
   engineersLog=new StreamWriter(prefix+"-engineers.csv");
   sitesLog=new StreamWriter(prefix+"-expansions.csv");
   supportLog=new StreamWriter(prefix+"-support.csv");
   incomeLog=new StreamWriter(prefix+"-income.csv");
   operationsLog.WriteLine("tick,operation_id,player,role,status,start_tick,first_contact_tick,arrival_tick,target_id,target_type,target_x,target_y,units,initial_value,current_value,hp_weighted_value,visible_enemy_value_12_cells,friendly_value_12_cells,loss_value,kill_value,economic_kills,exchange_ratio,player_earned,player_spent,unit_composition,visible_enemy_composition");
   engineersLog.WriteLine("tick,engineer_id,player,start_tick,status,cost,captures,captured_ids,actual_income_from_captured_assets,income_minus_engineer_cost");
   sitesLog.WriteLine("tick,site_id,player,x,y,home,status,start_tick,last_loss_tick,recoveries,last_recovery_delay,buildings,defence_value,invested_building_value,destroyed_building_value,accepted_refinery_income,income_minus_building_value,construction_yard_present,yard_loss_tick,yard_recoveries,last_yard_recovery_delay");
   supportLog.WriteLine("tick,support_id,player,status,request_tick,arrival_tick,arrival_delay,operation_id,threat_id,asset_id,asset_x,asset_y,asset_hp_at_request,asset_hp_now,asset_lost,end_reason");
   incomeLog.WriteLine("tick,player,source_id,source_type,source_x,source_y,kind,amount,related_actor_id,site_id");
  }
  static bool Combat(Actor a) { return a.Info.HasTraitInfo<AttackBaseInfo>(); }
  static bool Live(Actor a) { return a!=null&&!a.IsDead&&a.IsInWorld&&a.OccupiesSpace!=null; }
  static int HpValue(Actor a) { var hp=a.TraitOrDefault<Health>(); return hp==null?ActorCost(a):(int)((long)ActorCost(a)*Math.Max(0,hp.HP)/Math.Max(1,hp.MaxHP)); }
  static int Hp(Actor a) { if(!Live(a)) return 0; var hp=a.TraitOrDefault<Health>(); return hp==null?0:hp.HP; }
  static string IncomeKey(uint id,Player owner) { return owner.InternalName+":"+id; }
  EngineerRecord Engineer(Actor actor,Player owner) {
   EngineerRecord r;
   if(!engineerRecords.TryGetValue(actor.ActorID,out r)) { r=new EngineerRecord{Actor=actor,Owner=owner,Start=actor.World.WorldTick,Cost=ActorCost(actor)}; engineerRecords[actor.ActorID]=r; }
   return r;
  }
  public void TelemetryCapture(Actor self,Actor captor,Player oldOwner,Player newOwner) {
   if(engineersLog==null||captor==null||captor.Info.Name!="e6") return;
   var r=Engineer(captor,newOwner); r.Captures++; r.Buildings.Add(self.ActorID); r.Status="captured"; incomeBeneficiaries[self.ActorID]=captor.ActorID;
   eventLog.WriteLine(Csv(self.World.WorldTick,"capture",self.ActorID,self.Info.Name,newOwner.InternalName,self.Location.X,self.Location.Y,ActorCost(self),captor.ActorID,"e6",oldOwner.InternalName,"","","","","capture linked to exact engineer"));
  }
  SiteRecord NearestSite(Player owner,CPos cell) {
   return siteRecords.Values.Where(s=>s.Owner==owner&&s.LostAt<0&&(s.Cell-cell).LengthSquared<=144).OrderBy(s=>(s.Cell-cell).LengthSquared).FirstOrDefault();
  }
  public void TelemetryIncome(Actor source,Player owner,int amount,string kind,Actor helper) {
   if(incomeLog==null||source.OccupiesSpace==null) return;
   var key=IncomeKey(source.ActorID,owner); long total; sourceIncome.TryGetValue(key,out total); sourceIncome[key]=total+amount;
   if(kind!="refinery_accepted") {
    uint id; EngineerRecord beneficiary=null;
    if(helper!=null&&helper.Info.Name=="e6") beneficiary=Engineer(helper,owner);
    else if(incomeBeneficiaries.TryGetValue(source.ActorID,out id)) engineerRecords.TryGetValue(id,out beneficiary);
    if(beneficiary!=null&&beneficiary.Owner==owner) beneficiary.Income+=amount;
   }
   var site=NearestSite(owner,source.Location);
   if(kind=="refinery_accepted"&&site!=null) site.AcceptedIncome+=amount;
   incomeLog.WriteLine(Csv(source.World.WorldTick,owner.InternalName,source.ActorID,source.Info.Name,source.Location.X,source.Location.Y,kind,amount,helper==null?"":helper.ActorID.ToString(),site==null?"":site.Id.ToString()));
  }
  public void TelemetrySupportRequest(Player player,Actor threat) {
   if(supportLog==null) return;
   SupportRecord r;
   if(supportRecords.TryGetValue(player,out r)&&!r.Ended) return;
   var asset=threat.World.Actors.Where(a=>Live(a)&&a.Owner!=player&&player.RelationshipWith(a.Owner)==PlayerRelationship.Ally&&a.CanBeViewedByPlayer(player)&&(a.Info.Name=="fact"||a.Info.Name=="proc"||a.Info.HasTraitInfo<HarvesterInfo>()))
    .OrderBy(a=>(a.Location-threat.Location).LengthSquared).FirstOrDefault();
   r=new SupportRecord{Id=++supportSerial,Start=threat.World.WorldTick,Player=player,Threat=threat,Asset=asset,HpBefore=Hp(asset)};
   supportRecords[player]=r; supportHistory.Add(r); WriteSupport(threat.World,r,"requested");
  }
  public void TelemetrySupportEnd(World world,Player player,string reason) {
   SupportRecord r; if(supportRecords.TryGetValue(player,out r)&&!r.Ended) {r.Ended=true;r.EndReason=reason;WriteSupport(world,r,"ended");}
  }
  void WriteSupport(World world,SupportRecord r,string status) {
   var asset=r.Asset;
   supportLog.WriteLine(Csv(world.WorldTick,r.Id,r.Player.InternalName,status,r.Start,r.Arrival<0?"":r.Arrival.ToString(),r.Arrival<0?"":(r.Arrival-r.Start).ToString(),r.OpId==0?"":r.OpId.ToString(),r.Threat.ActorID,asset==null?"":asset.ActorID.ToString(),asset==null?"":asset.Location.X.ToString(),asset==null?"":asset.Location.Y.ToString(),r.HpBefore,Hp(asset),asset!=null&&!Live(asset),r.EndReason));
  }
  void WriteYardRecovery(World world,Player player,YardLoss loss,string kind,SiteRecord replacement,Actor mcv) {
   recoveryLog.WriteLine(Csv(world.WorldTick,player.InternalName,kind,loss.Site.Id,loss.Site.Cell.X,loss.Site.Cell.Y,loss.Tick,replacement==null?"":replacement.Id.ToString(),replacement==null?"":replacement.Cell.X.ToString(),replacement==null?"":replacement.Cell.Y.ToString(),world.WorldTick-loss.Tick,mcv==null?"":mcv.ActorID.ToString(),mcv==null?"":mcv.Location.X.ToString(),mcv==null?"":mcv.Location.Y.ToString()));
  }
  List<YardLoss> PendingYards(Player player) {
   List<YardLoss> result;if(!yardLosses.TryGetValue(player,out result)){result=new List<YardLoss>();yardLosses[player]=result;}return result;
  }
  void YardRestored(World world,SiteRecord site) {
   if(site.Home)return;
   var pending=PendingYards(site.Owner);
   var loss=pending.FirstOrDefault(l=>l.Site==site)??pending.FirstOrDefault();
   if(loss==null)return;
   var same=loss.Site==site;
   WriteYardRecovery(world,site.Owner,loss,same?"replacement_same_area":"replacement_elsewhere",site,null);
   recoverySummaries.Add(site.Owner.InternalName+": forward yard bij "+loss.Site.Cell+" verloren op tick "+loss.Tick+"; latere forward yard bij "+site.Cell+" na "+(world.WorldTick-loss.Tick)+" ticks ("+(same?"zelfde gebied":"andere locatie")+"). Dit is waargenomen vervanging, geen bewijs van de interne bouwintentie.");
   pending.Remove(loss);
  }
  void DecisionScan(World world,Actor[] actors) {
   unitOperations.Clear();
   foreach(var p in world.Players.Where(p=>p.IsBot&&p.Playable)) {
    var manager=p.PlayerActor.TraitOrDefault<ImprovedSquadManagerBotModule>();
    var squads=manager==null||manager.IsTraitDisabled?new Squad[0]:manager.TelemetrySquads();
    foreach(var squad in squads) {
     Op op;
     var role=manager.TelemetryRole(squad.Units.First());
     if(!operations.TryGetValue(squad,out op)||op.Ended) {
      op=new Op{Id=++operationSerial,Start=world.WorldTick,Player=p,Squad=squad,Role=role,InitialValue=squad.Units.Sum(ActorCost),Target=squad.IsTargetValid?squad.TargetActor:null};
      operations[squad]=op; WriteOp(world,op,actors,"started");
     }
     op.Target=squad.IsTargetValid?squad.TargetActor:null;
     foreach(var a in squad.Units.Where(Live)){op.Members.Add(a.ActorID);unitOperations[a.ActorID]=op;}
     if(op.Arrival<0&&Live(op.Target)&&squad.Units.Any(a=>Live(a)&&(a.Location-op.Target.Location).LengthSquared<=64)) op.Arrival=world.WorldTick;
     SupportRecord support;
     if(role=="AllySupport"&&supportRecords.TryGetValue(p,out support)&&!support.Ended) {
      support.OpId=op.Id;
      if(support.Arrival<0&&Live(support.Asset)&&squad.Units.Any(a=>Live(a)&&(a.Location-support.Asset.Location).LengthSquared<=64)) support.Arrival=world.WorldTick;
     }
    }
    foreach(var op in operations.Values.Where(o=>o.Player==p&&!o.Ended&&!squads.Contains(o.Squad))) {op.Ended=true;WriteOp(world,op,actors,"ended");}
   }
   foreach(var a in actors.Where(a=>a.Owner.IsBot&&a.Info.Name=="e6")) Engineer(a,a.Owner);
   foreach(var r in engineerRecords.Values.Where(r=>r.Status=="active"&&!Live(r.Actor))) r.Status=r.Actor.IsDead?"destroyed":"removed_without_observed_capture";
   foreach(var a in actors.Where(a=>a.Owner.IsBot&&(a.Info.Name=="fact"||a.Info.Name=="proc"))) {
    if(siteRecords.Values.Any(s=>s.Owner==a.Owner&&s.LostAt<0&&(s.Cell-a.Location).LengthSquared<=144)) continue;
    var old=siteRecords.Values.Where(s=>s.Owner==a.Owner&&s.LostAt>=0&&(s.Cell-a.Location).LengthSquared<=144).OrderBy(s=>(s.Cell-a.Location).LengthSquared).FirstOrDefault();
    if(old!=null) {old.Anchor=a;old.Recoveries++;old.RecoveryDelay=world.WorldTick-old.LostAt;old.LostAt=-1;}
    else siteRecords[a.ActorID]=new SiteRecord{Id=a.ActorID,Owner=a.Owner,Cell=a.Location,Anchor=a,Start=world.WorldTick,Home=(a.Location-a.Owner.HomeLocation).LengthSquared<=324};
   }
   foreach(var site in siteRecords.Values.Where(s=>s.LostAt<0)) {
    var buildings=actors.Where(a=>a.Owner==site.Owner&&a.Info.HasTraitInfo<BuildingInfo>()&&(a.Location-site.Cell).LengthSquared<=144&&NearestSite(a.Owner,a.Location)==site).ToArray();
    foreach(var a in buildings) if(site.Buildings.Add(a.ActorID)) site.Invested+=ActorCost(a);
    var yard=buildings.Any(a=>a.Info.Name=="fact");
    if(site.HadYard&&!yard&&!site.YardMissing){site.YardMissing=true;site.YardLostAt=world.WorldTick;if(!site.Home){var loss=new YardLoss{Site=site,Tick=world.WorldTick};PendingYards(site.Owner).Add(loss);WriteYardRecovery(world,site.Owner,loss,"forward_yard_lost",null,null);}}
    if(site.YardMissing&&yard){site.YardMissing=false;site.YardRecoveries++;site.YardRecoveryDelay=world.WorldTick-site.YardLostAt;YardRestored(world,site);}
    if(yard&&!site.HadYard){YardRestored(world,site);site.HadYard=true;}
    if(!Live(site.Anchor)) {
     var anchor=buildings.FirstOrDefault(a=>a.Info.Name=="fact"||a.Info.Name=="proc");
     if(anchor==null) site.LostAt=world.WorldTick; else site.Anchor=anchor;
    }
   }
   foreach(var pair in yardLosses) foreach(var loss in pair.Value.Where(l=>l.McvTick<0)) {
    var mcv=actors.FirstOrDefault(a=>a.Owner==pair.Key&&a.Info.Name=="mcv");
    if(mcv!=null){loss.McvTick=world.WorldTick;WriteYardRecovery(world,pair.Key,loss,"mcv_available",null,mcv);}
   }
  }
  CombatRecord CombatTotals(Player player) {
   CombatRecord value; if(!combatRecords.TryGetValue(player,out value)){value=new CombatRecord();combatRecords[player]=value;}return value;
  }
  long LoggedIncome(Player player) { return sourceIncome.Where(kv=>kv.Key.StartsWith(player.InternalName+":" )).Sum(kv=>kv.Value); }
  void DecisionDamage(Actor victim,Actor attacker,int hpAfter) {
   Op sourceOp, victimOp;
   unitOperations.TryGetValue(victim.ActorID,out victimOp);
   if(attacker!=null&&attacker.Owner.RelationshipWith(victim.Owner)==PlayerRelationship.Enemy) {
    if(unitOperations.TryGetValue(attacker.ActorID,out sourceOp)&&sourceOp.Contact<0) sourceOp.Contact=victim.World.WorldTick;
    if(victimOp!=null&&victimOp.Contact<0) victimOp.Contact=victim.World.WorldTick;
   }
   if(hpAfter!=0||!fatalActors.Add(victim.ActorID)) return;
   if(ImprovedSquadManagerBotModule.VeteranRank(victim)>0)TelemetryVeteran(victim,"fatal_damage");
   var casualty=CombatTotals(victim.Owner); var cost=ActorCost(victim); casualty.Lost+=cost;
   var army=Combat(victim)&&(victim.Info.HasTraitInfo<MobileInfo>()||victim.Info.HasTraitInfo<AircraftInfo>());
   var building=victim.Info.HasTraitInfo<BuildingInfo>(); var harvester=victim.Info.HasTraitInfo<HarvesterInfo>();
   if(army)casualty.ArmyLost+=cost; if(building)casualty.BuildingLost+=cost;if(harvester)casualty.HarvesterLost+=cost;
   if(attacker!=null&&attacker.Owner.RelationshipWith(victim.Owner)==PlayerRelationship.Enemy){
    var killer=CombatTotals(attacker.Owner);killer.Killed+=cost;
    if(army)killer.ArmyKilled+=cost;if(building)killer.BuildingKilled+=cost;if(harvester)killer.HarvesterKilled+=cost;
   }
   if(victimOp!=null&&!victimOp.Ended) victimOp.Lost+=ActorCost(victim);
   if(attacker!=null&&attacker.Owner.RelationshipWith(victim.Owner)==PlayerRelationship.Enemy&&unitOperations.TryGetValue(attacker.ActorID,out sourceOp)&&!sourceOp.Ended) {
    sourceOp.Killed+=ActorCost(victim);
    if(victim.Info.HasTraitInfo<HarvesterInfo>()||victim.Info.Name=="proc"||victim.Info.HasTraitInfo<CashTricklerInfo>()) sourceOp.EconomicKills++;
   }
   foreach(var site in siteRecords.Values.Where(s=>s.Owner==victim.Owner&&s.Buildings.Contains(victim.ActorID))) site.DestroyedValue+=ActorCost(victim);
  }
  void WriteOp(World world,Op op,Actor[] actors,string status) {
   var units=actors.Where(a=>op.Squad.Units.Contains(a)&&a.Owner==op.Player).ToArray();
   var center=units.Length==0?op.Player.HomeLocation:new CPos((int)units.Average(a=>a.Location.X),(int)units.Average(a=>a.Location.Y));
   var enemies=actors.Where(a=>Combat(a)&&op.Player.RelationshipWith(a.Owner)==PlayerRelationship.Enemy&&a.CanBeViewedByPlayer(op.Player)&&(a.Location-center).LengthSquared<=144);
   var friends=actors.Where(a=>Combat(a)&&op.Player.RelationshipWith(a.Owner)==PlayerRelationship.Ally&&(a.Location-center).LengthSquared<=144);
   var r=op.Player.PlayerActor.Trait<PlayerResources>();var target=op.Target;
   operationsLog.WriteLine(Csv(world.WorldTick,op.Id,op.Player.InternalName,op.Role,status,op.Start,op.Contact<0?"":op.Contact.ToString(),op.Arrival<0?"":op.Arrival.ToString(),target==null?"":target.ActorID.ToString(),target==null?"":target.Info.Name,target==null?"":target.Location.X.ToString(),target==null?"":target.Location.Y.ToString(),units.Length,op.InitialValue,units.Sum(ActorCost),units.Sum(HpValue),enemies.Sum(HpValue),friends.Sum(HpValue),op.Lost,op.Killed,op.EconomicKills,op.Lost==0?"":(op.Killed/(double)op.Lost).ToString("F3",System.Globalization.CultureInfo.InvariantCulture),r.Earned,r.Spent,string.Join(";",units.GroupBy(a=>a.Info.Name).OrderBy(g=>g.Key).Select(g=>g.Key+":"+g.Count())),string.Join(";",enemies.GroupBy(a=>a.Info.Name).OrderBy(g=>g.Key).Select(g=>g.Key+":"+g.Count()))));
  }
  void DecisionSnapshot(World world,Actor[] actors) {
   foreach(var p in world.Players.Where(p=>p.IsBot&&p.Playable)){
    var c=CombatTotals(p);
    combatLog.WriteLine(Csv(world.WorldTick,p.InternalName,p.BotType,c.Lost,c.Killed,c.ArmyLost,c.ArmyKilled,c.BuildingLost,c.BuildingKilled,c.HarvesterLost,c.HarvesterKilled,c.Lost==0?"":(c.Killed/(double)c.Lost).ToString("F3",System.Globalization.CultureInfo.InvariantCulture)));
   }
   foreach(var op in operations.Values.Where(o=>!o.Ended)) WriteOp(world,op,actors,world.IsGameOver?"game_over":"active");
   foreach(var r in engineerRecords.Values) {
    long income=0,value;
    foreach(var id in r.Buildings) if(sourceIncome.TryGetValue(IncomeKey(id,r.Owner),out value)) income+=value;
    engineersLog.WriteLine(Csv(world.WorldTick,r.Actor.ActorID,r.Owner.InternalName,r.Start,r.Status,r.Cost,r.Captures,string.Join(";",r.Buildings),r.Income,r.Income-r.Cost));
   }
   foreach(var s in siteRecords.Values) {
    var buildings=actors.Where(a=>a.Owner==s.Owner&&a.Info.HasTraitInfo<BuildingInfo>()&&NearestSite(a.Owner,a.Location)==s).ToArray();
    sitesLog.WriteLine(Csv(world.WorldTick,s.Id,s.Owner.InternalName,s.Cell.X,s.Cell.Y,s.Home,s.LostAt<0?"active":"lost",s.Start,s.LostAt<0?"":s.LostAt.ToString(),s.Recoveries,s.RecoveryDelay<0?"":s.RecoveryDelay.ToString(),buildings.Length,buildings.Where(Combat).Sum(ActorCost),s.Invested,s.DestroyedValue,s.AcceptedIncome,s.AcceptedIncome-s.Invested,buildings.Any(a=>a.Info.Name=="fact"),s.YardLostAt<0?"":s.YardLostAt.ToString(),s.YardRecoveries,s.YardRecoveryDelay<0?"":s.YardRecoveryDelay.ToString()));
   }
   foreach(var r in supportRecords.Values.Where(r=>!r.Ended)) WriteSupport(world,r,world.IsGameOver?"game_over":"active");
  }
  void WriteDecisionSummary(World world) {
   if(decisionPrefix==null)return;
   var lines=new List<string>{"Wedstrijdanalyse - laatste meetpunt tick "+world.WorldTick,"","Verliezen alleen bepalen niet of een aanval goed was. Vergelijk geruilde waarde, economische doelen, inkomsten, positie en de uitslag.","Waarde hieronder is aanschafwaarde, geen volledige maat voor gevechtskracht. De logger observeert; de AI krijgt deze gegevens niet."};
   foreach(var p in world.Players.Where(p=>p.IsBot&&p.Playable)) {
    var resources=p.PlayerActor.Trait<PlayerResources>();
    lines.Add("");lines.Add(p.InternalName+" ("+p.BotType+"): "+p.WinState+"; verdiend "+resources.Earned+", uitgegeven "+resources.Spent+".");
    var totals=CombatTotals(p);
    lines.Add("  Totale vernietigde aanschafwaarde: verloren "+totals.Lost+", vijand uitgeschakeld "+totals.Killed+". Iedere actor telt één keer; verkoop/verdwijnen is geen gevechtsverlies.");
    lines.Add("  Aan inkomstenbronnen toegeschreven "+LoggedIncome(p)+"; verschil met verdiend-teller "+(resources.Earned-LoggedIncome(p))+". Verschil kan andere inkomsten of timing zijn.");
    foreach(var op in operations.Values.Where(o=>o.Player==p))
     lines.Add("  Groep "+op.Id+" "+op.Role+": vertrekwaarde "+op.InitialValue+", verloren "+op.Lost+", uitgeschakeld "+op.Killed+", economische doelen vernietigd "+op.EconomicKills+", eerste gevechtscontact "+(op.Contact<0?"niet gemeten":op.Contact.ToString())+". Alleen aan deze groep toegeschreven schade.");
    foreach(var e in engineerRecords.Values.Where(e=>e.Owner==p))
     lines.Add("  Engineer "+e.Actor.ActorID+": "+e.Status+", kosten "+e.Cost+", innames "+e.Captures+", werkelijke cash uit ingenomen oliegebouwen "+e.Income+", cash minus engineerprijs "+(e.Income-e.Cost)+".");
    foreach(var site in siteRecords.Values.Where(s=>s.Owner==p))
     lines.Add("  Basis "+site.Id+" bij "+site.Cell+" ("+(site.Home?"startgebied":"uitbreiding")+"): geaccepteerde oogstopbrengst "+site.AcceptedIncome+", geplaatste gebouwwaarde "+site.Invested+", vernietigde gebouwwaarde "+site.DestroyedValue+", herstelde construction yards "+site.YardRecoveries+", laatste hersteltijd "+(site.YardRecoveryDelay<0?"niet gemeten":site.YardRecoveryDelay+" ticks")+".");
    foreach(var help in supportHistory.Where(h=>h.Player==p))
     lines.Add("  Hulpvraag "+help.Id+": aankomst "+(help.Arrival<0?"niet gemeten":(help.Arrival-help.Start)+" ticks na aanvraag")+", beschermd object "+(help.Asset==null?"onbekend":help.Asset.ActorID.ToString())+", object verloren "+(help.Asset!=null&&!Live(help.Asset))+", eindreden "+help.EndReason+".");
   }
   lines.Add("");lines.AddRange(recoverySummaries);
   lines.Add("");lines.Add("De opbrengst van een basis is geen nettowinst: MCV/harvesters, eenheden, reistijd, opportunity costs, subsidies en gemiste inkomsten zijn niet volledig toegerekend. Een hulpvraag of ruil bewijst geen causaal effect.");
   File.WriteAllLines(decisionPrefix+"-analyse.txt",lines);
  }
  void FlushDecisions() { foreach(var w in new[]{operationsLog,engineersLog,sitesLog,supportLog,incomeLog,combatLog,recoveryLog,veteranLog,attackDecisionLog,localAttackLog,attackTraceLog}) if(w!=null)w.Flush(); }
 }
}









