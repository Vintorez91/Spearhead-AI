using System;
using System.Linq;
using OpenRA.Traits;
using OpenRA.Mods.Common.Traits.AITest.Squads;
namespace OpenRA.Mods.Common.Traits.AITest
{
 public partial class ImprovedSquadManagerBotModule
 {
  Squad supportSquad;
  void UpdateAllySupport(IBot bot, ImprovedStrategyBotModule strategy) {
   var threat = strategy.AllyEnemies.FirstOrDefault(a => a.IsInWorld && !a.IsDead && a.CanBeViewedByPlayer(Player));
   var logger=World.WorldActor.TraitOrDefault<AITestMetrics>();
   if(strategy.Plan==StrategicPlan.Defend || threat==null) {
    if(logger!=null) logger.TelemetrySupportEnd(World,Player,threat==null?"visible_threat_cleared":"own_base_defence_priority");
    if(supportSquad!=null) {
     foreach(var a in supportSquad.Units.Where(a=>!unitCannotBeOrdered(a))) bot.QueueOrder(new Order("Move",a,Target.FromCell(World,GetRandomBaseCenter()),false));
     ReleaseUnits(supportSquad); Squads.Remove(supportSquad); supportSquad=null; FindNewUnits(bot);
    }
    return;
   }
   if(logger!=null) logger.TelemetrySupportRequest(Player,threat);
   if(supportSquad==null || !Squads.Contains(supportSquad)) supportSquad=RegisterNewSquad(bot,SquadType.Protection,threat);
   supportSquad.TargetActor=threat;
   var desired=Math.Min(10,Math.Max(0,strategy.CombatCount-4));
   var available=unitsHangingAroundTheBase.Concat(Squads.Where(s=>s!=supportSquad&&(s.Type==SquadType.Assault||s.Type==SquadType.Rush)).SelectMany(s=>s.Units))
    .Where(a=>!unitCannotBeOrdered(a)&&a.Info.HasTraitInfo<MobileInfo>()&&a.Info.HasTraitInfo<AttackBaseInfo>()).Distinct()
    .OrderBy(a=>(a.CenterPosition-threat.CenterPosition).LengthSquared).Take(Math.Max(0,desired-supportSquad.Units.Count)).ToArray();
   foreach(var a in available) TransferUnit(a,supportSquad);
   if(available.Length>0) LogOperation(supportSquad,"ally support assigned="+supportSquad.Units.Count+" reserve=4");
  }
 }
}

