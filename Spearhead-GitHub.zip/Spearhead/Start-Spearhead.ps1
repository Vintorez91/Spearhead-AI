param([Parameter(Mandatory=$true)][string]$EngineDir)
$ErrorActionPreference='Stop'
$engine=(Resolve-Path -LiteralPath $EngineDir).Path
$versionFile=Join-Path $engine 'VERSION'
if(!(Test-Path $versionFile) -or (Get-Content $versionFile -Raw).Trim() -ne 'release-20250330'){throw 'Requires OpenRA release-20250330'}
if(!(Test-Path "$engine/RedAlert.exe")){throw 'Select the OpenRA program folder containing RedAlert.exe'}
$gameArgs=@('Game.Mod=spearhead-ai',('"Engine.EngineDir='+$engine+'"'),('"Engine.ModSearchPaths='+$PSScriptRoot+'\mods,'+$engine+'\mods"'))
Start-Process "$engine/RedAlert.exe" -ArgumentList $gameArgs -WorkingDirectory $engine -WindowStyle Normal
